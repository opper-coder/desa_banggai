PENGAMBILAN DATA DARI HALAMAN DAN CARA HANDLINGNYA:

HANDLING DATA:
/*-------------------------------------------------------*/
	PENGUMUMAN --->
		- periksa koneksi di home
		- lihat di dashboard
		- buatkan data koneksi
		- buatkan data untuk handling di dashboard
		- buatkan halaman data handling
	LAYANAN --->
		- saat data dikirim ada pop up notifikasi:
			- gagal
			- sukses -> tb status
			- data tidak valid
			- 
		- 


CARA INPUT DATA:
/*-------------------------------------------------------*/
	PENGUMUMAN --->
	- harusnya :
		- dashboard:
			- input :
			- 
	- hasilnya: BELUM