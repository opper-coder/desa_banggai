<?php
// ganti warna theme di akhir $theme
 	$theme = "../view/theme/theme_green.php";
 	require "../view/top_body.php";
	require $theme;
	require "../view/center_body.php";
?>
<!-- kirim theme dan iddesa -->
<a href="../pages/baca_inspirasi.php?theme=<?= $theme; ?>&iddesa=saiti" >buka halaman dan kirim get</a>








<!-- akhir body -->
	<?php require '../view/bottom_body.php' ?>