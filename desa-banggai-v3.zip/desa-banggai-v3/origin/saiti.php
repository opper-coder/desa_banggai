
<?php
	// pastikan nama file origin ini ("saiti.php") sama dengan $iddesa, 'desa' di mysql, 

 	$theme = "../view/theme/theme_green.php";
 	$iddesa = "saiti";
 	
 	require "../view/top_body.php";
	require $theme;
	require "../view/center_body.php";
	require '../core/init.php';

	$querycarousel = "SELECT * FROM artikel WHERE desa='$iddesa' AND type='Pengumuman' ORDER BY id DESC LIMIT 3";
	$resultcorousel = mysqli_query($conn, $querycarousel);
	
	$querypend = "SELECT * FROM penduduk WHERE desa='$iddesa' ";
	$querypend2 = "SELECT * FROM penduduk WHERE desa='$iddesa' AND kelamin='laki-laki'";
	$querypend3 = "SELECT * FROM penduduk WHERE desa='$iddesa' AND kelamin='Perempuan'";

	$desa = $_SESSION['desa'] = $iddesa;
	$tema = $_SESSION['tema'] = $theme;

if(isset($_SESSION['error'])){unset($_SESSION["error"]);}

function hitungbarispenduduk($query){
	global $conn;
	global $iddesa;

	$resultpend = mysqli_query($conn, $query);
	$datapend = mysqli_num_rows($resultpend);
	echo $datapend;
}
	?>
<!-- body home -->

<div class="navHome w3-theme-d2 w3-padding w3-card">
	<a href="../pages/about.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>"><img src="../assets/info.png" alt=""></a>
	<a href="../functions/login.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>"><img src="../assets/akun1.png" alt="" class="w3-right"></a>
	<a href="../pages/n14_pesan.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>"><img src="../assets/pesan1.png" alt="" class="w3-right"></a>
	<a href="../pages/n6_status_layanan.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>"><img src="../assets/status.png" alt="" class="w3-right"></a>
</div>
<div class="home">
	<div class="wadahDesa ">
		<img src="../assets/saiti/utils/desa.png" alt="" class="desa w3-right">
	</div>

<?= "ini berada dibawah top navbar kayaknya ketutup"; ?>

	<div class="jumbotron w3-theme-d1">
		<img src="../assets/saiti/utils/logoSaiti.png" alt="" class="logo">
		<div class="saitiHome">
			<span class="w3-large">Saiti mobile </span>
			<br>
			<span class="w3-small">Dari desa Saiti untuk Indonesia</span>
		</div>
		<div class="statHome">
			<span class="w3-large">2096<?php // hitungbarispenduduk($querypend); ?></span>
			<span class="w3-large">1095<?php // hitungbarispenduduk($querypend2); ?></span>
			<span class="w3-large">1001<?php // hitungbarispenduduk($querypend3); ?></span>
			<span class="w3-tiny">jumlah Jiwa</span>
			<span class="w3-tiny">Laki laki</span>
			<span class="w3-tiny">Perempuan</span>
		</div>

<!-- carousel -->		
		<div class="containerCarousel">
			<div class="owl-carousel owl-theme">
				<?php
				while ( $datacarousel = mysqli_fetch_assoc($resultcorousel) ):?>
							<div class="item">
								<a href="../pages/n1_pengumuman.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>">
								<div class="carouselCn">
									<img src="../assets/saiti/iconThumb/pengumuman2.png" alt="tdk tersedia" class="w3-circle w3-border" >
									<span></span>
									<p class="w3-tiny lipattext">
										<b style="text-transform: capitalize;"><?= $datacarousel["judul"]; ?></b>
										<br>
										<span>
											<i>pengumuman berlaku sampai :<?= $datacarousel["berlaku"]; ?></i>
										</span>
										<br>
										<?= $datacarousel["p1"]; ?>
									</p>
								</div>
								 </a>
							</div> 
				<?php endwhile ?>
			</div>
		</div>
<!-- end carousel -->
	</div>
<!-- end jumbotron -->

<?php 
	// var_dump($resultpend);
 ?>

<!-- menu kotak home -->
	<div class="menuHomeCn">
		<div class="menuHome satu w3-card-2 ">
			<a href="../pages/n3_layanan.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>">
			<img src="../assets/saiti/iconUi/layanan.jpg" alt="" >
			</a>
			<a href="../pages/n3_layanan.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>" class="aNone">
			<span>Layanan</span>
			</a>
		</div>
		
		<div class="menuHome w3-card-2">
			<a href="../pages/n7_statistik.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>">
			<img src="../assets/saiti/iconUi/statistik.jpg" alt="" >
			</a>
			<a href="../pages/n7_statistik.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>" class="aNone">
			<span>Statistik</span>
			</a>
		</div>

		<div class="menuHome tiga w3-card-2">
			<a href="../pages/n10_apbdes.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>">
			<img src="../assets/saiti/iconUi/apbdes.jpg" alt="" >
			</a>
			<a href="../pages/n10_apbdes.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>" class="aNone">
			<span>APBDes</span>
			</a>
		</div>

		<div class="menuHome w3-card-2">
			<a href="../pages/n14_pesan.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>">
			<img src="../assets/saiti/iconUi/pesan.jpg" alt="" >
			</a>
			<a href="../pages/n14_pesan.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>"  class="aNone">
			<span>Pesan</span>
			</a>
		</div>

		<div class="menuHome tiga w3-card-2">
			<a href="../pages/n16_berita.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>" class="aNone">
			<img src="../assets/saiti/iconUi/berita.jpg" alt="" >
			</a>
			<a href="../pages/n10_apbdes.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>" class="aNone">
			<span>Berita</span>
			</a>
		</div>

		<div class="menuHome w3-card-2">
			<a href="../pages/n18_mitra.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>" class="aNone">
			<img src="../assets/saiti/iconUi/covid.png" alt="" >
			</a>
			<a href="../pages/n14_pesan.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>"  class="aNone">
			<span>COVID-19</span>
			</a>
		</div>
		




<!-- menu kotak home -->


<!-- daftar list berita -->

<!-- 
	</div>
	<a href="../pages/n16_berita.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>" class="aNone">
	<div class="testimoni w3-card-2 w3-small">
		<img src="../img/kades.jpg" alt="">
		<p><b>berita</b><br>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo modi doloremque, voluptatem maiores autem iure perspiciatis eaque magnam, </p>
	</div>
	</a>

	<a href="../pages/n18_mitra.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>" class="aNone">
	<div class="testimoni w3-card-2 w3-small">
		<img src="../img/kades.jpg" alt="">
		<p><b>mitra</b><br>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo modi doloremque, voluptatem maiores autem iure perspiciatis eaque magnam, </p>
	</div>
	</a>
 -->

<!-- end daftar list berita -->
</div>	

<!-- akhir body -->
	<?php require '../view/bottom_body.php' ?>