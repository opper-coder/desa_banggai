<?php 	
	$judulHalaman = "NAMA KONTAK";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$hrefBack = "n14_pesan.php?theme=$theme&iddesa=$iddesa";
 
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
?>
<div class="chatCn w3-pale-green">
	


	<i class="pengirim w3-small">@sopyan  | 10 okt | 7.30 am | terkirim</i>
	<div class="inbox w3-green">
		Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni, sit! consectetur adipisicing elit. Magni, sit!
	</div>

	<i class="penerima w3-small">admin | 10 okt | 7.30 am | terkirim</i>
	<div class="outbox w3-white w3-border">
		Lorem ipsum dolor sit amet,
	</div>




<!--hapus batas ini  -->

<i class="pengirim w3-small">@sopyan  / 10 okt, terkirim</i>
	<div class="inbox w3-green">
		Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni, sit! consectetur adipisicing elit. Magni, sit!
	</div>

	<i class="penerima w3-small">admin / 10 okt, terkirim</i>
	<div class="outbox w3-white w3-border">
		Lorem ipsum dolor sit amet,
	</div>
	<i class="pengirim w3-small">@sopyan  / 10 okt, terkirim</i>
	<div class="inbox w3-green">
		Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni, sit! consectetur adipisicing elit. Magni, sit!
	</div>

	<i class="penerima w3-small">admin / 10 okt, terkirim</i>
	<div class="outbox w3-white w3-border">
		Lorem ipsum dolor sit amet,
	</div>
	<i class="pengirim w3-small">@sopyan  / 10 okt, terkirim</i>
	<div class="inbox w3-green">
		Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni, sit! consectetur adipisicing elit. Magni, sit!
	</div>

	<i class="penerima w3-small">admin / 10 okt, terkirim</i>
	<div class="outbox w3-white w3-border">
		Lorem ipsum dolor sit amet,
	</div>
	<i class="pengirim w3-small">@sopyan  / 10 okt, terkirim</i>
	<div class="inbox w3-green">
		Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni, sit! consectetur adipisicing elit. Magni, sit!
	</div>

	<i class="penerima w3-small">admin / 10 okt, terkirim</i>
	<div class="outbox w3-white w3-border">
		Lorem ipsum dolor sit amet,
	</div>
	<i class="pengirim w3-small">@sopyan  / 10 okt, terkirim</i>
	<div class="inbox w3-green">
		Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni, sit! consectetur adipisicing elit. Magni, sit!
	</div>

	<i class="penerima w3-small">admin / 10 okt, terkirim</i>
	<div class="outbox w3-white w3-border">
		Lorem ipsum dolor sit amet,
	</div>
	<i class="pengirim w3-small">@sopyan  / 10 okt, terkirim</i>
	<div class="inbox w3-green">
		Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni, sit! consectetur adipisicing elit. Magni, sit!
	</div>

	<i class="penerima w3-small">admin / 10 okt, terkirim</i>
	<div class="outbox w3-white w3-border">
		Lorem ipsum dolor sit amet,
	</div>
	<i class="pengirim w3-small">@sopyan  / 10 okt, terkirim</i>
	<div class="inbox w3-green">
		Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni, sit! consectetur adipisicing elit. Magni, sit!
	</div>

	<i class="penerima w3-small">admin / 10 okt, terkirim</i>
	<div class="outbox w3-white w3-border">
		Lorem ipsum dolor sit amet,
	</div>
	<i class="pengirim w3-small">@sopyan  / 10 okt, terkirim</i>
	<div class="inbox w3-green">
		Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni, sit! consectetur adipisicing elit. Magni, sit!
	</div>

	<i class="penerima w3-small">admin / 10 okt, terkirim</i>
	<div class="outbox w3-white w3-border">
		Lorem ipsum dolor sit amet,
	</div>
	<i class="pengirim w3-small">@sopyan  / 10 okt, terkirim</i>
	<div class="inbox w3-green">
		Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni, sit! consectetur adipisicing elit. Magni, sit!
	</div>

	<i class="penerima w3-small">admin / 10 okt, terkirim</i>
	<div class="outbox w3-white w3-border">
		Lorem ipsum dolor sit amet,
	</div>


<!--hapus batas ini   -->

	<form action="" method="" class="formMsgCn w3-theme-l3">
		<input type="text" class="message">
		
		<button type="" class="msgsend">
			<img src="../assets/panahKiri.png" alt="" style="width: 100%">
		</button>
		<button type="submit" class="msgsend">
			<img src="../assets/panahKiri.png" alt="" style="width: 100%">
		</button>
	</form>


</div>





	<?php require '../view/bottom_body.php' ?>