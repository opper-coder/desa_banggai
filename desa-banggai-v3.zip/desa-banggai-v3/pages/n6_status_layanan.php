<?php 	
	$judulHalaman 		= "STATUS LAYANAN";
	$theme 				= $_GET['theme'];
	$iddesa 			= $_GET['iddesa'];
	$hrefBack 			= "../origin/saiti.php";
	$gambarJumbotron 	= "../assets/saiti/ilustrasi/layanan.jpg";
	require '../view/top_body.php';
	require $theme;
	require '../view/navback.php';
	require '../view/jumbotron.php';
	require '../view/center_body.php';
	require '../core/init.php';
	$sender = $_SESSION['user'];

	$datastatus 		= query("SELECT verifikasi FROM suratkeluar WHERE desa='$iddesa' AND sender='$sender' ");
	$status  				= status($datastatus);

	$querysedang		= "SELECT * FROM suratkeluar WHERE verifikasi!='4' AND desa='$iddesa' AND sender='$sender'ORDER BY tglmasuk DESC";
	$queryhistory		= "SELECT * FROM suratkeluar WHERE verifikasi='4' AND desa='$iddesa' AND sender='$sender'ORDER BY tglmasuk DESC";
	//$querysedang		= "SELECT * FROM suratkeluar WHERE verifikasi!='4' ORDER BY tglmasuk DESC"; // sementara untuk debug
	//$queryhistory		= "SELECT * FROM suratkeluar WHERE verifikasi='4' ORDER BY tglmasuk DESC"; // sementara untuk debug
	$resultsedang 	= mysqli_query($conn, $querysedang);
	$resulthistory 	= mysqli_query($conn, $queryhistory);
// ------------------ cek login -------------------
if( !isset($_SESSION['user']) ){
	// die('anda belum login');
	header ( 'Location: ../functions/login.php' );
}
// var_dump($_SESSION);
// --------------------------------------------------------------------------  ?>
<div class="jarak20"></div>
<div class="containerBaca">
	<b>Sedang di proses:</b>
	<div class="jarak10"></div>
	<section>
<?php 
while ($sedang 	= mysqli_fetch_assoc($resultsedang)) { ?>
		<div class="w3-white w3-card w3-round w3-padding w3-small marginB10" >
			<p class="datastatus"><b>Nama Surat: <?= 'cari dulu'; ?></b></p>
			<div class="kotakstatus">
				<p class="">perihal : <b><?= $sedang["perihal"] ;?></b></p>
				<p class="">Tanggal masuk : <b><?= $sedang["tglmasuk"] ;?></b></p>
				<p class="">Pemohon : <b><?= $sedang["pemohon"] ;?></b></p>
				<p class="">Pengirim : <b><?= $sedang["sender"] ;?></b></p>
				<p class="">Status permohonan : <b><?= status($datastatus); ?></b></p>
				<p><a href="n30_edit.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&edit=true&idd=<?= $sedang['id']; ?>" class="w3-button w3-theme-d4 w3-round">Edit data</a></p>
			</div>
			<p class="">Pesan : <b><?= $sedang["pesan"]; ?></b></p>	
		</div>
<?php } ?>
	</section>
	<!-- ---------------------------------------------------------------------- -->
	<div class="jarak20"></div>
	<b>History permohonan:</b>
	<div class="jarak10"></div>
	<section>
<?php 
while ($history 	= mysqli_fetch_assoc($resulthistory)) { ?>
		<div class="w3-white w3-card w3-round w3-padding w3-small marginB10" >
			<p class="datastatus"><b>Nama Surat: Cari 2<?= $namalayanan["nama"]; ?></b></p>
			<div class="kotakstatus">
				<p class="">perihal : <b><?= $history["perihal"] ;?></b></p>
				<p class="">Pemohon : <b><?= $history["pemohon"] ;?></b></p>
				<p class="">Tanggal masuk : <b><?= $history["tglmasuk"] ;?></b></p>
				<p><a href="n30_edit.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&edit=false&idd=<?= $history['id']; ?>" class="w3-button w3-tiny w3-theme-l3 w3-round">Lihat data</a></p>
			</div>
		</div>
<?php } ?>
	</section>
</div>
<?php require '../view/bottom_body.php' ?>
