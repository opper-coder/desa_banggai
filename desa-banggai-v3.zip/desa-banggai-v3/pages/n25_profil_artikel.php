<?php 	
	$judulHalaman = "ARSIP";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$gambarJumbotron = "../assets/ilustrasi/baca.jpg";
	$hrefBack = "n20_profil_desa.php?theme=$theme&iddesa=$iddesa";
 
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
	require '../view/jumbotron.php';
?>
<!-- <a href="../pages/baca_inspirasi.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>" >buka halaman dan kirim get</a> -->
<div class="jarak20"></div>



<div class="containerBaca">
	
	<a href="n29_arsip.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>">
	<div class="w3-white w3-card w3-round w3-padding w3-small avatar">
		<img src="../img/kades.jpg" alt="personal" class="w3-circle" style="width: 70px;">
		<p><b>Lorem ipsum:</b> dolor sit amet, consectetur adipisicing elit. Tenetur maxime velit inventore ullam odit exercitationem voluptatibus at eaque incidunt, </p>
	</div>
	</a>



	<a href="">
	<div class="w3-white w3-card w3-round w3-padding w3-small avatar">
		<img src="../img/kades.jpg" alt="personal" class="w3-circle" style="width: 70px;">
		<p><b>Lorem ipsum:</b> dolor sit amet, consectetur adipisicing elit. Tenetur maxime velit inventore ullam odit exercitationem voluptatibus at eaque incidunt, </p>
	</div></a>

	
</div>






	<?php require '../view/bottom_body.php' ?>