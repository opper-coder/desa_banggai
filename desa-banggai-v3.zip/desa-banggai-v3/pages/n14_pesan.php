<?php 	
	$judulHalaman = "PESAN";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$hrefBack = "../origin/saiti.php";
 
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
	require '../core/init.php';
?>


<?php // ============== halaman butuh login ===========

if( !isset($_SESSION['user']) ){
	// die('anda belum login');
	header ( 'Location: ../functions/login.php' );
}

// ============== /halaman butuh login ===========  ?>




<!-- <a href="../pages/baca_inspirasi.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>" >buka halaman dan kirim get</a> -->
<div class="jarak40"></div>

<a href="n15_pesan2.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>" style="text-decoration: none;">
<div class="w3-border-bottom w3-padding kontakPesan">
	<div class="gambarKontak"><img src="../img/saiti/aparat/bupati/bupati2021.jpg" alt="" class="gambarUmum"></div>
	<div class="daftarKontak">
		<b class="namaKontak">admin</b><i class="w3-small w3-right">12/9/2019</i>
		<div class="singkatanPesan w3-small">Assalamualaikum, semua</div>
	</div>
</div>
</a>

<a href="" style="text-decoration: none;">
<div class="w3-border-bottom w3-padding kontakPesan">
	<div class="gambarKontak"><img src="../img/saiti/aparat/bupati/bupati.jpg" alt="" class="gambarUmum"></div>
	<div class="daftarKontak">
		<b class="namaKontak">admin2</b><i class="w3-small w3-right">12/9/2019</i>
		<div class="singkatanPesan w3-small">Assalamualaikum, semua</div>
	</div>
</div>
</a>


<p style="background-color:salmon;
			margin:40px 16px 0px 16px;
			border-radius: 10px;
			padding: 15px;
			color: White;
			text-align: center;
			">halaman pesan desa masih dalam pengembangan</p>
	
<?php require '../view/bottom_body.php' ?>