<?php 	
	$judulHalaman = "ISI PENGUMUMAN";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$gambarJumbotron = "../assets/ilustrasi/baca.jpg";
	$hrefBack = "n1_pengumuman.php?theme=$theme&iddesa=$iddesa";
 
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
	require '../view/jumbotron.php';
?>
<!-- <a href="../pages/baca_inspirasi.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>" >buka halaman dan kirim get</a> -->










	<?php require '../view/bottom_body.php' ?>