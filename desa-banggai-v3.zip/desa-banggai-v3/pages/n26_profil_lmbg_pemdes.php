<?php 	
	$judulHalaman = "PROFIL PEJABAT";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$kategori = $_GET['kategori'];
	$periode = $_GET['periode'];
	$hrefBack = "n27_profil_periode.php?theme=$theme&iddesa=$iddesa&kategori=$kategori";
 
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';

	require '../core/init.php';

$periode = $_GET["periode"]; //?????

$queryKdes = "SELECT * FROM aparat WHERE Periode=$periode AND jabatan='kepala desa' AND desa='$iddesa' AND kategori='$kategori'";
$querySek = "SELECT * FROM aparat WHERE Periode=$periode AND jabatan='Sekretaris desa' AND desa='$iddesa' AND kategori='$kategori'";

$resultKdes = mysqli_query($conn, $queryKdes);
$resultSek = mysqli_query($conn, $querySek);

$dataKdes = mysqli_fetch_assoc($resultKdes);
$dataSek = mysqli_fetch_assoc($resultSek);

?>

<div class="jarak40"></div>
<div class="cardBlock ketua">
	<div class="bingkaiKetua">
		<img src="../img/<?= $dataKdes["foto"] ?>" alt="" class="gambarUmum">
	</div>
</div>

<!-- kades -->
<div class="jarak20"></div>
<div class="w3-theme-l3 w3-card w3-padding">
	<b>Periode Pemerintahan desa <?= $_GET["iddesa"] ?> ke <?= $_GET["periode"] ?> tahun <?= $dataKdes["thPeriodeA"] ?> - <?= $dataKdes["thPeriodeB"] ?></b>
	<br>
	<table class="w3-text-black" >
		<tr>
			<td>Nama</td>
			<td>:</td>
			<td style="text-transform: capitalize;"><?= $dataKdes["nama"] ?></td>
		</tr>
		<tr>
			<td>Jabatan</td>
			<td>:</td>
			<td style="text-transform: capitalize;"><?= $dataKdes["jabatan"] ?></td>
		</tr>
		<tr>
			<td>Alamat</td>
			<td>:</td>
			<td style="text-transform: capitalize;"><?= $dataKdes["alamat"] ?></td>
		</tr>
		<tr>
			<td>Pendidikan</td>
			<td>: </td>
			<td style="text-transform: capitalize;"><?= $dataKdes["pendidikan"] ?></td>
		</tr>
		<tr>
			<td>Temp Tgl Lahir</td>
			<td>:</td>
			<td style="text-transform: capitalize;"><?= $dataKdes["tpl"].", ".$dataSek["tgl"] ?></td>
		</tr>
	</table>

</div>


<?php 

$querydbg2 = "SELECT * FROM aparat 
	WHERE desa='$iddesa' 
	AND jabatan!='kepala desa' 
	AND jabatan!='ketua bpd' 
	AND kategori='$kategori' 
	AND Periode='$periode'";

$resultperson = mysqli_query($conn, $querydbg2);


while ( $data2=mysqli_fetch_assoc($resultperson)) { ?>
	
	<div class="jarak20"></div>
<div class="cardPersonal w3-theme-l3 w3-card">
	<div class="bingkaiAnggota ">
		<img src="../img/<?= $data2['foto']; ?>" alt="" class="gambarUmum">
	</div>

	<table class="w3-small" >
		<tr>
			<td>Nama</td>
			<td>:</td>
			<td style="text-transform: capitalize;"><?= $data2["nama"] ?></td>
		</tr>
		<tr>
			<td>Jabatan</td>
			<td>:</td>
			<td style="text-transform: capitalize;"><?= $data2["jabatan"] ?></td>
		</tr>
		<tr>
			<td>Alamat</td>
			<td>: </td>
			<td style="text-transform: capitalize;"><?= $data2["alamat"] ?></td>
		</tr>
		<tr>
			<td>Pendidikan</td>
			<td>: </td>
			<td style="text-transform: capitalize;"><?= $data2["pendidikan"] ?></td>
		</tr>
		<tr>
			<td>Temp Tgl Lahir</td>
			<td>:</td>
			<td style="text-transform: capitalize;"><?= $data2["tpl"].",".$data2["tgl"] ?></td>
		</tr>
	</table>
</div>


<?php } ?>

<?php require '../view/bottom_body.php' ?>