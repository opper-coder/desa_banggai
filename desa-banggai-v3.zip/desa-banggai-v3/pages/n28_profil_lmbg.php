<?php 	
	$judulHalaman = "PROFIL LEMBAGA";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$hrefBack = "n21_profil_kelembagaan.php?theme=$theme&iddesa=$iddesa";
	$kategori = $_GET['kategori'];
 
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
?>



<!-- <a href="../pages/baca_inspirasi.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>" >buka halaman dan kirim get</a> -->
<div class="jarak40"></div>
<div class="jarak20"></div>

<div class="containerBaca w3-round">
<?php 
$conn = mysqli_connect("localhost","root","","desa_banggai");
$queryAcc	= "SELECT * FROM lembaga WHERE desa='$iddesa' AND kategori='$kategori'";
$resultAcc	= mysqli_query($conn, $queryAcc); 

$i=1;

while ($data = mysqli_fetch_assoc($resultAcc)):?>
	<style>
	#accord<?= $i; ?>{
		height: 0;
		overflow: hidden;
	}
	#accord<?= $i; ?>:target{
		height: auto;
	}
	</style>

	<a href="#accord<?php echo $i; ?>" class="namaLmbg w3-theme-l2"><?= $data['nmlembaga']; ?></a>
		<div id="accord<?php echo $i; ?>" class="w3-border w3-white isiaccord">
		<div class="jarak16"></div>
		<?= $data['deskripsi']; ?>
		<br>
		<p>berikut data data mengenai lembaga tersebut:</p>
		
		<div class="jarak16"></div>
			<table class="w3-table w3-striped w3-border w3-round">
				<tr>
					<td>Nama Lembaga:</td>
					<td><?= $data['nmlembaga']; ?></td>
				</tr>
				<tr>
					<td>Tahun berdiri:</td>
					<td><?= $data['thnberdiri']; ?></td>
				</tr>
				<tr>
					<td>Sekretariat:</td>
					<td><?= $data['sekretariat']; ?></td>
				</tr>
				<tr>
					<td>Kordinator Bpk/Ibu:</td>
					<td><?= $data['koordinator']; ?></td>
				</tr>
				<tr>
					<td>Jumlah Pengurus:</td>
					<td><?= $data['jumpengurus']; ?></td>
				</tr>
				<tr>
					<td>Jumlah Anggota:</td>
					<td><?= $data['jumanggota']; ?></td>
				</tr>
			</table>
			<div class="jarak16"></div>
		</div>

<?php $i++; endwhile ?>
</div>



<!-- -------akhir halaman -->
	<?php require '../view/bottom_body.php' ?>