<?php 
// CATATAN MAP CODE DAN PSEUDO CODE

// halaman ini menerima data GET dan POSH
// GET = id layanan 
// POST = data surat keluar, data desa global, datafield dari form, iddesa, 

// semua data suratkeluar di kumpul dalam var $data
// $datafield bisa di explode di dalam function / atau pakai global
// $data desa di gunakan untuk data di function / atau pakai global
// $desa1 untuk data layanan untuk desa tertentu

// picu fungsi cetak surat send, id layanan dan data
	// pilih layanan berdasar id layanan, kirim data
		// pilih surat yang ada dalam layanan, kirim data
			// bikin surat 
				// bikin struktur surat
// 


// PSEUDO CODE 

// function runsurat(){pilihlayanan}
// function layanan1(){sktm, skk, sku}
// function sktm(){kop, nosurat, body}
// function kop(){no surat}
// -----
// runsurat()
 ?>

<!-- ================================================================ -->

<?php 
require_once "../core/init.php";
require('../fpdf182/fpdf.php');
ob_start();

// _______ variabel halaman utama _____

	$idlayanan 	= $_POST["cetak"];
	$data 		= query("SELECT * FROM suratkeluar WHERE id='$idlayanan'");
	
	$iddesa 	= $data['desa'];
	$datafield 	= explode(",", $data['data']);	// data array num	
	
	$nikwarga	= $data["nikpemohon"];
	$datawarga 	= query("SELECT * FROM penduduk WHERE desa='$iddesa' AND nik='$nikwarga'");
	

	$datadesa 	= query("SELECT * FROM globaldesa WHERE desa='$iddesa'");
	$tahun 		= date('Y');

	$desa1	= $datadesa['desa'];


	// var_dump($datawarga);
// ____________________________________
// _____________ Utylity ______________

function runsurat($idsurat, $data){
	switch ($idsurat){
		case '1':
			pilih1sktm($data);
			break;
		case '2':
			pilih2kawinislam($data);
			break;
		case '3':
			pilih3domisili($data);
			break;
		case '4':
			pilih4kredit($data);
			break;
		case '5':
			pilih5skusaha($data);
			break;
		case '6':
			pilih6sjb($data);
			break;
		case '7':
			pilih7sikeramaian($data);
			break;
		case '8':
			pilih8skuasa($data);
			break;
		case '9':
			pilih9skkb($data);
			break;
		case '10':
			pilih10skpindah($data);
			break;
		case '11':
			pilih11spengantar($data);
			break;
		case '12':
			pilih12sahliwaris($data);
			break;
		case '13':
			pilih13sktmbpjs($data);
			break;
		case '14':
			pilih14sktmpend($data);
			break;
		case '15':
			pilih15kawinkrhd($data);
			break;
		case '16':
			pilih16spernyataan($data);
			break;
		case '17':
			latihan17($data);
			break;
		case '18':
			latihan18($data);
			break;
		default:
			echo "Request layanan belum tersedia...!";
			break;
	}
}

// ----- fungsi pilih surat -----
function pilih1sktm($data){
	sktm($data, 1);
}

function pilih2kawinislam($data){
	global $pdf;
	n1($data, 1);
	$pdf->AddPage();
	n2($data, 2);
	$pdf->AddPage();
	n3($data, 3);
 	$pdf->AddPage();
	n4($data, 4);
	$pdf->AddPage();
	n5($data, 5);
	$pdf->AddPage();
	n6($data, 6);
	// $pdf->AddPage();
	// n7($data, 7);
	$pdf->AddPage();
	n8($data, 8);
	$pdf->AddPage();
	sktt($data, 9);
}

function pilih3domisili($data){
	domisili($data, 1);
}

function pilih4kredit($data){
	spermohonankreditusaha($data, 1);
	skhasilortu($data, 2);
	skusaha($data, 3);
	skkb($data, 4);
	skuasa($data, 5);
}

function pilih5skusaha($data){
	skusaha($data, 1);
}

function pilih6sjb($data){
	sjb($data, 1);
}

function pilih7sikeramaian($data){
	spengantar($data, 1);
	spernyataan($data, 2);
}

function pilih8skuasa($data){
	skuasa($data, 1);
}

function pilih9skkb($data){
	skkb($data, 1);
}

function pilih10skpindah($data){
	skpindah($data, 1);
}

function pilih11spengantar($data){
	skpengantar($data, 1);
}

function pilih12sahliwaris($data){
	sahliwaris($data, 1);
}

function pilih13sktmbpjs($data){
	sktmbpjs($data, 1);
}

function pilih14sktmpend($data){
	sktmpend($data, 1);
}

function pilih15kawinkrhd($data){
	skhubdarah($data, 1);
	skbelumnikah($data, 2);
}

function pilih16spernyataan($data){
	spernyataan($data, 1);
}
// _________________________________
// ____________ mpdf _______________

// _________________________________
// _____________ CSS _______________
$css = '<style>
	span{
		line-height: 1.1;
	}
</style>';
// __________________________________

// ----- variabel fpdf ----- 
$legal = [215, 330];
$pdf = new FPDF('P','mm',$legal);

// ----- jalankan fungsi utama fpdf -----
$pdf->SetMargins(20, 18 ,20);
$pdf->AddPage();


// ___________ CONTOH HTML __________




// ////////////////////////////////////////

// $izza	= ucwords("adad apa ini");
// $izza	= strtolower("adad apa ini");
// $izza	= ucfirst("adad apa ini");
// $izza	= mb_strtoupper("adad apa ini");





// ////////////////////////////////////////



// _________ TRIGGER SURAT __________
runsurat($data['idlayanan'], $data);
// __________________________________..............
// ____________ PENUTUP _____________
$pdf->Output("Doc-Banggai","I");
// ==================================================================
?>

