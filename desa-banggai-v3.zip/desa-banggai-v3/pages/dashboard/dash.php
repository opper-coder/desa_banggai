<?php 	
	// $theme = $_GET['theme'];
	// $iddesa = $_GET['iddesa'];
	// $hrefBack = "../origin/saiti.php";
 
	require '../../view/top_body.php';
	require '../../view/center_body.php';

?>

<?php

// dasboard
// bikin accordion
// crud
// login/user
// badge notif

?>
<div class="contdash">
	<div class="barkanan">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid porro molestias sed quo est praesentium aspernatur et molestiae, optio, veniam, voluptate sint officiis similique a vel non commodi ab in?</div>
	<div class="barkiri">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci facilis reprehenderit, blanditiis dicta minima placeat ratione pariatur qui odio veniam! Aliquid eligendi vitae sapiente. Modi obcaecati expedita reiciendis odio cumque!</div>
</div>