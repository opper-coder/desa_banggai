<?php 
// ini halaman cetak halaman surat

// akan mencetak surat sesuai 
// 1. layanan	= dari post
// 2. lampiran dibuat di fungsi surat dari db
// 3. data pengguna = dari user 
// 4. nomor surat = dari function halaman 
// 5. pembuat = admin
// 6. tanggal terbit/cetak = dari function halaman

// 7. tombol cetak di bawah
// 8. tombol home di bawah
// 9. tombol ukuran kertas

// ----- ALGORITMA -----
// 1. USER request di form = data desa, data form, data pemohon, data sender
// 2. masuk ke SQL
// 3. ADMIN buka dashboard = dapat inbox, buka layanan, klik nama, klik preview
// 4. data yang di bawa = desa, admin, layanan, user, pemohon.
// 6. 
// 7. 
// 8. 
// 9. 
// 10. 
// ----- INSTRUKSI -----

// 1. isi global pada tiap funsi pilih surat *
// 2. isi jumlah surat yang diperlukan dalam function *
// 3. 

 ?>
<?php
// _________ hubungan halaman _________
require "../core/init.php";
require "../view/top_body.php";
require "../view/center_body.php";
// ____________________________________
// _______ variabel halaman utama _____

	$idlayanan 	= $_POST["cetak"];
	$data 		= query("SELECT * FROM suratkeluar WHERE id='$idlayanan'");
	
	$iddesa 	= $data['desa'];
	$datafield 	= explode(",", $data['data']);	// data array num
	
	$datadesa 	= query("SELECT * FROM globaldesa WHERE desa='$iddesa'");
	$tahun 		= date('Y');
// ____________________________________




// ??????????????? coba coba ????????????????


function latihan17(){echo "halo 17";}
function latihan18(){echo "halo 18";}
echo "<br>";


// for ($i=$tahun; $i < 2022; $i++) { 
// 	for ($j=1; $j < 5; $j++) { 
// 		echo "coba" . $j . "<br>";
// 	}
// }

nosuratsaiti($data, 3);
	
	// $tahun = query("SELECT YEAR(tglterbit) FROM suratkeluar WHERE desa='$iddesa' AND id=1");
	// $sekarang = date('Y');

	// var_dump($sekarang);
	// echo "<br>";
	// var_dump($tahun['YEAR(tglterbit)']);

// ????????????????????????????????????????????



// _____________ Utylity ______________

function runsurat($idsurat, $data){
	switch ($idsurat){
		case '1':
			pilih1sktm($data);
			break;
		case '2':
			pilih2kawinislam($data);
			break;
		case '3':
			pilih3domisili($data);
			break;
		case '4':
			pilih4kredit($data);
			break;
		case '5':
			pilih5skusaha($data);
			break;
		case '6':
			pilih6sjb($data);
			break;
		case '7':
			pilih7sikeramaian($data);
			break;
		case '8':
			pilih8skuasa($data);
			break;
		case '9':
			pilih9skkb($data);
			break;
		case '10':
			pilih10skpindah($data);
			break;
		case '11':
			pilih11spengantar($data);
			break;
		case '12':
			pilih12sahliwaris($data);
			break;
		case '13':
			pilih13sktmbpjs($data);
			break;
		case '14':
			pilih14sktmpend($data);
			break;
		case '15':
			pilih15kawinkrhd($data);
			break;
		case '16':
			pilih16spernyataan($data);
			break;
		case '17':
			latihan17($data);
			break;
		case '18':
			latihan18($data);
			break;
		default:
			echo "Request layanan belum tersedia...!";
			break;
	}
}

// ----- fungsi pilih surat -----
function pilih1sktm($data){
	sktm($data, 1);
}

function pilih2kawinislam($data){
	n1($data, 1);
	n2($data, 2);
	n3($data, 3);
	n4($data, 4);
	n5($data, 5);
	n6($data, 6);
	n7($data, 7);
	n8($data, 8);
	sktt($data, 9);
}

function pilih3domisili($data){
	domisili($data, 1);
}

function pilih4kredit($data){
	spermohonankreditusaha($data, 1);
	skhasilortu($data, 2);
	skusaha($data, 3);
	skkb($data, 4);
	skuasa($data, 5);
}

function pilih5skusaha($data){
	skusaha($data, 1);
}

function pilih6sjb($data){
	sjb($data, 1);
}

function pilih7sikeramaian($data){
	spengantar($data, 1);
	spernyataan($data, 2);
}

function pilih8skuasa($data){
	skuasa($data, 1);
}

function pilih9skkb($data){
	skkb($data, 1);
}

function pilih10skpindah($data){
	skpindah($data, 1);
}

function pilih11spengantar($data){
	skpengantar($data, 1);
}

function pilih12sahliwaris($data){
	sahliwaris($data, 1);
}

function pilih13sktmbpjs($data){
	sktmbpjs($data, 1);
}

function pilih14sktmpend($data){
	sktmpend($data, 1);
}

function pilih15kawinkrhd($data){
	skhubdarah($data, 1);
	skbelumnikah($data, 2);
}

function pilih16spernyataan($data){
	spernyataan($data, 1);
}

// ----------------------------------





// ==================================================
 ?>
 <div class="kertasA4">
 	<?php 
 		





 		kopsurat($datadesa);
 		perihal(2, "coba coba"); // no surat, lampiran
 		kepada( "bupati banggai", "Pemaerintah daerah 2 banggai", "Banggai");


// require_once __DIR__ . '../../mpdf/vendor/autoload.php';

// $mpdf = new \Mpdf\Mpdf();
// $mpdf->WriteHTML('<h1>Hello world!</h1>');
// $mpdf->Output();





 	 ?>
 </div>
<?php
	runsurat($data["idlayanan"], $data);
?>

<!-- bagian tombol halaman ini -->
<div>
	<div class="jarak20"></div>
	<form action="">
		<label for="a4">kertas A4:</label>
		<input type="radio" name="kertas" value="a4" id="a4">
		<br>
		<label for="legal">kertas legal:</label>
		<input type="radio" name="kertas" value="legal" id="legal">
		<br>
		<button type="submit" name="print" class="w3-button w3-blue"> print</button>
	</form>
	<br>
	<form action="../dashboard.php" method="">
		<button class="w3-button w3-blue">Dashboard</button>
	</form>
</div>
 <?php // =========================================== ?>