<?php 	
	$judulHalaman = "STATUS LAYANAN";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$hrefBack = "../origin/saiti.php";
	$gambarJumbotron = "../assets/saiti/ilustrasi/layanan.jpg";
	require '../view/top_body.php';
	require $theme;
	require '../view/navback.php';
	require '../view/jumbotron.php';
	require '../view/center_body.php';
	require '../core/init.php';
// ============== halaman butuh login ===========	
if( !isset($_SESSION['user']) ){
	die('anda belum login');
	header ( 'Location: ../functions/login.php' );
}
// ============== /halaman butuh login ===========  ?>
<div class="jarak20"></div>
<div class="containerBaca">
	<?php 
	$sender	 	= $_SESSION['user'];
	$datastatus = query("SELECT verifikasi FROM suratkeluar WHERE desa='$iddesa' AND sender='$sender' ");
	$status  	= status($datastatus);
	$conn 			= mysqli_connect("localhost","root","","desa_banggai");
	$querylayanan	= "SELECT * FROM suratkeluar WHERE desa='$iddesa' AND sender='$sender' ORDER BY tglmasuk DESC";
	$querylayanan2	= "SELECT * FROM suratkeluar WHERE desa='$iddesa' AND sender='$sender' AND verifikasi= 4 ORDER BY tglmasuk DESC";
	$resultlayanan 	= mysqli_query($conn, $querylayanan); // cari suratklr,sender,ordertglmask
	$resultlayanan2 	= mysqli_query($conn, $querylayanan2); // cari suratklr,sender,ordertglmask
 	?>

<b class="containerBaca">Permohonan sedang di proses</b>
<section class="containerBaca">

<?php 
	while ($data = mysqli_fetch_assoc($resultlayanan)):?>
			<div class="w3-white w3-card w3-round w3-padding w3-small marginB10" >
					<?php 
						$idlayanan = $data["idlayanan"];
					 	$namalayanan	= query( "SELECT * FROM layanan WHERE id = '$idlayanan'" );
				 		$idsurat = $data["id"];
					 	$perihal = query( "SELECT * FROM suratkeluar WHERE  desa ='$iddesa' AND sender='$sender' AND id = '$idsurat'" );
					 	$dataperihal = explode(",", $perihal["data"]);
					 	$dataperihal2 = $dataperihal[1];
					 	$dataperihal3 = explode("=>", $dataperihal2);
					 	$dataperihal4 = $dataperihal3[1];
					?>
				<p class="datastatus "><b><?= $namalayanan["nama"]; ?></b></p>
				<div class="kotakstatus">
					<p class="">perihal : <b><?= $dataperihal4 ;?></b></p>
					<p class="">Tanggal masuk : <b><?= $data["tglmasuk"] ;?></b></p>
					<p class="">Pemohon : <b><?= $data["pemohon"] ;?></b></p>
					<p class="">Pengirim : <b><?= $data["sender"] ;?></b></p>
					<p class="">Status permohonan : <b><?= status($datastatus); ?></b></p>
					<p><a href="" class="w3-button w3-tiny w3-theme w3-round">Chat!</a></p>
				</div>
				<p class="">Pesan : <b><?= $data["pesan"]; ?></b></p>	
			</div>
		<?php endwhile ?>
</div>
</section>
<!-- ---------------------------------------------------------------------- -->
<b class="containerBaca">Permohonan yang sudah selesai</b>
<section class="containerBaca">
	
<?php 
	while ($data2 = mysqli_fetch_assoc($resultlayanan2)):?>
			<div class="w3-white w3-card w3-round w3-padding w3-small marginB10" >
					<?php 
						$idlayanan = $data2["idlayanan"];
					 	$namalayanan	= query( "SELECT * FROM layanan WHERE id = '$idlayanan'" );
				 		$idsurat = $data2["id"];
					 	$perihal = query( "SELECT * FROM suratkeluar WHERE  desa ='$iddesa' AND sender='$sender' AND id = '$idsurat'" );
					 	$dataperihal = explode(",", $perihal["data"]);
					 	$dataperihal2 = $dataperihal[1];
					 	$dataperihal3 = explode("=>", $dataperihal2);
					 	$dataperihal4 = $dataperihal3[1];
					?>
				<p class="datastatus "><b><?= $namalayanan["nama"]; ?></b></p>
				<div class="kotakstatus">
					<p class="">perihal : <b><?= $dataperihal4 ;?></b></p>
					<p class="">Tanggal masuk : <b><?= $data2["tglmasuk"] ;?></b></p>
					<p class="">Pemohon : <b><?= $data2["pemohon"] ;?></b></p>
					<p class="">Pengirim : <b><?= $data2["sender"] ;?></b></p>
					<p class="">Status permohonan : <b><?= status($datastatus); ?></b></p>
					<p><a href="" class="w3-button w3-tiny w3-theme w3-round">Chat!</a></p>
				</div>
				<p class="">Pesan : <b><?= $data2["pesan"]; ?></b></p>	
			</div>
		<?php endwhile ?>
</div>

</section>

<?php require '../view/bottom_body.php' ?>