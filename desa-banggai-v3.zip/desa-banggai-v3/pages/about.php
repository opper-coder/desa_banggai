<?php 	
	$judulHalaman = "TENTANG APLIKASI";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$hrefBack = "../origin/saiti.php";
 
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
?>
<!-- <a href="../pages/baca_inspirasi.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>" >buka halaman dan kirim get</a> -->

<div class="jarak40"></div>
<div class="jarak20"></div>
<!-- ========= latihan ======= -->
<div class="containerBaca w3-sand w3-padding w3-border w3-round-large w3-card">
<form action="" method="post">
	<label for="masukan">masukan :</label>
	<input type="text" name="masukan" id="masukan">
	<button type="input">send..!</button>
</form>

<br>

<?php $ada = strval($_POST["masukan"]) . "x"; ?>
<h4>tampilkan isi input: <?php var_dump ($ada); ?></h4>

<p>tampilkan potongan : <?php $ada2 = preg_replace(["/\D/"],"","11112222333344445555x"); var_dump( $ada2 ); ?></p>

</div><br>
<!-- ================ -->
<div class="containerBaca w3-sand w3-padding w3-border w3-round-large w3-card">
	<b>Tentang Aplikasi</b>
	<hr>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus sapiente commodi soluta perspiciatis possimus distinctio ab autem id rem nihil eum eaque itaque deserunt aliquam repellendus eveniet voluptates iusto sed, fugit cumque, maiores repellat sint est. Nulla minima quis exercitationem,<br><br> eveniet autem, suscipit doloremque beatae accusantium, commodi excepturi nobis amet facere. Sed, commodi, numquam! Similique sed itaque est molestiae aliquam magni, dolores inventore esse eos quaerat commodi minus mollitia. Voluptas officia expedita eius dicta in pariatur, odio nisi, sunt nesciunt sapiente veritatis adipisci est beatae aperiam nihil fugit recusandae quibusdam! Totam voluptatem modi rem optio aperiam voluptates voluptas tempore aliquam?
	</p><br>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. A suscipit labore, aut ea dolores eveniet aperiam iste temporibus repellat molestias, optio dignissimos voluptas, voluptatum! Officiis ipsum dicta eaque incidunt aut.</p>
	<hr>
	<p class="w3-small w3-indigo w3-padding">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Similique iure distinctio, aliquid est aut veritatis totam labore nemo deleniti. </p>
	<div class="jarak10"></div>
</div>


	<?php require '../view/bottom_body.php' ?>




	<?php  

// ============================================

/* 
> sktm persalinan
pengantar perkawinan
> domisili
>permohonan kredit
> sku
sjb
izin keramaian
> skuasa
> skkb
sk pindah
spengantar
> sk ahli waris
>sktm bpjs
>sktm pend
>sk perkawinan hindu/kristen

-------------



sktm persalinan
		nik=>NIK yang bersangkutan,
		perihal=>untuk perihal


surat perkawinan islam
	Nik 
	perihal
	status perkawinan
	berapa istri
	nama istri terdahulu

	$field = [
		nik=>NIK yang bersangkutan,
		perihal=>untuk perihal
	];
	

Surat keterangan domisili
	nik pemohon
	perihal

	$field = [
		nik=>NIK yang bersangkutan, 
		perihal=>untuk perihal
	];

surat keterangan usaha
	perihal
	nik pemohon
	pemilik usaha
	alamat tempat usaha

	$field = [
		nik=>NIK yang bersangkutan,
		perihal=>untuk perihal,
		usaha=>Jenis Usaha,
		alamat=>Alamat Usaha
	];

surat kuasa
	nik
	perihal
	sertifikat atas nama:
	no sertifikat/AJB/akta hibah
	tgl akta
	luas:
	alamat akta:

	utara:
	timur
	selatan
	barat

	BANK tujuan: /// perikasa di pdf perlu di tentukan banknya

	memberi kuasa pada:
	nama:
	ttl
	pekerjaan
	alamat


	$field = [
		nik=>NIK yang bersangkutan, 
		perihal=>untuk perihal,
		nomor=>No. Sertifikat/AJB/Akta Hibah,
		tgl=>Tanggal Akta/Surat,
		luas=>Luas Tanah/Agunan, 
		alamat=>alamat akta
	];

	$field	= [
		utara=>batas utara,
		timur=>batas timur,
		selatan=>batas selatan,
		barat=>batas barat
	];

	$field = [
		bank=>Bank tujuan,
		kuasakan=>Memberi kuasa kepada,
		nama=>Nama,
		ttl=>Tempat dan Tgl lahir,
		pekerjaan=>Pekerjaan,
		alamat=>Alamat
	];


surat kelakuan baik
	nik
	perihal

	$field = [
		nik=>NIK yang bersangkutan,
		perihal=>untuk perihal
	];
*/

==================================================

/*

FITUR YANG BELUM BERJALAN 

HOME
	TENTANG APLIKASI
		data saja
	STATUS LAYANAN
		tampilan list
		queri
		logic
	PESAN
		tabel data base
		sistem akun
		sistem info dan ststus pesan
		hapus pesan
	LOGIN AKUN
		pengaturan
		inbox pesan
		status layanan
	PENGUMUMAN
		data list
		data isi
	LAYANAN
		layanan pemdes
			keterangan
		layanan mitra
			list 
		layanan integrasi
			list aja
		inspirasi
			berita

	STATISTIK
		profil desa
			kelembagaan
				list
				periode
				tabel
			program desa
				tabel tahun
				tabel rincian
			galeri
				foto dan database
			hiburan
				foto dan database
			arsip desa
				list 
				rincian
		statistik sarana umum
			list 
			tabel rincian
		aset desa 
			list 
			tabel rincian
		kependudukan
			list
			tabel rincian

	APBDES
		data base
	BERITA
		list
		tabel rincian
	MITRA
		list
		tabel rincian

=================

TAMPILAN
	perbaikan list
	icon2
	di list kelembagaan


*/

PRIORITAS

=====
STATUS LAYANAN
		tampilan list --fix
		queri --fix
		logic --fix
		layanan inspirasi 
=====
APBDES
		data base --fix
		halaman lanjutan --fix		 
=====
STATISTIK
profil desa
	kelembagaan
		list --fix	
		periode --fix	
		tabel --fix	
		rt --fix
		lembaga --fix
	program desa
		tabel tahun -->
		tabel rincian -->
	galeri
		foto dan database -->
	hiburan
		foto dan database -->
	arsip desa
		list -->
		rincian -->
statistik sarana umum
	list 
	tabel rincian
aset desa 
	list 
	tabel rincian
kependudukan
	list 
	tabel rincian
-----
TABLE APARAT
id ---
nama ---
alamat---
ttl---
jabatan---
pendidikan---
periode---
telpon---
desa---

TABLE KELEMBAGAAN : kelembagaanmasyarakat / kelembagaan
	id ---
	nmlembaga ---
	kategori ---
	deskripsi ---
	thnberdiri ---
	sekretariat ---
	koordinator ---
	jumpengurus ---
	jumanggota ---
	periode ---
	desa ---

-----
=====
DASHBOARD
	input data APBDES
	input data lembaga
	input data aparat
	
=====
INTERNET
upload gambar
download file
hosting

=======

jumlah kk ---

===============================

kopi data ke mysql

?>


<?php 
quesioner surat:
-----
SK AHLI WARIS
nik	
perihal

nama almarhum:
jenis kelamin almarhum
status keluarga
alamat almarhum
tgl meninggal
nama istri
jumlah anak
nama anak anak 
ttl anak anak

saksi1 nama umur alamat pekerjaan alamat
saksi2 nama umur alamat pekerjaan alamat
camat setempat
--
nik=>nik,	
perihal=>perihal,
namaalm=>nama almarhum,
jkelalm=>jenis kelamin almarhum,
sttskel=>status keluarga,
alamatalm=>alamat almarhum,
tglwft=>tgl meninggal,
namaistri=>nama istri,
janak=>jumlah anak,
??????
nama anak anak,
ttl anak anak,
???????
nms1=>nama saksi 1,
umurs1=>umur saksi 1,  
alamats1=>alamat saksi 1,
pekerjaans1=>pekerjaan saksi 1, 
alamats1=>alamat saksi 1,
nms2=>nama saksi 2,
umurs2=>umur saksi 2, 
alamats2=>alamat saksi 2,
pekerjaans2=>pekerjaan saksi 2, 
alamats2=>alamat saksi 2,
camat=>camat setempa
 ?>

------

<?php 
PERMOHONAN KREDIT

kepala kantor BRI BUNTA unit cab

nik
perihal

nama lengkap
nama panggilan
ttl
jenis kelamin
pekerjaan
sektor usaha
alamat 
ibu kandung
no telpon
besar keperluan
angsuran per
selama x bulan
lampiran:
--
kepala kantor BRI BUNTA unit cab

nik=>nik
perihal=>perihal
nama=>nama lengkap
panggilan=>nama panggilan
templahir=>tempat lahir
tgllahir=>tanggal lahir
jkelamin=>jenis kelamin
pekerjaan=>pekerjaan
usaha=>sektor usaha
alamat=>alamat
ibu=>ibu kandung
hp=>no telpon
jumlkredit=>besar keperluan
angduran=>angsuran per
jumlbulan=>selama x bulan
------


SURAT PERNYATAAN
	
	nik
	perihal

	nama 
	ttl
	alamat
--
	nik=>nik
	perihal=>perihal
	nama=>nama
	templahir=>tempat lahir
	tgllahir=>tanggal lahir
	alamat=>alamat
-->
nik
perihal

SURAT KELAKUAN BAIK
	
	nik
	perihal

	nama
	jabatan

		nama 
		ttl
		jenis kel
		pekerjaan
		agama
		sukun dan warga negara
		alamat
--
	nik=>nik
	perihal=>perihal

	nama=>nama
	jabatan=>jabatan

	nama=>nama 
	tgllahir=>tanggal lahir
	templahir=>tempat lahir
	jkelamin=>jenis kelamin
	pekerjaan=>pekerjaan
	agama=>agama
	suku=>suku 
	WN=>warga negara
	alamat=>alamat
-->
	nik
	perihal


SURAT KETERANGAN USAHA
	
	nik
	perihal

	nama kades
	jabatan 

	nama
	ttl
	pekerjaaan
	alamat

	memiliki usaha:
	wilayah pemasaran
	sarana tunjangan : 1 2 3 
	lokasi sarana 

-->
	nik
	perihal

	pemilik usaha
	wilayah pemasaran
	sarana tunjangan 1
	sarana tunjangan 2
	sarana tunjangan 3
	sarana tunjangan 4
	lokasi sarana

?>

<?php 
-----
SKTM persalinan
	
	nama 
	jabatan

	nik 
	perihal

	nama 
	jenis kelamin
	ttl
	nik
	agama
	pekerjaan
	alamat
	suami dari :
-->
	nik 
	perihal
	suami dari :

SKTM BPJS

	nama
	ttl/umur
	NIK
	nomor kk
	status hub dalam kel
	alamat

	tabel susunan keluarga
	no 
	nama 
	NIK
	jenis kel
	ttl
	status hub kel
-->
	nik 
	perihal

-----
SKTM SEKOLAH

	nama 
	jabatan

	nik 
	perihal

	nama 
	jenis kelamin
	ttl
	nik
	agama
	pekerjaan
	alamat

	ortu 
		nama
		jkelamin
		ttl
		nik
		agama
		alamat

-->
	nik 
	perihal



 ?>
 <?php 
-----

SK BELUM PERNAH MENIKAH
	
	calon
nama
ttl
nik
agama
pekerjaan
alamat
	dan
nama
ttl
nik
agama
pekerjaan
alamat

-->
nik
perihal

nama calon pasangan:
ttl
nik
agama
pekerjaan
alamat


SK TIDAK ADA HUBUNGAN DARAH

	nama 
	jabatan

	nama
	ttl
	nik
	agama
	pekerjaan
	alamat
		dan
	nama
	ttl
	nik
	agama
	pekerjaan
	alamat

-->

nik 
perihal

	nama calon pasangan
	ttl
	nik
	agama
	pekerjaan
	alamat
 ?>
-----
<?php 
DARI PERTANYAAN BERULANG AKAN DIRINGKAS DI DAFTAR QUESIONER 
NANTI AKAN DI FORMULASIKAN

N1
SURAT PENGANTAR PERKAWINAN
nik 
perihal

nama 
jenis kelamin
ttl
warga negara 
agama
pekerjaan 
tempat tinggal
bin
status perkawinan
nama istri terdahulu

ortu dari:

I
nama dan alias
NIK
ttl
kewargaan
agama 
pekerjaann 
alamat

II
nama dan alias
NIK
ttl
kewargaan
agama 
pekerjaann 
alamat

==
N2
nama calon suami
nama calon istri
tgl acara
pukul
tempat desa acara: kediaman
kec 
kab 

==
N3
SURAT PERSETUJUAN MEMPELAI

calon suami
	nama alias
	bin
	ttl
	WN
	agama
	pekerjaan
	tempat tinggal

calon istri
	nama alias
	bin
	ttl
	WN
	agama
	pekerjaan
	tempat tinggal

==
N4
SURAT IZIN ORTU

AYAH
	nama dan alias
	bin
	NIK
	ttl
	kewargaan
	agama 
	pekerjaann 
	alamat

IBU
	nama dan alias
	bin
	NIK
	ttl
	kewargaan
	agama 
	pekerjaann 
	alamat

ortu dari:

perempuan I
	nama dan alias
	bin
	NIK
	ttl
	kewargaan
	agama 
	pekerjaann 
	alamat

laki2 II
	nama dan alias
	bin
	NIK
	ttl
	kewargaan
	agama 
	pekerjaann 
	alamat

==
N5

	ayah calon pengantin
	suami
	istri

==
N6
pelapor
	nama dan alias
	bin
	ttl
	kewargaan
	agama 
	pekerjaann 
	alamat
	tempat tinggal terakhir
yang meninggal
	nama dan alias
	bin
	ttl
	kewargaan
	agama 
	pekerjaann 
	alamat
	tempat tinggal terakhir

==
N7

==
N8
 hari tanggal bulan tahun
 cal suami
 cal istri
 cal wali
 akad:
 	hari/tgl	masehi
	waktu		hijriyah
 nama petugas pemeriksa
 jabatan


==

?>

<?php  
------
SK domisili

nama
jabatan

nama
	ttl
	NIK
	j kelamin
	agama 
	status kawin
	pekerjaan
	alamat
	
?>