<?php 	
	$judulHalaman = "KATEGORI KELEMBAGAAN";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$gambarJumbotron = "../assets/ilustrasi/baca.jpg";
	$hrefBack = "n20_profil_desa.php?theme=$theme&iddesa=$iddesa";
 
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
	require '../view/jumbotron.php';
	require '../core/init.php';
?>



<?php // ============== halaman butuh login ===========

if( !isset($_SESSION['user']) ){
	// die('anda belum login');
	header ( 'Location: ../functions/register.php' );
}

// ============== /halaman butuh login ===========  ?>



<!-- <a href="../pages/baca_inspirasi.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>" >buka halaman dan kirim get</a> -->

<p class="jarak20"></p>
<p class="cardBlock">
	<b>Lembaga Pemerintah</b>
	<p class="jarak10"></p>
	<p class="dftrlembaga " >
		<a href="n27_profil_periode.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&kategori=pemdes">Pemerintah Desa</a>
		<a href="n27_profil_periode.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&kategori=bpd">BPD</a>
	</p>
</p>

<p class="jarak10"></p>
<p class="cardBlock">
	<b>Lembaga Keagamaan</b>
	<p class="jarak10"></p>
	<p class="dftrlembaga " >	
		<a href="n28_profil_lmbg.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&kategori=yasin">Jamaah Yasinan</a>
		<a href="n28_profil_lmbg.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&kategori=taklim">Jamaah Ta'lim</a>
		<a href="n28_profil_lmbg.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&kategori=hindu">persatuan Hindu</a>
		<a href="n28_profil_lmbg.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&kategori=Kristen">persatuan Kristen</a>
	</p>
</p>

<p class="jarak10"></p>
<p class="cardBlock">
	<b>Lembaga Kemasyarakatan</b>
	<p class="jarak10"></p>
	<p class="dftrlembaga " >
		<a href="n28_profil_lmbg.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&kategori=bumdes">BUMDES</a>
		<a href="n28_profil_lmbg.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&kategori=pkk">PKK</a>
		<a href="n28_profil_lmbg.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&kategori=taruna">Karang Taruna</a>
		<a href="n28_profil_lmbg.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&kategori=posyandu">Kader POSYANDU</a>
		<a href="n28_profil_lmbg.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&kategori=tani">Kelompok Tani</a>
		<a href="n28_profil_lmbg.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&kategori=Seni">Seni dan budaya</a>
	</p>
</p>

	<?php require '../view/bottom_body.php' ?>