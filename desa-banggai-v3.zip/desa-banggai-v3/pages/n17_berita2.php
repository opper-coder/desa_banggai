<?php 	
	$judulHalaman = "ISI BERITA";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$gambarJumbotron = "../assets/ilustrasi/baca.jpg";
	$idberita = $_GET["idberita"];
	$hrefBack = "n16_berita.php?theme=$theme&iddesa=$iddesa";
 
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
	require '../view/jumbotron.php';
	require '../core/init.php';
?>
<!-- body berita -->
<?php 
$queryberita = "SELECT * FROM artikeltb WHERE desa='$iddesa' AND type='berita' AND id='$idberita'";
$resultberita = mysqli_query($conn, $queryberita);
$databerita = mysqli_fetch_assoc($resultberita);

	$ilustrasiBerita = "../assets/ilustrasi/".$databerita["foto"];
	$ilustrasiBerita2 = "../assets/ilustrasi/".$databerita["foto2"];
	$ilustrasiBerita3 = "../assets/ilustrasi/".$databerita["foto3"];
 ?>

<div class="containerBaca w3-white w3-card w3-round w3-border w3-padding" style="margin-top: 20px;">
	<h3><?= $databerita["judul"]; ?></h3>
	<span style="color: darkgrey;">tanggal posting: <?= $databerita["tglPosting"] ?></span><br>
	<p><?= $databerita["p1"]; ?></p><br>
	<img src="<?= $ilustrasiBerita; ?>" alt="data foto tidak tersedia" style="width: 70%"><br>
	<p><?= $databerita["p2"]; ?></p><br>
	<img src="<?= $ilustrasiBerita2; ?>" alt="data foto tidak tersedia" style="width: 70%"><br>
	<p><?= $databerita["p3"]; ?></p><br>
	<img src="<?= $ilustrasiBerita3; ?>" alt="data foto tidak tersedia" style="width: 70%"><br>
	<p><?= $databerita["p4"]; ?></p><br>
	<p><?= $databerita["p5"]; ?></p>
</div>

<?php require '../view/bottom_body.php' ?>