<?php 	
	$judulHalaman = "KATEGORI PROGRAM";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$hrefBack = "n20_profil_desa.php?theme=$theme&iddesa=$iddesa";
 
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
?>
<!-- <a href="../pages/baca_inspirasi.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>" >buka halaman dan kirim get</a> -->
<div class="jarak40"></div>
<div class="jarak20"></div>
<div class="w3-white w3-padding w3-border">
	<table class="w3-table w3-striped">
		<tr>
			<th class="w3-theme-l3">No.</th>
			<th class="w3-theme-l3">Uraian</th>
			<th class="w3-theme-l3">Alamat</th>
		</tr>
		<tr>
			<td>1</td>
			<td>bagian 1</td>
			<td>-</td>
		</tr>
		<tr>
			<td>2</td>
			<td>bagian 2</td>
			<td>-</td>
		</tr>
		<tr>
			<td>3</td>
			<td>bagian 3</td>
			<td>-</td>
		</tr>
	</table>
</div>

<div class="jarak20"></div>
<div class="w3-white w3-padding w3-border">
	<table class="w3-table w3-striped">
		<tr>
			<th class="w3-theme-l3">No.</th>
			<th class="w3-theme-l3">Uraian</th>
			<th class="w3-theme-l3">Alamat</th>
		</tr>
		<tr>
			<td>1</td>
			<td>bagian 1</td>
			<td>-</td>
		</tr>
		<tr>
			<td>2</td>
			<td>bagian 2</td>
			<td>-</td>
		</tr>
		<tr>
			<td>3</td>
			<td>bagian 3</td>
			<td>-</td>
		</tr>
	</table>
</div>













	<?php require '../view/bottom_body.php' ?>