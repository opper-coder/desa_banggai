<?php 	
	$judulHalaman = "APBDES DESA SAITI"; // desa ambilkan dari dbase
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$gambarJumbotron = "../assets/ilustrasi/baca.jpg";
	$hrefBack = "n10_apbdes.php?theme=$theme&iddesa=$iddesa";
 
// $apbdesTahun = $_GET['apbdesTahun'];

	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
	require '../core/init.php';
?>


<!-- <a href="../pages/baca_inspirasi.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>" >buka halaman dan kirim get</a> -->

	<div class="jarak40"></div>
	<div class="jarak30"></div>

<!-- dah jalan ini -->

<?php 
	// daftar pemasukan------
	$thanggaran = $_GET["thanggaran"];

			// $dd = query("SELECT * FROM apbdesin WHERE desa='$iddesa' AND thanggaran='$thanggaran' AND sumberdana='dd' ");
			// var_dump( $dd["nilai"] );

			// echo "<br>";
			// echo "<br>";

	$datadd 	= query("SELECT * FROM apbdesin WHERE desa='$iddesa' AND thanggaran='$thanggaran' AND sumberdana='dd' "); 
	$dataadd	= query("SELECT * FROM apbdesin WHERE desa='$iddesa' AND thanggaran='$thanggaran' AND sumberdana='add' ");
	$datapbh	= query("SELECT * FROM apbdesin WHERE desa='$iddesa' AND thanggaran='$thanggaran' AND sumberdana='pbh' ");
	$datasilpa	= query("SELECT * FROM apbdesin WHERE desa='$iddesa' AND thanggaran='$thanggaran' AND sumberdana='silpa' ");
	$datall		= query("SELECT * FROM apbdesin WHERE desa='$iddesa' AND thanggaran='$thanggaran' AND sumberdana='ll' ");
	$datapad	= query("SELECT * FROM apbdesin WHERE desa='$iddesa' AND thanggaran='$thanggaran' AND sumberdana='pad' ");

	$jumlahkan 	= $datadd["nilai"] + $dataadd["nilai"] + $datapbh["nilai"] + $datasilpa["nilai"] + $datall["nilai"] + $datapad["nilai"];
	
	$prodd 		= ($datadd["nilai"]/$jumlahkan)*100;
	$proadd 	= ($dataadd["nilai"]/$jumlahkan)*100;
	$propbh 	= ($datapbh["nilai"]/$jumlahkan)*100;
	$prosilpa 	= ($datasilpa["nilai"]/$jumlahkan)*100;
	$proll 		= ($datall["nilai"]/$jumlahkan)*100;
	$propad 	= ($datapad["nilai"]/$jumlahkan)*100;

	$d1 = $propad ;
	$d2 = $proll  ;
	$d3 = $prosilpa;
	$d4 = $propbh  ;
	$d5 = $proadd ;
	$d6 = $prodd ;


	// ----- daftar pengeluaran

	$datapemdes 		= query("SELECT * FROM apbdesout WHERE desa='$iddesa' AND thanggaran='$thanggaran' AND kategori='pemdes' ");
	$databangun 		= query("SELECT * FROM apbdesout WHERE desa='$iddesa' AND thanggaran='$thanggaran' AND kategori='pembangunan' ");
	$databinaan			= query("SELECT * FROM apbdesout WHERE desa='$iddesa' AND thanggaran='$thanggaran' AND kategori='pembinaan' ");
	$datadayaan 		= query("SELECT * FROM apbdesout WHERE desa='$iddesa' AND thanggaran='$thanggaran' AND kategori='pemberdayaan' ");
	$datatanggulangi	= query("SELECT * FROM apbdesout WHERE desa='$iddesa' AND thanggaran='$thanggaran' AND kategori='Penanggulangan' ");

	$jumlahkan2 = $datapemdes["jumlah"] + $databangun["jumlah"] + $databinaan["jumlah"] + $datadayaan["jumlah"] + $datatanggulangi["jumlah"];

	$prob1 = $datapemdes["jumlah"]/$jumlahkan2*100;
	$prob2 = $databangun["jumlah"]/$jumlahkan2*100;
	$prob3 = $databinaan["jumlah"]/$jumlahkan2*100;
	$prob4 = $datadayaan["jumlah"]/$jumlahkan2*100;
	$prob5 = $datatanggulangi["jumlah"]/$jumlahkan2*100;

	$b1 = $prob1;
	$b2 = $prob2;
	$b3 = $prob3;
	$b4 = $prob4;
	$b5 = $prob5;
?>

<!-- /dah jalan ini  -->
	<div class="containerBaca w3-theme-d3 w3-round w3-card w3-padding w3-border w3-center">
	Pendapatan Desa tahun anggaran <?= $_GET["thanggaran"]; ?>
	</div>
	<div class="containerBaca pieCn1 marginB20 w3-theme-l4 w3-round w3-card w3-padding">
		<div class="pieCn">
			<div class="chart1 pie" data-percent="<?= $d1+$d2+$d3+$d4+$d5+$d6;  ?>"></div>
		</div>
		<div class="pieCn">
			<div class="chart2 pie" data-percent="<?= $d2+$d3+$d4+$d5+$d6;  ?>"></div>
		</div>
		<div class="pieCn">
			<div class="chart3 pie" data-percent="<?= $d3+$d4+$d5+$d6;  ?>"></div>
		</div>
		<div class="pieCn">
			<div class="chart4 pie" data-percent="<?= $d4+$d5+$d6;  ?>"></div>
		</div>
		<div class="pieCn">
			<div class="chart5 pie" data-percent="<?= $d5+$d6;  ?>"></div>
		</div>
		<div class="pieCn">
			<div class="chart6 pie" data-percent="<?= $d6;  ?>"></div>
		</div>
	</div>
	<div class="containerBaca w3-theme-l2 w3-round w3-padding w3-border w3-center ">
	Keterangan Diagram
	</div>
	<div class="containerBaca  w3-padding w3-leftbar w3-border-orange w3-pale-blue w3-card">
	DD<span class="w3-right w3-border-left marginKr10"><?= number_format($prodd,1) ?>%</span><span class="w3-right w3-border-left"><?= "Rp ".number_format($datadd["nilai"],2,",","."); ?></span>	
	</div>
	<div class="containerBaca w3-padding w3-leftbar w3-border-yellow w3-pale-green w3-card">
	ADD<span class="w3-right w3-border-left marginKr10"><?= number_format($proadd,1) ?>%</span><span class="w3-right w3-border-left"><?= "Rp ". number_format($dataadd["nilai"],2,",","."); ?></span>	
	</div>
	<div class="containerBaca w3-padding w3-leftbar w3-border-green w3-pale-blue w3-card">
	PBH<span class="w3-right w3-border-left marginKr10"><?= number_format($propbh,1) ?>%</span><span class="w3-right w3-border-left"><?= "Rp ".number_format($datapbh["nilai"],2); ?></span>	
	</div>
	<div class="containerBaca w3-padding w3-leftbar w3-border-brown w3-pale-green w3-card">
	SILPA<span class="w3-right w3-border-left marginKr10"><?= number_format($prosilpa,1) ?>%</span><span class="w3-right w3-border-left"><?= "Rp ".number_format($datasilpa["nilai"],2); ?></span>	
	</div>
	<div class="containerBaca w3-padding w3-leftbar w3-border-blue w3-pale-blue w3-card">
	LL<span class="w3-right w3-border-left marginKr10"><?= number_format($proll,1) ?>%</span><span class="w3-right w3-border-left"><?="Rp ". number_format($datall["nilai"],2); ?></span>	
	</div>
	<div class="containerBaca w3-padding w3-leftbar w3-border-red w3-pale-green w3-card">
	PAD<span class="w3-right w3-border-left marginKr10"><?= number_format($propad,1) ?>%</span><span class="w3-right w3-border-left"><?="Rp ". number_format($datapad["nilai"],2); ?></span>	
	</div>

	<div class="w3-container jarak30 w3-border-bottom"></div>

	<div class="jarak30"></div>
	<div class="containerBaca w3-theme-d3 w3-round w3-card w3-padding w3-border w3-center">
	Belanja Desa tahun anggaran <?= $_GET["thanggaran"]; ?>
</div>
<!--  -->
<style>
.dblock1{
	height: <?= $b1; ?>px;
}
.dblock2{
	height: <?= $b2; ?>px;
}
.dblock3{
	height: <?= $b3; ?>px;
}
.dblock4{
	height: <?= $b4; ?>px;
}
.dblock5{
	height: <?= $b5; ?>px;
}
</style>
<!--  -->
	<div class="containerBaca diagramCn marginB20 w3-white w3-round w3-card w3-padding">
		<div class="diagramBlockCn  ">
			<div class="dblock dblock1 w3-theme-d2"></div>
			<div class="dblock dblock2 w3-theme-d2"></div>
			<div class="dblock dblock3 w3-theme-d2"></div>
			<div class="dblock dblock4 w3-theme-d2"></div>
			<div class="dblock dblock5 w3-theme-d2"></div>
		</div>
		<div class="diagramBlockCn  ">
			<div class="w3-badge w3-theme-d4 w3-card">1</div>
			<div class="w3-badge w3-theme-d4 w3-card">2</div>
			<div class="w3-badge w3-theme-d4 w3-card">3</div>
			<div class="w3-badge w3-theme-d4 w3-card">4</div>
			<div class="w3-badge w3-theme-d4 w3-card">5</div>
		</div>
	</div>
<!--  -->
	<div class="containerBaca w3-theme-l2 w3-round w3-padding w3-border w3-center ">
	Keterangan Diagram
	</div>








	<div class="containerBaca w3-padding w3-round w3-border w3-small w3-white w3-card">
		<table class="w3-table w3-striped">
			<tr>
				<td>1</td>
				<td>Penyelenggaraan Pemerintah Desa</td>
				<td><?= "Rp ".  number_format($datapemdes["jumlah"],2,",","."); ?></td>
				<td><?= number_format($b1,1); ?>%</td>
			</tr>
			<tr>
				<td>2</td>
				<td>Pelaksanaan Pembangunan desa</td>
				<td><?= "Rp ". number_format($databangun["jumlah"],2,",","."); ?></td>
				<td><?= number_format($b2,1); ?>%</td>
			</tr>
			<tr>
				<td>3</td>
				<td>Pembinaan Kemasyarakatan Desa</td>
				<td><?= "Rp ".  number_format($databinaan["jumlah"],2,",","."); ?></td>
				<td><?= number_format($b3,1); ?>%</td>
			</tr>
			<tr>
				<td>4</td>
				<td>Pemberdayaan Masyarakat Desa</td>
				<td><?= "Rp ".  number_format($datadayaan["jumlah"],2,",","."); ?></td>
				<td><?= number_format($b4,1); ?>%</td>
			</tr>
			<tr>
				<td>5</td>
				<td>Penanggulangan Bencana</td>
				<td><?= "Rp ".  number_format($datatanggulangi["jumlah"],2,",","."); ?></td>
				<td><?= number_format($b5,1); ?>%</td>
			</tr>
		</table>
	</div>
	<div class="jarak20"></div>
<!--  -->
	<div class="containerBaca w3-padding w3-theme-l4 w3-round w3-border w3-small">
		Untuk Informasi Uraian belanja  desa selengkapnya, silahkan klik tombol di bawah ini
		<br><br>
		<a href="n12_apbdes3.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&thanggaran=<?= $thanggaran; ?>" class="w3-btn w3-theme-d2 w3-round w3-small">rincian belanja</a>
	</div>
<!--  -->
<?php require '../view/bottom_body.php' ?>