<?php 
	$judulHalaman = "DAFTAR PENGUMUMAN";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$gambarJumbotron = "../assets/ilustrasi/pengumuman.jpg";
	$hrefBack = "../origin/saiti.php";
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
	require '../view/jumbotron.php';
	require '../core/init.php';
?>



<?php // ============== halaman butuh login ===========

if( !isset($_SESSION['user']) ){
	// die('anda belum login');
	header ( 'Location: ../functions/login.php' );
}

// ============== /halaman butuh login ===========  ?>




<!-- body pengumuman -->
<?php 
$queryberita = "SELECT * FROM artikel WHERE desa='$iddesa' AND type='pengumuman'";
$resultberita = mysqli_query($conn, $queryberita);
 ?>

<div class="containerBaca">
	<?php  
	while ($databerita = mysqli_fetch_assoc($resultberita)){?>
		<?php $idberita = $databerita["id"]; ?>

		<a href="n2_pengumuman2.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&idberita=<?=$idberita; ?>">
		<div class="w3-white w3-card w3-round w3-padding w3-small avatar w3-border">
			<img src="../assets/saiti/iconThumb/pengumuman2.png" alt="personal" style="width: 80px;" class="marginK10">
			<p class="w3-padding lipattext"><b><?= $databerita["judul"]; ?></b><br>
				<span style="color: darkgrey;">tanggal posting: <?= $databerita["tglPosting"] ?></span><br>
				<?= $databerita["p1"]; ?></p>
		</div>
		</a>
	<?php } ?>
</div>


	<?php require '../view/bottom_body.php' ?>