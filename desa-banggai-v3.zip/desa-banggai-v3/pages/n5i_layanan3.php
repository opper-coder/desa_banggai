<?php 	
	$judulHalaman = "FORM LAYANAN";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$idlayanan = $_GET['idlayanan'];
	$hrefBack = "n4_layanan2.php?theme=$theme&iddesa=$iddesa&kategori=pemdes";
	require_once '../view/top_body.php';
	require_once $theme;
	require_once '../view/navback.php';
	require_once '../view/center_body.php';
	require_once '../core/init.php';
// ============================= function ===============================
// --------------- session login --------------
if( !isset($_SESSION['user']) ){
	// die('anda belum login');
	header ( 'Location: ../functions/login.php' );
}
/* --------------- query --------------------->
	ambil data dari field database(quesioner) -> urai jadi array assoc*/
	$data = query("SELECT quesioner FROM layanan WHERE id='$idlayanan' AND desa='umum' OR desa='$iddesa'");
	$strdata = $data['quesioner'];
// ---------------  urai string ---------------
	function uraiString($data){
		$urai1 = explode(",", $data);
		$arraydata =[];
			for ($i=0; $i < count($urai1); $i++) {
				$arraydata [] = explode("=>", $urai1[$i]);
			}
		$dataquesioner2 = [];
			for ($k=0; $k < count($urai1); $k++) { 
				$dataquesioner2[$arraydata[$k][0]] = $arraydata[$k][1];
			}	
		return ($dataquesioner2);
	}
	$field = uraiString($strdata);
/* --------------- bikin field --------------->
	bikin field quesioner dari array assoc di atas*/
	function fField($datafield){
		foreach ($datafield as $key => $value) { ?>
			<label class="huruf12" for=<?= $key ?> ><?= $value ?></label>
			<div class="jarak5"></div>
			<input type="text" class="w3-input w3-small w3-round" name=<?= $key;?> id=<?= $key; //dibelakang ini boleh tulis required?> > 
			<div class="jarak10" ></div>
	<?php }
	}
/* --------------- data POST field ------------
 field di atas di gunakan untuk posting data -> datanya kita tangkap disini*/
$arraypost 	= $_POST;							// beres
array_pop($arraypost);
$nikpemohon = 0;
$perihal	= 0;

if (isset($_POST["submitx"])) {
	$nikpemohon = $arraypost['nik'];			// beres
	$perihal	= $arraypost['perihal'];		// beres
}

$idlayanan 		= $idlayanan;					
$datakirim 		= fdatakirim($arraypost);		// beres
$tglmasuk		= date('Y-m-d');				// beres
$sender 		= $_SESSION["user"];			// beres
$iddesa 		= $iddesa; 						// beres
/* -------------- untuk fcek -------------------
 
 */

$datadb			=	mysqli_num_rows(mysqli_query($conn, "SELECT data FROM suratkeluar WHERE data='$datakirim'"));
// jika ada maka > 0 :
$tglmasukdb		=	mysqli_num_rows(mysqli_query($conn, "SELECT tglmasuk FROM suratkeluar WHERE tglmasuk='$tglmasuk'"));
// jika benar maka > 0 :
$nikpemohondb	=	mysqli_num_rows(mysqli_query($conn, "SELECT nikpemohon FROM suratkeluar WHERE nikpemohon='$nikpemohon'"));

// ini hal baru jika di atas berjalan maka ini boleh hapus
function querybaca($query){
	global $conn;
	$result = mysqli_query($conn, $query);
	$barisdata = [];
	while ($data = mysqli_fetch_assoc($result)) {
		$barisdata = $data;
	}
	return $barisdata;
}
$querytgl 		= 	"SELECT tglmasuk   FROM suratkeluar WHERE data ='$datakirim'";
$querynikpemohon= 	"SELECT nikpemohon FROM suratkeluar WHERE tglmasuk ='$tglmasuk'";
$tglmasukdb2	=	querybaca($querytgl);
$nikpemohondb2	=	querybaca($querynikpemohon);
/*
*/


/* -------- fungsi tangkap input user ----------

*/
// ================================================
echo "<br><br><br><hr>";
var_dump($tglmasukdb);
echo "<br><br><br><hr>";
// ================================================


function fdatakirim($arraypost){
	$key = array_keys($arraypost);
	$val = array_values($arraypost);
	$datakirim=[];

	for ($i=0; $i < count($arraypost); $i++) { 
		$datakirim[] = $key[$i] . "=>" . $val[$i] . ",";
	}
	$data = implode($datakirim);
	$data2 = substr($data, 0, -1);
	return $data2;
}
/* --------------- queri insert ----------------
oper data berikut ke db -> 
*/
function tulisFieldKeDb(){
	global 	$conn, 
			$idlayanan, 
			$datakirim, 
			$nikpemohon,
			$perihal,
			$tglmasuk, 
			$sender, 
			$iddesa;
    $queryinsert = "INSERT INTO suratkeluar (
    	idlayanan,
    	data,  
    	nikpemohon, 
    	perihal,
    	tglmasuk,
    	sender, 
    	desa) 
    	VALUES (
    	'$idlayanan', 
    	'$datakirim', 
    	'$nikpemohon',
    	'$perihal',
    	'$tglmasuk', 
    	'$sender', 
    	'$iddesa')";

		if( mysqli_query ($conn, $queryinsert) ){
			return true;
			}else{return false;}
}
/* ---------- kondisi validasi isi field -----------
- periksa :
- ada? = POST
- isi? = nik dan perihal
- 
*/
$kosong = in_array("", $arraypost);
$error = "silahkan mengisi formulir dengan benar";
/*
if( isset($_POST["submitx"]) ){ 
    if ( !empty( trim($nikpemohon)) && !empty( trim($perihal)) ) { 
		if ( !$kosong ){
			// cek nik dan perihal dan tgl
			if( $datadb == 0  && $tglmasukdb == 0 && $nikpemohondb == 0 ){ 
				if(tulisFieldKeDb()){
					$error = 'berhasil kirim data, silahkan lihat status layanan';
				} else {$error = "data tidak berhasil dikirim silahkan coba lagi nanti";}
			} else{ $error = 'data sudah ada dalam database silahkan klik tombol "status layanan" di bagian bawah';}
		}else{ $error = "field tidak boleh kosong, anda harus mengisi semua kolom yang di sediakan"; }
	}else{ $error = "field tidak boleh kosong, anda harus mengisi semua kolom yang di sediakan";}
}*/
if( isset($_POST["submitx"]) ){ 
    if ( !empty( trim($nikpemohon)) && !empty( trim($perihal)) ) { 
		if ( !$kosong ){
			// cek nik dan tgl
			// if( $tglmasukdb < 2 && $nikpemohondb < 2 ){ 
			if( true ){ 
				if(tulisFieldKeDb()){
					$error = 'berhasil kirim data, silahkan lihat status layanan';
				} else {$error = "data tidak berhasil dikirim silahkan coba lagi nanti";}
			} else{ $error = 'data sudah ada dalam database silahkan klik tombol "status layanan" di bagian bawah';}
		}else{ $error = "field tidak boleh kosong, anda harus mengisi semua kolom yang di sediakan"; }
	}else{ $error = "field tidak boleh kosong, anda harus mengisi semua kolom yang di sediakan";}
}
$status=in_array("", $arraypost);
?>
<!-- ============================= style =============================== -->
/* The Modal (background) */
<style>
.modal {
  display: block; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 80%;
}

/* The Close Button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}
</style>

<!-- ============================= body layanan =============================== -->
<!-- <div class="jarak40"></div> -->
<div class="jarak20"></div>
<div class="containerBaca marginB20 w3-white w3-card w3-round w3-border w3-padding w3-theme-l4 w3-small " >
	<h5 style="text-transform: capitalize;"><?php queryTFlayanan("layanan", "nama"); ?></h5>
<!-- 	<hr>
	<p>layanan ini membutuhkan lampiran dan kelengkapan yang di sediakan oleh pemerintah desa dan beberapa layanan yang harus di lengkapi oleh yang bersangkutan labih lanjut silahkan melihat tabel di bawah ini</p> -->
</div>
<div class="containerBaca marginB16 w3-white w3-round w3-border w3-padding" >
	<div class="jarak10"></div>
	<p>Kelengkapan berkas yang di sediakan:</p>
	<div class="jarak10"></div>
	<ul style="padding-left: 30px; font-size:13px; color:#656565; list-style: none;">
		<li class="paddingB5"><span>- </span><span>SKTM Persalinan</span></li>
		<li class="paddingB5"><span>- </span><span>fc KTP</span></li>
		<li class="paddingB5"><span>- </span><span>fc KK</span></li>
		<li class="paddingB5"><span>- </span><span>fc Surat Keterangan</span></li>
	</ul>
	<div class="jarak10"></div>
	<p>Kelengkapan berkas yang di sediakan:</p>
	<div class="jarak10"></div>
	<ul style="padding-left: 30px; font-size:13px; color:#656565; list-style: none;">
		<li class="paddingB5"><span>- </span><span>SKTM Persalinan</span></li>
		<li class="paddingB5"><span>- </span><span>SKTM Persalinan</span></li>
		<li class="paddingB5"><span>- </span><span>SKTM Persalinan</span></li>
		<li class="paddingB5"><span>- </span><span>SKTM Persalinan</span></li>
	</ul>
	<div class="jarak10"></div>
	<p>Estimasi Proses:</p>
	<div class="jarak10"></div>
	<ul style="padding-left: 30px; font-size:13px; color:#656565; list-style: none;">
		<li class="paddingB5"><span>- </span><span>< 5 menit</span></li>
	</ul>
	<div class="jarak10"></div>
	<p>total biaya:</p>
	<div class="jarak10"></div>
	<ul style="padding-left: 30px; font-size:13px; color:#656565; list-style: none;">
		<li class="paddingB5"><span>- </span><span>Gratis</span></li>

	</ul>
</div>
<div class="containerBaca marginB16 w3-white w3-round w3-border w3-padding" >
	<b id="ajukan">Lengkapi formulir dibawah ini:</b>
	<p>Untuk melengkapi persyaratan silahkan mengisi seluruh kolom pertanyaan di bawah ini dengan benar</p>
	<br>
	<div class="containerForm w3-border">
		<form action="" method="post" class="w3-form">		
			<?php fField($field); ?>
			<div class="jarak20"></div>
			<button type="submit" name="submitx" class="w3-btn w3-theme-d4 w3-round w3-small" id="myBtn">Ajukan pelayanan!</button>
		</form><a href="n6_status_layanan.php?iddesa=<?= $iddesa; ?>&theme=<?= $theme; ?>" class="w3-btn btnlay marginB16">Status layanan</a>
		<div>
			<p class="w3-orange paddingKr10"><?= $error; ?></p>
		</div>
	</div>
</div>

<!-- Trigger/Open The Modal -->
<!-- <button id="myBtn">Open Modal</button> -->

<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <p class="w3-orange">Pesan:</p>
    <p class="w3-orange"><?= $error ?></p>
  </div>

</div>

<script>
// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>

<?php require '../view/bottom_body.php' ?>