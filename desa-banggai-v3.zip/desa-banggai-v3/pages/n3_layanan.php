<?php 
	$judulHalaman = "KATEGORI LAYANAN";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$gambarJumbotron = "../assets/saiti/ilustrasi/layanan.jpg";
	$hrefBack = "../origin/saiti.php";
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
	require '../view/jumbotron.php';
?>

<div class="menuHomeCn">
		<div class="menuHome satu w3-card-2 ">
			<a href="n4_layanan2.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&kategori=pemdes">
			<img src="../assets/saiti/iconUi/layanan.jpg" alt="">
			</a>
			<a href="n4_layanan2.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&kategori=pemdes" style="text-decoration: none;">
			<span>Layanan pemdes</span>
			</a>
		</div>
		
		<div class="menuHome w3-card-2 ">
			<a href="../pages/n4_layanan2.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&kategori=integrasi">
			<img src="../assets/saiti/iconUi/integrasi1.jpg" alt="">
			</a>
			<a href="../pages/n4_layanan2.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&kategori=integrasi" style="text-decoration: none;">
			<span>layanan integrasi</span>
			</a>
		</div>

		<div class="menuHome tiga w3-card-2 ">
			<a href="../pages/n4_layanan2.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&kategori=mitra">
			<img src="../assets/saiti/iconUi/mitra2.jpg" alt="">
			</a>
			<a href="../pages/n4_layanan2.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&kategori=mitra" style="text-decoration: none;">
			<span>layanan mitra</span>
			</a>
		</div>

		<div class="menuHome w3-card-2 ">
			<a href="../pages/n3_layanan.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&kategori=inspirasi">
			<img src="../assets/saiti/iconUi/inspirasi.jpg" alt="">
			</a>
			<a href="../pages/n3_layanan.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&kategori=inspirasi" style="text-decoration: none;">
			<span>Inspirasi</span>
			</a>
		</div>

	</div>

	<?php require '../view/bottom_body.php' ?>