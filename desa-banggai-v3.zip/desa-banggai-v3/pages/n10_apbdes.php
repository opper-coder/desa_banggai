<?php 
	$judulHalaman = "APBDES tahun Anggaran";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$gambarJumbotron = "../assets/saiti/ilustrasi/ekonomi.jpg";
	$hrefBack = "../origin/saiti.php";

	$apbdes18 = "apbdes18"; // dari database ?????
	$apbdes19 = "apbdes19"; // dari database ?????

	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
	require '../view/jumbotron.php';
	require '../core/init.php';
?>




<div class="containerBaca">
	<?php 
	$conn 			= mysqli_connect("localhost","root","","desa_banggai");
	$querytahun		= "SELECT DISTINCT thanggaran FROM apbdesin WHERE desa='$iddesa' ORDER BY thanggaran";
	$resulttahun 	= mysqli_query($conn, $querytahun);

	while ($data = mysqli_fetch_assoc($resulttahun)):?>
			<a href="n11_apbdes2.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&thanggaran=<?= $data['thanggaran']; ?>">
				<div class="w3-white w3-card w3-round w3-padding w3-small avatar" >
					<img src="../assets/saiti/iconUi/apbdes.png" alt="personal" class="w3-circle" style="width: 60px;">
					<p><b style="font-size: 12px;">APBDesa Tahun Anggaran <?= " ".$data["thanggaran"]; ?></b>
				</div>
			</a>
		<?php endwhile ?>
</div>

<?php require '../view/bottom_body.php' ?>