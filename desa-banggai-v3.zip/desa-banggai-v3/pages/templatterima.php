<?php 
	$theme = $_GET['theme'];
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	
	// sudah terima theme dan id desa
	// var_dump($_GET['iddesa']);
?>
<a href="sementara.php?theme=<?= $theme; ?>&iddesa=saiti">test kirim theme</a>










<!-- akhir body -->
	<?php require '../view/bottom_body.php' ?>