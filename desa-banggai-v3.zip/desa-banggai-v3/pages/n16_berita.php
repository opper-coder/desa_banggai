<?php 	
	$judulHalaman = "DAFTAR BERITA";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$gambarJumbotron = "../assets/saiti/ilustrasi/berita.jpg";
	$hrefBack = "../origin/saiti.php";
 
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
	// require '../view/jumbotron.php';
	require '../core/init.php';
?>

<div class="jarak40" style="background-color: #000853"></div>
<div class="jumbotron2" style="background-color: #000853">
	<img src="<?= $gambarJumbotron; ?>" alt="gambar ilustrasi">
</div> 

<!-- body berita -->
<?php 
$queryberita = "SELECT * FROM artikel WHERE desa='$iddesa' AND type='berita'";
$resultberita = mysqli_query($conn, $queryberita);
 ?>

<div class="containerBaca">
	<?php  
	while ($databerita = mysqli_fetch_assoc($resultberita)){?>
		<?php $idberita = $databerita["id"]; ?>
		<a href="n17_berita2.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&idberita=<?=$idberita; ?>">
		<div class="w3-white w3-card w3-round w3-padding w3-small avatar w3-border" >
			<img src="../img/kades.jpg" alt="personal" style="width: 80px;" class="marginK10">
			<p class="w3-padding lipattext"><b><?= $databerita["judul"]; ?></b><br>
				<span style="color: darkgrey;">tanggal posting: <?= $databerita["tglPosting"] ?></span><br>
				<?= $databerita["p1"]; ?></p>
		</div>
		</a>
	<?php } ?>
</div>

<?php require '../view/bottom_body.php' ?>