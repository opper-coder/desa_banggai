<?php 	
	$judulHalaman = "DETAIL INFORMASI";
	$idbelanja = $_GET["idbelanja"];
	$thanggaran = $_GET["thanggaran"];
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$hrefBack = "n12_apbdes3.php?theme=$theme&iddesa=$iddesa&thanggaran=$thanggaran";
 
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
	require '../core/init.php';

echo $idbelanja;
?>

<?php // ============== halaman butuh login ===========
	if( !isset($_SESSION['user']) ){
		header ( 'Location: ../functions/login.php' );
	}
// ============== /halaman butuh login ===========  ?>


<!-- body -->
<?php 
$dataLBangunan = query("SELECT * FROM apbdesout WHERE desa='$iddesa' AND thanggaran='$thanggaran' AND id='$idbelanja'");
 ?>

<div class="jarak20"></div>
<div class="jarak5"></div>
<h4 class="judulThumb w3-border-bottom" style="text-transform: uppercase;"><?= $dataLBangunan["posbelanja"]; ?></h4>

<div class="thumb4">
	<div class="gambarCn">
		<img src="../img/<?= $dataLBangunan['foto1'] ?>.jpg" alt="gambar tidak tersedia" class="gambar w3-card"  onclick="document.getElementById('modal01').style.display='block'">	
		<div id="modal01" class="w3-modal" onclick="this.style.display='none'">
		  <span class="w3-closebtn w3-hover-red w3-container w3-padding w3-display-topright">X</span>
		  <img class="w3-modal-content w3-animate-zoom" src="../img/<?= $dataLBangunan['foto1'] ?>.jpg" style="width: 50%">
		</div>
	</div>
	<div class="gambarCn">
		<img src="../img/<?= $dataLBangunan['foto2'] ?>.jpg" alt="gambar tidak tersedia" class="gambar w3-card"  onclick="document.getElementById('modal02').style.display='block'">	
		<div id="modal02" class="w3-modal" onclick="this.style.display='none'">
		  <span class="w3-closebtn w3-hover-red w3-container w3-padding w3-display-topright">X</span>
		  <img class="w3-modal-content w3-animate-zoom" src="../img/<?= $dataLBangunan['foto2'] ?>.jpg" style="width: 50%">
		</div>
	</div>
	<div class="gambarCn">
		<img src="../img/<?= $dataLBangunan['foto3'] ?>.jpg" alt="gambar tidak tersedia" class="gambar w3-card"  onclick="document.getElementById('modal03').style.display='block'">	
		<div id="modal03" class="w3-modal" onclick="this.style.display='none'">
		  <span class="w3-closebtn w3-hover-red w3-container w3-padding w3-display-topright">X</span>
		  <img class="w3-modal-content w3-animate-zoom" src="../img/<?= $dataLBangunan['foto3'] ?>.jpg" style="width: 50%">
		</div>
	</div>
	<div class="gambarCn">
		<img src="../img/<?= $dataLBangunan['foto4'] ?>.jpg" alt="gambar tidak tersedia" class="gambar w3-card"  onclick="document.getElementById('modal04').style.display='block'">	
		<div id="modal04" class="w3-modal" onclick="this.style.display='none'">
		  <span class="w3-closebtn w3-hover-red w3-container w3-padding w3-display-topright">X</span>
		  <img class="w3-modal-content w3-animate-zoom" src="../img/<?= $dataLBangunan['foto4'] ?>.jpg" style="width: 50%">
		</div>
	</div>

	<!-- <div class="gambarCn">
		<img src="../img/balai desa.jpg" alt="gambar tidak tersedia" class="gambar w3-card">
	</div>
	<div class="gambarCn">
		<img src="../img/balai desa.jpg" alt="gambar tidak tersedia" class="gambar w3-card">
	</div>
	<div class="gambarCn">
		<img src="../img/balai desa.jpg" alt="gambar tidak tersedia" class="gambar w3-card">
	</div> -->

</div>

<div class="containerBaca w3-white w3-round w3-card">
	<p class="paddingKr16 w3-theme w3-padding">Keterangan Foto</p>
	<table class="w3-table w3-striped w3-border table">
		<tr>
			<td>1</td>
			<td><?= $dataLBangunan["pfoto1"] ?> %</td>
			<td><b><?= $dataLBangunan["kfoto1"] ?></b></td>
		</tr>
		<tr>
			<td>2</td>
			<td><?= $dataLBangunan["pfoto2"] ?> %</td>
			<td><b><?= $dataLBangunan["kfoto2"] ?></b></td>
		</tr>
		<tr>
			<td>3</td>
			<td><?= $dataLBangunan["pfoto3"] ?> %</td>
			<td><b><?= $dataLBangunan["kfoto3"] ?></b></td>
		</tr>
		<tr>
			<td>4</td>
			<td><?= $dataLBangunan["pfoto4"] ?> %</td>
			<td><b><?= $dataLBangunan["kfoto4"] ?></b></td>
		</tr>
	</table>
</div>

<div class="jarak20"></div>
<div class="containerBaca w3-white w3-round w3-card">
	<p class="paddingKr16 w3-theme w3-padding">Rincian Kegiatan</p>
	<table class="w3-table w3-striped w3-border table">
		<tr>
			<td>1</td>
			<td>aktifitas</td>
			<td><b><?= $dataLBangunan["posbelanja"]; ?> </b></td>
		</tr>
		<tr>
			<td>2</td>
			<td>Sumber Dana</td>
			<td><b><?= $dataLBangunan["sumberdana"]; ?></b></td>
		</tr>
		<tr>
			<td>3</td>
			<td>progress</td>
			<td><b><?= $dataLBangunan["progress"]; ?></b></td>
		</tr>
		<tr>
			<td>4</td>
			<td>Mulai Kegiatan</td>
			<td><b><?= $dataLBangunan["mulaikegiatan"]; ?></b></td>
		</tr>
		<tr>
			<td>5</td>
			<td>akhir Kegiatan</td>
			<td><b><?= $dataLBangunan["akhirkegiatan"]; ?></b></td>
		</tr>
		<tr>
			<td>6</td>
			<td>Anggaran</td>
			<td><b>Rp.<?= " ". number_format($dataLBangunan["jumlah"],2,",","."); ?></b></td>
		</tr>
				<tr>
			<td>7</td>
			<td>keterangan</td>
			<td><b><?= $dataLBangunan["keterangan"]; ?></b></td>
		</tr>
	</table>
</div>

<?php require '../view/bottom_body.php' ?>