<?php 	
	$judulHalaman = "Pilihan kategori";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$hrefBack = "n21_profil_kelembagaan.php?theme=$theme&iddesa=$iddesa";
 
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';

	require '../core/init.php';

?>
<div class="jarak40"></div>
<div class="jarak20"></div>

<?php

// persiapan parameter pemanggilan

$linkTable = "n26_profil_lmbg_pemdes.php?theme=$theme&iddesa=$iddesa";
$field = ["No.","Perode","Ke"];

// $query6sini = "SELECT max(periode) as jumlah FROM aparat";
// $dataku = mysqli_query($conn, $query6sini);
// $data = mysqli_fetch_assoc($dataku);

// $query7sini = "SELECT * FROM aparat WHERE desa='$iddesa'";
// $dataku2 = mysqli_query($conn, $query7sini);
// $tahun = mysqli_fetch_assoc($dataku2);
 ?>

<?php 
function listLink5($field, $linkTable){ 
	global $theme;
	global $iddesa;
	global $conn;
	?>
		
		<div class="containerBaca">
			<table class="w3-table w3-striped w3-bordered w3-border w3-hoverable ">
				<tr>
					<?php  
					foreach ($field as $f):?>
						<th class="w3-theme-l2"><?= $f ?></th>
					<?php endForeach ?>
				</tr>
				
				<?php 
				$query7sini = "SELECT max(periode) as jumlah FROM aparat WHERE desa='$iddesa'";
				$dataq = mysqli_query($conn, $query7sini);
				$data2 = mysqli_fetch_assoc($dataq);
				$i = 1;
				$kategori="&kategori=".$_GET["kategori"];


				while ( $i <= $data2["jumlah"] ) { ?>
					<tr>
						<?php 
						$id="&periode=".$i; 
						?>
						<td><a href=<?= $linkTable.$id.$kategori; ?>><?= $i ?></a></td>
						<td style="text-transform: capitalize;"><a href=<?= $linkTable.$id.$kategori; ?>>periode pemerintahan</a></td>
						<td><a href=<?= $linkTable.$id.$kategori; ?>>ke : <?= $i ?></a></td>
					</tr>
					<?php $i++;} ?>
			</table>
		</div>

	<?php } ?>


<?php  
listLink5($field, $linkTable);
?>


<!-- ---------batas akhir---------- -->
<?php require '../view/bottom_body.php' ?>