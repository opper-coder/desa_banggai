<?php 	
	$judulHalaman = "FORM LAYANAN";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$idlayanan = $_GET['idlayanan'];
	$hrefBack = "n4_layanan2.php?theme=$theme&iddesa=$iddesa";
 
	require_once '../view/top_body.php';
	require_once $theme;
	require_once '../view/navback.php';
	require_once '../view/center_body.php';
	require_once '../core/init.php';

// ============== halaman butuh login ===========

if( !isset($_SESSION['user']) ){
	// die('anda belum login');
	header ( 'Location: ../functions/login.php' );
}

// ============== /halaman butuh login ===========
// =============== function bikin field ================

	// $query1		= "SELECT quesioner FROM layanan WHERE id='$idlayanan' AND desa='umum' OR desa='$iddesa'";
	// $hasil 		= mysqli_query($conn, $query1);
	// $data 		= mysqli_fetch_assoc($hasil);


	$data = query("SELECT quesioner FROM layanan WHERE id='$idlayanan' AND desa='umum' OR desa='$iddesa'");

	$datanya = $data['quesioner'];
	// $datanya = "nama=>nama lengkap :,alamat=>alamat rumah,nik=>nik bersangkutan,kk=>ada kk" ;
// -----
	function dataquesioner($data){
		$urai1 = explode(",", $data);
		$arraydata =[];
			for ($i=0; $i < count($urai1); $i++) { 	
				$arraydata [] = explode("=>", $urai1[$i]);
			}
		$dataquesioner = [];
			for ($k=0; $k < count($urai1); $k++) { 
				$dataquesioner[$arraydata[$k][0]] = $arraydata[$k][1];
			}	
		return ($dataquesioner);
	}
// -----
	$dataquesioner = dataquesioner($datanya);
// -----
// =============== function baca field ================

	function fField($dataquesioner){
		foreach ($data as $key => $value) { ?>
			<label class="huruf14" for=<?= $key ?> ><?= $value ?></label>
			<div class="jarak5"></div>
			<input type="text" class="w3-input w3-small w3-round" name=<?= $key;?> id=<?= $key; //dibelakang ini boleh tulis required?> > 
			<div class="jarak10" ></div>
	<?php  	}
	}

// -----
	// fField($dataquesioner);
// -----
// =============== /function field ================
// ----- function isi ke dbase -----

// tangkap data dari field untuk dikirim ke database field (letakkan func ini ke halaman modular)

$arraypost 	= $_POST;					// beres
array_pop($arraypost);
$nikpemohon = 0;
$perihal	= 0;

if (isset($_POST["submitx"])) {
	$nikpemohon = $arraypost['nik'];		// beres
	$perihal	= $arraypost['perihal'];	// beres
}

$idlayanan 		= $idlayanan;					
$datakirim 		= fdatakirim($arraypost);		// beres
$tglmasuk		= date('Y-m-d');				// beres
$sender 		= $_SESSION["user"];			// beres
$iddesa 		= $iddesa; 						// beres

// ----- untuk fcek

$datadb			=	mysqli_num_rows(mysqli_query($conn, "SELECT data FROM suratkeluar WHERE data='$datakirim'"));
$tglmasukdb		=	mysqli_num_rows(mysqli_query($conn, "SELECT tglmasuk FROM suratkeluar WHERE tglmasuk='$tglmasuk'"));
$nikpemohondb	=	mysqli_num_rows(mysqli_query($conn, "SELECT nikpemohon FROM suratkeluar WHERE nikpemohon='$nikpemohon'"));

	// echo "<br><br><br>";

	// 	print_r($datadb);echo "<br>";
	// 	print_r($tglmasukdb);echo "<br>";
	// 	print_r($nikpemohondb);echo "<br>";
	// var_dump($perihal);

// =========== fungsi tangkap input user ===========

function fdatakirim($arraypost){
	$key = array_keys($arraypost);
	$val = array_values($arraypost);
	$datakirim=[];

	for ($i=0; $i < count($arraypost); $i++) { 
		$datakirim[] = $key[$i] . "=>" . $val[$i] . ",";
	}
	$data = implode($datakirim);
	$data2 = substr($data, 0, -1);
	return $data2;
}

// ada beberapa aturan untuk tulis surat keluar

/*
0. id layanan / ambil id disini
1. nomor / analisa
2. urut / bikin urutan
3. data / dah ada
4. pemohon / nama nik pemohon dari penduduk
5. nik pemohon / ambil dari field 
6. penerbit / --
7. sender / ambil dari user session 
8. perihal / ambil dari field 
9. tanggal masuk / data sekarang 
10. tgl terbit / --
11. verifi / --
12. pesan / --
13. desa / dari id desa 
*/

// =================== queri insert ==================== 
function tulisFieldKeDb(){
	global 	$conn, 
			$idlayanan, 
			$datakirim, 
			$nikpemohon,
			$perihal,
			$tglmasuk, 
			$sender, 
			$iddesa;

    $queryinsert = "INSERT INTO suratkeluar (
    	idlayanan,
    	data,  
    	nikpemohon, 
    	perihal,
    	tglmasuk,
    	sender, 
    	desa) 
    	VALUES (
    	'$idlayanan', 
    	'$datakirim', 
    	'$nikpemohon',
    	'$perihal',
    	'$tglmasuk', 
    	'$sender', 
    	'$iddesa')";

		if( mysqli_query ($conn, $queryinsert) ){
			return true;
			}else{return false;}
}

// ================= kondisi validasi isi field ==========
$kosong = in_array("", $arraypost);
$error = "";
if( isset($_POST["submitx"]) ){ 
    if ( !empty( trim($nikpemohon)) && !empty( trim($perihal)) ) { 
		if ( !$kosong ){
			// cek nik dan perihal dan tgl
			if( $datadb == 0  && $tglmasukdb == 0 && $nikpemohondb == 0 ){ 
				// if(tulisFieldKeDb()){
				// 	$error = 'berhasil kirim data, silahkan lihat status layanan';
				// } else {$error = "data tidak berhasil dikirim silahkan coba lagi nanti";}
			} else{ $error = "data sudah ada dalam database silahkan klik tombol status layanan";}
		}else{ $error = "field harus di isi"; }
	}else{ $error = "field harus di isi";}
}

$status=in_array("", $arraypost);
// =============== /function isi ke dbase ==============
 ?>

<!-- body layanan -->
<div class="jarak40"></div>
<div class="jarak20"></div>
<div class="containerBaca marginB20 w3-white w3-card w3-round w3-border w3-padding w3-theme-l4 w3-small " >
	<h5 style="text-transform: capitalize;"><?php queryTFlayanan("layanan", "nama"); ?></h5>
	<hr>
	<p>layanan ini membutuhkan lampiran dan kelengkapan yang di sediakan oleh pemerintah desa dan beberapa layanan yang harus di lengkapi oleh yang bersangkutan labih lanjut silahkan melihat tabel di bawah ini</p>
</div>
<div class="containerBaca marginB16 w3-white w3-round w3-border w3-padding" >
	<b>Syarat tersedia di PemDes</b>
	<hr>
	<table class="w3-table w3-striped w3-small">
		<tr class="w3-theme-l4">
			<th>No.</th>
			<th>Syarat </th>
			<th>Tersedia</th>
			<th>biaya</th>
		</tr>
		<tr>
			<td>1.</td>
			<td><?php queryTFlayanan("layanan", "lampiran"); ?></td>
			<td>Tersedia</td>
			<td>-</td>
		</tr>
		<tr>
			<td>2.</td>
			<td>KTP yang berlaku</td>
			<td>Tersedia</td>
			<td>-</td>
		</tr>
	</table>
</div>

<div class="containerBaca marginB16 w3-white w3-round w3-border w3-padding">
	<b>Syarat dilengkapi oleh yang bersangkutan</b>
	<hr>
	<table class="w3-table w3-striped w3-small">
		<tr class="w3-theme-l4">
			<th>No.</th>
			<th>Syarat</th>
			<th>Tersedia</th>
			<th>biaya</th>
		</tr>
		<tr>
			<td>1.</td>
			<td>Surat Pengantar RT & RW</td>
			<td>belum</td>
			<td>-</td>
		</tr>
		<tr>
			<td>2.</td>
			<td>KTP yang berlaku</td>
			<td>belum</td>
			<td>-</td>
		</tr>
	</table>
</div>

<div class="containerBaca marginB16 w3-white w3-round w3-border w3-padding" >
	<b>Estimasi Proses</b>
	<hr>
	<p><5 menit</p>
</div>

<div class="containerBaca marginB16 w3-white w3-round w3-border w3-padding">
	<b>Total biaya</b>
	<hr>
	<p>Gratis</p>
	<!-- dari data base -->
</div>
<div class="containerBaca marginB16 w3-white w3-round w3-border w3-padding" >
	<b id="ajukan">Lengkapi formulir dibawah ini:</b>
	<hr>
	<p>Untuk melengkapi persyaratan silahkan mengisi seluruh kolom pertanyaan di bawah ini dengan benar</p>
	<br>
	<!-- <div class="containerForm w3-border">
		<form action="n6_status_layanan.php" method="get" class="w3-form">		
			<input type="hidden" name="iddesa" value=<?= $iddesa; ?>>
			<input type="hidden" name="theme" value=<?= $theme; ?>>
			<?php 

			// query ke 'layanan' 'umum' 'saiti' 'id' 'layanan'

			$queryque = "SELECT * FROM layanan WHERE desa='$iddesa' OR desa='umum' AND id='$idlayanan'";
			$resultque = mysqli_query($conn, $queryque);
			$dataque = mysqli_fetch_assoc($resultque);
			$quesioner = explode(",", $dataque["quesioner"]);
			$i = 0;
			foreach ($quesioner as $k ) {
				?>
				<label for="perihal" class="huruf14"><?= "$k"; ?>:</label>
				<div class="jarak5"></div>
				<input type="text" name="kolom<?= $i; ?>" id="perihal" class="w3-input w3-small w3-round" required>
				<div class="jarak10" ></div>
				<?php $i++; } ?>
			
			<div class="jarak20"></div>
			<button type="submit" name="submit" class="w3-btn w3-theme-d4 w3-round w3-small">Ajukan pelayanan!</button>
		</form>
	</div> -->
	<div class="containerForm w3-border">
		<form action="" method="post" class="w3-form">		
			<?php fField($dataquesioner); ?>
			<div class="jarak20"></div>
			<button type="submit" name="submitx" class="w3-btn w3-theme-d4 w3-round w3-small">Ajukan pelayanan!</button>
		</form><a href="n6_status_layanan.php?iddesa=<?= $iddesa; ?>&theme=<?= $theme; ?>!" class="w3-btn btnlay marginB16">Status layanan</a>
		<div>
			<p class="w3-orange paddingKr10"><?= $error; ?></p>
		</div>
	</div>
</div>
<?php require '../view/bottom_body.php' ?>

<?php /*
----------------------------------------------------------------
 KETENTUAN
- baca data struktur surat di halaman layanan:
	
- baca struktur kuesioner:
	
- kirim data:
	
- notifikasi:




*/?>