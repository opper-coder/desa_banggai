torikulhuda0
torikulhuda17
ikuldjoy71

12345678
112233
wellcome
wellcometome
Wellcome123
qwerty123
Qwerty123



CATATAN LAYANAN SURAT

1. 	a. sktmpersalinan
	b. sktmkis
	c. sktmsekolah 
2. surat pengantar perkawinan
	surat
		n1
		n2
		n3
		n4
		n5
		n6
		n7
		n8
3. surat keterangan kelakuan baik
4. surat keterangan domisili
5. surat permohonan kredit bank
6. surat keterangan usaha
7. surat jual beli
8. surat izin keramaian
9. surat kuasa
10. surat keterangan pindah
11. surat pengantar pembuatan kk


CATATAN wireframe

user request lewat form quesioner dikirim lewat post
	-> untuk disimpan database surat / blm ngerti
	-> untuk identifier nik
		- kirim data surat apa yang di akses
		- kirim data quesioner
		- tentu theme dan iddesa 

ditangkap di halaman surat
	-> data diatas 
		- akses switch surat
		- tangkap data ke array surat / belum ngerti
		- olah surat dari fsurat php yang sudah tersedia beserta ukuran surat nya 
		- simpan data nomor surat dan data surat serta data pemohon


CATATAN LOGIN 
	- di sistem login harapanya ada iddesa=desa bersangkutan 
	- 

di layananan dipelukan 

- badge kiriman 
- daftar layanan dan badge
- klik daftar permohonan 
- data permohonan 
- tombol kirim status
- tombol verify

