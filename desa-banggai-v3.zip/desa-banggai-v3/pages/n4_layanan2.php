<?php 
	$judulHalaman = "DAFTAR LAYANAN";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$gambarJumbotron = "../assets/saiti/ilustrasi/layanan.jpg";
	$hrefBack = "n3_layanan.php?theme=$theme&iddesa=$iddesa";
	$kategori = $_GET['kategori'];
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
	require '../view/jumbotron.php';
	require '../core/init.php';
?>
<!-- body----- -->
<?php 
$querylayanan = "SELECT * FROM layanan WHERE desa='$iddesa' OR desa='umum' AND kategori='$kategori'";
$result = mysqli_query($conn, $querylayanan);
 ?>

<div class="containerBaca">
	<?php  
	while ($datalayanan = mysqli_fetch_assoc($result)):?>
		<?php $idlayanan=$datalayanan["id"]; $kodesurat=$datalayanan["kodesurat"];?>
		<a href="n5i_layanan3.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&idlayanan=<?= $idlayanan; ?>&kodesurat=<?= $kodesurat; ?>">
		<div class="w3-white w3-card w3-round w3-padding w3-small avatar" >
			<img src="../assets/saiti/iconThumb/surat2.png" alt="personal" class="w3-circle" style="width: 60px;">
			<p><b style="font-size: 12px; text-transform: uppercase;"><?= $datalayanan["nama"]; ?></b>
		</div>
		</a>
	<?php endwhile ?>

<?php 
if ($kategori == "pemdes") {?>
	<a href="#">
	<div class="w3-white w3-card w3-round w3-padding w3-small avatar" >
		<img src="../assets/saiti/iconUi/layanan.jpg" alt="personal" class="w3-circle" style="width: 60px;">
		<p><b style="font-size: 12px;">= USULKAN LAYANAN LAIN MELALUI PESAN =</b>
	</div>
	</a>
<?php
}else{ ?>
	<a href="#">
	<div class="w3-white w3-card w3-round w3-padding w3-small avatar" >
		<img src="../assets/saiti/iconUi/layanan.jpg" alt="personal" class="w3-circle" style="width: 60px;">
		<p><b style="font-size: 12px;">= LAYANAN DALAM PROSES PENGEMBANGAN =</b>
	</div>
	</a>
<?php } ?>	
</div>

	<?php require '../view/bottom_body.php' ?>