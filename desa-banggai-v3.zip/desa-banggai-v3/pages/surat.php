<?php 
// generate no surat
// buatkan function untuk table kuesioner
// function tembusan
// func ttd
// func lampiran
// func lembar berikutnya

 ?>

<?php 	
	$judulHalaman = "SURAT";
	// $theme = $_GET['theme'];
	// $surat = $_GET['surat'];
	

	// METODE PENGAMBILAN DATA INI BERDASAR DATABSE
	$iddesa = "Saiti"; // $iddesa = $_GET['iddesa'];
	$idkec = "Nuhon";
	$idkab = "Banggai";
	$sekret = "kantor desa saiti kotak pos 94753";
	$logodesa = "logoSaiti.png";
	$initsurat = "ST";
	$kodesurat = 333;
	// $hrefBack = "#";


	require '../view/top_body.php';
	require '../view/center_body.php';
	require '../core/init.php';
	// require $theme;
	// require '../view/navback.php';
	
?>
<!-- kop surat -->
<div class="kertasA4">
	<header class="kopSurat">
		<img src="../img/logo Banggai.png" alt="">
		<h5 style="text-transform: uppercase;">
			<b>
				<span>PEMERINTAH DAERAH KABUPATEN BANGGAI</span>
			</b><br>
			<span style="font-size: 26px;">DESA SAITI KEC. NUHON</span><br>
			<span style="text-transform: capitalize;">Sekretasriat : Kantor Desa Saiti Kotak Pos 94753</span>
		</h5>
		<img src="../img/logoSaiti.png" alt="">
	</header>
<!-- perihal -->
	<div class="jarak20" style="border-top: 1px solid black; margin-top: 1px"></div>
	<div class="perihal">
		<table class="w3-text-black">
			<tr>
				<td>Nomor</td>
				<td style="padding-left: 10px;">:</td>
				<td><?php nosurat("sktm"); ?></td>
			</tr>
			<tr>
				<td>Lampiran</td>
				<td style="padding: 0 5px 0 10px;"> :</td>
				<td><b>2 lembar</b></td>
			</tr>
			<tr>
				<td>Perihal</td>
				<td style="padding-left: 10px;">:</td>
				<td><b>Surat Keterangan Tidak Mampu</b></td>
			</tr>
		</table>
	</div>
<!-- kepada -->
<div class="jarak20"></div>
	<div class="kepada">
		<p style="padding-left: 20px;"><b>Kepada Yth:</b></p>
		<p>Kepala Kantor BPKAD </p>
		<p>Kab. Banggai</p>
		<p>di-</p>
		<b style="text-decoration: underline; padding-left: 40px;">Banggai</b>
	</div>

<!-- body surat -->
<div class="jarak20"></div>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellendus voluptas hic, placeat, animi alias veniam soluta unde fugiat et expedita nihil ratione accusantium vero error aliquam       assumenda ipsum dolor amet enim similique, modi atque! Nobis id ipsum sed officiis, totam rerum expedita voluptas. Officia iusto recusandae labore assumenda aspernatur voluptates libero ducimus odit facere, minus aperiam sed ullam, eveniet nostrum doloremque unde eligendi. Ad tenetur iste deserunt at, eos adipisci nesciunt eum deleniti, magnam recusandae minima placeat officia quis quod, eveniet blanditiis. Quia, amet nobis facilis eum impedit, repellendus dolore voluptate vel laudantium fuga rerum, aliquid dolorem at sapiente possimus.</p><br>

	<p>     Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ullam eius, suscipit hic qui illo, voluptates cupiditate fugiat eaque magnam! Omnis quas, recusandae porro dignissimos. Commodi cumque natus ut similique, laborum.</p><br>

	<p>Demikian surat ini kami buat, Atas perhatianya kami ucapkan Terima kasih</p>
	<br><br>

	<div class="container">
		<div class="container">Saiti, 22 Desember 2019</div>
		<div class="jarak30"></div>
		<div class="kotakTtd">
			<div class="ttd1">
				<p>Mengetahui</p>
				<p>Kepala Desa Saiti kecamatan Nuhon</p>
				<div class="jarak40"></div>
				<div class="jarak40"></div>
			</div>
			<div class="ttd2">
				<p>Mengetahui</p>
				<p>Kepala Desa Saiti</p>
				<div class="jarak40"></div>
				<div class="jarak40"></div>
			</div>
			<div class="ttd3">
				<p>Mengetahui</p>
				<p>Kepala Desa Saiti</p>
				<div class="jarak40"></div>
				<div class="jarak40"></div>
				
			</div>

			<b class="ttd1 nmttd">Lamudi</b>
			<b class="ttd2 nmttd">Lamudi</b>
			<b class="ttd3 nmttd">Lamudi</b>
		</div>
</div>
</div>






<!-- ---------------------debug2---------------------- -->
<div>
	<h2 style="background-color: salmon;">debug2</h2>

	<?php 
	$kertas = "kertasA4";
	$lampiran = "3 lembar";
	$perihal = "Surat keterangan tidak mampu ini";

	$jabatan1 = 1;
	$jabatan2 = "camat";
	$jabatan3 = "yang bersangkutan";

	$pejabat1 = "lamudi" ;
	$pejabat2 = "haryanto" ;
	$pejabat3 = "hataba sahabo" ;
	 ?>

	<div class="<?= $kertas; ?>">

	<?php 
// -------------------- lampiran

	sktm("nik", "perihal");
	echo "<br>";
	nosurat("ksk");
	kopsurat();
	perihal($lampiran, $perihal);
	kepada("kepala kantor departemen pendidikan");
	salam();
	isisurat();
	penutup();
	ttd(
		$jabatan1,
		$jabatan2,
		$jabatan3,

		$pejabat1,
		$pejabat2,
		$pejabat3
		);

// --------------------
	 ?>
	</div>
</div>	
<!-- ---------------------debug3---------------------- -->
<h2 style="background-color: salmon;">debug3</h2>

<!-- ------------- -->
<div class="<?= $kertas; ?>"> 	
	<?php 
	sktmpersalinan("7201132509040001");
	 ?>
</div>

<!-- ---------------------debug4---------------------- -->
<h2 style="background-color: salmon;">debug4</h2>

<div class="<?= $kertas; ?>">	
	<?php 
	sktmkis("7201132509040001");
	 ?>
</div>
<!-- ---------------------debug5---------------------- -->
<h2 style="background-color: salmon;">debug5</h2>

<div class="<?= $kertas; ?>">	
	<?php 
	sktmsekolah("7201132509040001");
	 ?>
</div>
<!-- ---------------------debug6---------------------- -->
<h2 style="background-color: salmon;">debug5</h2>

<div class="<?= $kertas; ?>">	
	<?php 
	skdomisili("7201132509040001");
	 ?>
</div>
<!-- ------------ -->












<?php require '../view/bottom_body.php' ?>