<?php 	
	$judulHalaman = "ISI ARSIP";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$gambarJumbotron = "../assets/ilustrasi/baca.jpg";
	$ilustrasiBerita = "../assets/ilustrasi/pengumuman3.jpg";
	$hrefBack = "n25_profil_artikel.php?theme=$theme&iddesa=$iddesa";
 
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
	require '../view/jumbotron.php';
?>

<div class="containerBaca w3-white w3-card w3-round w3-border w3-padding" style="margin-top: 20px;">
	<h3>Isi Artikel</h3>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maiores deleniti sapiente facere delectus porro, aperiam quasi, molestias dolore nisi obcaecati incidunt. Iste fuga reiciendis laboriosam quos facere consequatur id earum?</p>
	<img src="<?= $ilustrasiBerita; ?>" alt="gambar tidak tersedia" style="width: 70%">
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maiores deleniti sapiente facere delectus porro, aperiam quasi, molestias dolore nisi obcaecati incidunt. Iste fuga reiciendis laboriosam quos facere consequatur id earum?</p>
</div>

<?php require '../view/bottom_body.php' ?>