<?php   
  $judulHalaman = "SEBARAN COVID-19";
  $theme = $_GET['theme'];
  $iddesa = $_GET['iddesa'];
  $hrefBack = "../origin/saiti.php";
 
  require '../view/top_body.php';
  require $theme;
  require '../view/center_body.php';
  require '../view/navback.php';
  require '../core/init.php';

$datacovid = query("SELECT * FROM covid WHERE desa = 'saiti'");
$querycovid = "SELECT * FROM covid ";
$resultcovid = mysqli_query($conn, $querycovid);
$kordinatcovid = mysqli_query($conn, $querycovid);
$queryjumlahlat = "SELECT count(lat) as jumlah FROM covid";
$resultqueryjumlahlat = mysqli_query($conn, $queryjumlahlat);

// --->baris di bawah ini hapus jika sudah di gunakan debug
// echo'<br><br>';
$arrkordinatlat=[]; 
$arrkordinatlng=[]; 
while ($row = mysqli_fetch_assoc($kordinatcovid)) {
  // echo $row['lat']."--".$row['lng'];echo'<br>';
  $korlat = $row['lat'];
  $korlng = $row['lng'];
  array_push($arrkordinatlat, $korlat);
  array_push($arrkordinatlng, $korlng);
}
$jsonkordinatlat=json_encode($arrkordinatlat);
$jsonkordinatlng=json_encode($arrkordinatlng);
$jumlahoranginveksi = count($arrkordinatlat);

// --->var_dump

// var_dump($jumlahoranginveksi);

?>
<div class="jarak40"></div>
<!--  -->
    <title>Simple Map</title>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
    <link rel="stylesheet" type="text/css" href="./style.css" />
<style>
  #map {
    height: 100%;
    height: 50%;
  }
  html,
  body {
    height: 100%;
    margin: 0;
    padding: 0;
  }
</style>
<script src="https://unpkg.com/@googlemaps/markerclustererplus/dist/index.min.js"></script>
    <script>
function initMap() {
  const map = new google.maps.Map(document.getElementById("map"), {
    zoom: 12,
    center: { lat: -0.9259136256349427, lng: 122.20857334229197 },
  });
  const labels = "CCCCC";
  const markers = locations.map((location, i) => {
    return new google.maps.Marker({
      position: location,
      label: labels[i % labels.length],
    });
  });
  // Add a marker clusterer to manage the markers.
  new MarkerClusterer(map, markers, {
    imagePath:
      "https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m",
  });
}

/*
const locations = [
  { lat: -0.9236608810308601, lng: 122.20919563481282 },
  { lat: -0.922781230698211, lng: 122.20745756343443 },
  { lat: -0.9274923231635913, lng: 122.20779942441754 },
  { lat: -0.9274548944915929, lng: 122.21100127079323 },
  { lat: -0.9278519494878028, lng: 122.21107572836252 }, 
];
*/
const locations =[];
var jumlorgpositif = <?= $jumlahoranginveksi; ?>;
var latittude = <?= $jsonkordinatlat; ?>;
var longitude = <?= $jsonkordinatlng; ?>;
for (var i = 0; i < jumlorgpositif; i++) {
  locations.push({lat:parseFloat(latittude[i]),lng:parseFloat(longitude[i])});
}
</script>
  </head>
  <body>
      <div id="map"></div>
<!-- ---------------- -->
<div class="containerBaca">
<div class="jarak20"></div>
<div>
  <strong>Daftar Nama Warga positif COVID-19</strong>
  <div class="jarak10"></div>
  <p>Sumber Data : Puskesmas Desa Saiti</p>
  <p>Update : 8 September 2021</p>
<table>
  <thead>
     <th>No.</th>
     <th>Nama</th>
     <th>Usia</th>
     <th>Dsn/RT</th>
     <th>Ket</th>
  </thead>
  <tbody>
      <?php  
    $i=1; 
    while($row = mysqli_fetch_assoc($resultcovid)){?>
      <tr>
        <td><?= $i; ?></td>
        <td style="text-transform:capitalize;"><?= $row['nama'];?></td>
        <td style="text-transform:capitalize;"><?= $row['umur'];?></td>
        <td style="text-transform:capitalize;"><?= $row['alamat'];?></td>
        <td style="text-transform:capitalize;"><?= $row['status'];?></td>
      </tr>
    <?php  $i++; } ?>
  </tbody>
</table>

  <ol>
    <?php  
    $i=1; 
    while($row = mysqli_fetch_assoc($resultcovid)){?>
      <li style="text-transform:capitalize;"><span><?= $i . ". "; ?> </span><?= $row['nama'];?></li>
    <?php  $i++; } ?>
  </ol>

<table>
  
</table>


</div>

<!-- ====================== -->


    <script
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBcnL4K4mX2vx7Wd62taS0j8elqib6mEAY&callback=initMap&libraries=&v=weekly" async>
    </script>
  </body>
</html>

<!-- keyKU=AIzaSyBcnL4K4mX2vx7Wd62taS0j8elqib6mEAY -->