<?php 
	$judulHalaman = "TABEL STATISTIK";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	// $gambarJumbotron = "../assets/saiti/ilustrasi/mitra.jpg";
	$hrefBack = "n8_statistik2.php?theme=$theme&iddesa=$iddesa&statistik=penduduk";
	$statistikList = $_GET['statistikList'];
	$data = $_GET["kolom"];
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
	// require '../view/jumbotron.php'; 
	require '../core/init.php';				

// $fieldDbase=["kk", "suku", "dusun", "bumil","bayi","tk","sd","smp","sma","s1","s1","difabel","pkh","rastra"];
// var_dump($_GET["kolom"]);
?>
<?php $datamasuk =query("SELECT max(datamasuk) as jumlah FROM penduduk WHERE desa='$iddesa'");
$tanggal = $datamasuk["jumlah"];
?>

<div class="jarak40" style="background-color: #3e82a7"></div>
<div class="jumbotron2" style="background-color: #3e82a7">
	<img src="../assets/saiti/ilustrasi/mitra.jpg" alt="gambar ilustrasi" >
</div> 

<div class="jarak30"></div>
<div class="containerBaca w3-white w3-border w3-round">
	<h4 style="text-align: center; text-transform: uppercase;"><?= $statistikList; ?></h4>
	<p class="w3-small" style="text-align: center; margin-top: -14px">data per, <?= $tanggal; ?></p>
	<table class="w3-table w3-striped w3-small">
		<tr class="w3-theme-l4">
			<th>No.</th>
			<th>Uraian</th>
			<th>Jumlah item</th>
			<th>Alamat</th>
		</tr>
		<tr>
			<td>1</td>
			<td>
<?php 
switch ($data) {
	case 'kk':
		echo "Jumlah KK di semua dusun";
		break;
	case 'suku':
		echo "Jumlah Suku warga desa Saiti";
		break;
	case 'dusun':
		echo "Jumlah dusun";
		break;
	case 'bumil':
		echo "Jumlah ibu hamil desa Saiti";
		break;
	case 'bayi':
		echo "Jumlah bayi usia di bawah 1 th";
		break;
	case 'tk':
		echo "Jumlah anak sekolah tingkat TK";
		break;
	case 'sd':
		echo "Jumlah anak sekolah tingkat SD";
		break;
	case 'smp':
		echo "Jumlah anak sekolah tingkat SLTP";
		break;
	case 'sma':
		echo "Jumlah anak sekolah tingkat SLTA";
		break;
	case 's1':
		echo "Jumlah Warga sedang kuliah";
		break;
	case 's1':
		echo "Jumlah Sarjana";
		break;
	case 'difabel':
		echo "Jumlah Warga penderita Difabel";
		break;
	case 'pkh':
		echo "Jumlah Warga penerima PKH";
		break;
	case 'rastra':
		echo "Jumlah Warga penerima Rastra";
		break;
	default:
		echo "pilih data yang ingin di tampilkan";
		break;
} ?>
			</td>
			<td>
<?php 



switch ($data) {
	case 'kk':
		$jumlah = query("SELECT count(id) as jumlahx FROM penduduk  WHERE  kk=1 AND desa='$iddesa'");
		echo $jumlah["jumlahx"];
		break;
	case 'suku':
		$jumlah = query("SELECT count(DISTINCT suku) as jumlahx FROM penduduk WHERE desa='$iddesa' "); 		
		echo $jumlah["jumlahx"];
		break;
	case 'dusun':
		$jumlah = query("SELECT count(DISTINCT dusun) as jumlahx FROM penduduk WHERE desa='$iddesa' "); 	
		echo $jumlah["jumlahx"];
		break;
	case 'bumil':
		$jumlah = query("SELECT count(bumil) as jumlahx FROM penduduk WHERE bumil=1 AND desa='$iddesa'"); 		
		echo $jumlah["jumlahx"];
		break;
	case 'bayi':
		$jumlah = query("SELECT count(bayi) as jumlahx FROM penduduk WHERE bayi=1 AND desa='$iddesa' "); 
		echo $jumlah["jumlahx"];
		break;
	case 'tk':
		$jumlah = query("SELECT count(tk) as jumlahx FROM penduduk WHERE tk=1 AND desa='$iddesa' "); 
		echo $jumlah["jumlahx"];
		break;
	case 'sd':
		$jumlah = query("SELECT count(sd) as jumlahx FROM penduduk WHERE sd=1 AND desa='$iddesa' "); 
		echo $jumlah["jumlahx"];
		break;
	case 'smp':
		$jumlah = query("SELECT count(smp) as jumlahx FROM penduduk WHERE smp=1 AND desa='$iddesa' "); 
		echo $jumlah["jumlahx"];
		break;
	case 'sma':
		$jumlah = query("SELECT count(sma) as jumlahx FROM penduduk WHERE sma=1 AND desa='$iddesa' "); 
		echo $jumlah["jumlahx"];
		break;
	case 's1':
		$jumlah = query("SELECT count(s1) as jumlahx FROM penduduk WHERE s1=1 AND desa='$iddesa' "); 
		echo $jumlah["jumlahx"];
		break;
	case 's1':
		$jumlah = query("SELECT count(s1) as jumlahx FROM penduduk WHERE s1=1 AND desa='$iddesa' "); 
		echo $jumlah["jumlahx"];
		break;
	case 'difabel':
		$jumlah = query("SELECT count(difabel) as jumlahx FROM penduduk WHERE difabel=1 AND desa='$iddesa' "); 
		echo $jumlah["jumlahx"];
		break;
	case 'pkh':
		$jumlah = query("SELECT count(pkh) as jumlahx FROM penduduk WHERE pkh=1 AND desa='$iddesa' "); 
		echo $jumlah["jumlahx"];
		break;
	case 'rastra':
		$jumlah = query("SELECT count(rastra) as jumlahx FROM penduduk WHERE rastra=1 AND desa='$iddesa' "); 
		echo $jumlah["jumlahx"];
		break;
	default:
		echo "data tidak terekam...";
		break;
}
 ?>
			</td>
			<td>Desa Saiti</td>
		</tr>	
<!-- --- -->
	</table>
</div>


<?php require '../view/bottom_body.php' ?>