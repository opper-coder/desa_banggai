<?php 
	$judulHalaman = "DAFTAR STATISTIK";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$statistik = $_GET['statistik'];
	// $gambarJumbotron = "../assets/ilustrasi/layanan4.jpg";
	$hrefBack = "n7_statistik.php?theme=$theme&iddesa=$iddesa";
	
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
	// require '../view/jumbotron.php'; 
	require '../core/init.php';
?>
<div class="jarak40" style="background-color: #3e82a7"></div>
<div class="jumbotron2" style="background-color: #3e82a7">
	<img src="../assets/saiti/ilustrasi/mitra.jpg" alt="gambar ilustrasi" >
</div> 


<?php // ============== halaman butuh login ===========
if( !isset($_SESSION['user']) ){
	// die('anda belum login');
	header ( 'Location: ../functions/login.php' );
}
// ============== /halaman butuh login ===========  ?>

<?php 
$daftarStatistik = ["Jumlah KK", "Jumlah Suku", "Jumlah warga per dusun", "Jumlah Ibu hamil", "jumlah Bayi 1th","jumlah Anak sekolah tingkat TK", "jumlah Anak sekolah tingkat SD", "jumlah Anak sekolah tingkat SLTP", "jumlah Anak sekolah tingkat SLTA", "jumlah Anak sekolah tingkat Kuliah", "jumlah lulusan Sarjana", "jumlah penderita Difabel","jumlah warga PKH", "jumlah warga Rastra"];
$fieldDbase=["kk", "suku", "dusun", "bumil","bayi","tk","sd","smp","sma","s1","s1","difabel","pkh","rastra"];
$i=0;
 ?>



<div class="containerBaca">
<?php 
if ($statistik == "penduduk") {  
	While($i < count($daftarStatistik) ){ ?>	
		<a href="n9_statistik3.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&statistikList=<?= $daftarStatistik[$i]; ?>&kolom=<?= $fieldDbase[$i] ?>">
			<div class="w3-white w3-card w3-round w3-padding w3-small avatar" >
			<img src="../assets/saiti/iconThumb/orang.png" alt="personal" class="w3-circle" style="width: 60px;">
			<p><b style="font-size: 12px;"><?= $daftarStatistik[$i]; ?></b>
			</div>
		</a>
	<?php $i++; } 
}elseif ($statistik == "aset") { ?>
	<p style="background-color:salmon;
			margin:40px 16px 0px 16px;
			border-radius: 10px;
			padding: 15px;
			color: White;
			text-align: center;
			">halaman aset desa masih dalam pengembangan</p>
<?php 
}else{?>
	<p style="background-color:salmon;
			margin:40px 16px 0px 16px;
			border-radius: 10px;
			padding: 15px;
			color: White;
			text-align: center;
			">halaman ini desa masih dalam pengembangan</p>
<?php } ?>
</div>


	







<ul>
	<!-- <b>profil desa</b>
		<li>pemdes</li>
		<li>program desa</li>
		<li>-</li>
		<br>
		<li>bpd</li>
		<li>rt/rw</li>
		<li>pkk</li>
		<li>karang taruna</li>
		<li></li>
	<b>sarana umum</b>
		<li>lapangan</li>
		<li>pasar</li>
		<li>kolam</li>
		<li>pendidikan</li>
		<li>air bersih</li>
		<li>peribadatan</li>
		<li>irigasi</li>
		<li>olahraga</li>
		<li>bangunan</li>
		<li></li>
	<b>asset</b>
		<li>kendaraan</li>
		<li>tanah</li>
		<li>bumdes</li>
		<li></li>
	<b>kependudukan</b>
		<li>jumlah kk</li>
		<li>laki2</li>
		<li>perempuan</li>
		<li>usia</li>
		<li>kwalitas bumil</li>
		<li>bayi</li>
		<li>persalinan</li>
		<li>kb</li>
		<li></li> -->
		<li></li>
</ul>


	<?php require '../view/bottom_body.php' ?>
