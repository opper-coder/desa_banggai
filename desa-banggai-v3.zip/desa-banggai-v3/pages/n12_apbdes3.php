<?php 

	$judulHalaman = "DAFTAR PEMBANGUNAN";
	$thanggaran = $_GET["thanggaran"];
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$gambarJumbotron = "../assets/saiti/ilustrasi/ekonomi.png";
	$hrefBack = "n11_apbdes2.php?theme=$theme&iddesa=$iddesa&thanggaran=$thanggaran";
 
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
	require '../view/jumbotron.php';
	require '../core/init.php';
?>


<?php // ============== halaman butuh login ===========

if( !isset($_SESSION['user']) ){
	// die('anda belum login');
	header ( 'Location: ../functions/login.php' );
}

// ============== /halaman butuh login ===========  ?>



<!-- isi body -->
<?php 

$queryLBangunan = "SELECT * FROM apbdesout WHERE desa='$iddesa' AND thanggaran='$thanggaran' ";
$resultLBangunan = mysqli_query($conn, $queryLBangunan);

while ($dataLBangunan = mysqli_fetch_assoc($resultLBangunan)) { ?>
	<?php $idbelanja= $dataLBangunan["id"]; ?>
	
<div class="jarak30"></div>
	<a href="n13_apbdes4.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&thanggaran=<?= $thanggaran?>&idbelanja=<?=$idbelanja?>" style="text-decoration: none">
	<div class="containerBaca listBangunan w3-card w3-white w3-round">
		<div class="gambarCn">
			<img src="../img/<?= $dataLBangunan['foto1'] ?>.jpg" alt="gambar tidak tersedia" class="gambar">
		</div>
		<div class="marginKr10">
			<b style="text-transform: capitalize;"><?= $dataLBangunan["posbelanja"]; ?></b> <br>
			<p class="w3-small"><?= $dataLBangunan["alamat"]; ?></p>
			<p class="jarak10"></p>
			<span>progress</span><p class="marginKr5 w3-round w3-tag w3-pink w3-small "><?= $dataLBangunan["progress"]; ?>%</p>
			<p class="jarak5"></p>
			<div class="progressCn marginB5">
				<div class="progressCn2">
					<div class="progress w3-theme" style="width: <?php echo $dataLBangunan["progress"]; ?>%; "></div>
				</div>
			</div>
		</div>
	</div>
	</a>
<?php } ?>

	<?php require '../view/bottom_body.php' ?>
