<?php 	
	$judulHalaman = "KATEGORI STATISTIK";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$gambarJumbotron = "../assets/saiti/ilustrasi/statistik.jpg";
	$hrefBack = "../origin/saiti.php";
 
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
	require '../view/jumbotron.php';
?>
<!-- <a href="../pages/baca_inspirasi.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>" >buka halaman dan kirim get</a> -->

<div class="menuHomeCn">
		<div class="menuHome satu w3-card-2 w3-small" style="text-align: center;">
			<a href="n20_profil_desa.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&statistik=profil">
			<img src="../assets/saiti/iconUi/profil.jpg" alt="">
			</a>
			<a href="n20_profil_desa.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&statistik=profil" style="text-decoration: none;">
			<span >Profil<br><b>Desa</b></span>
			</a>
		</div>
		<div class="menuHome w3-card-2 w3-small" style="text-align: center;">
			<a href="n8_statistik2.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&statistik=sarana">
			<img src="../assets/saiti/iconUi/sarana.jpg" alt="">
			</a>
			<a href="n8_statistik2.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&statistik=sarana" style="text-decoration: none;">
			<span >Statistik<br><b>Sarana Umum</b></span>
			</a>
		</div>
		<div class="menuHome tiga w3-card-2 w3-small" style="text-align: center;">
			<a href="n8_statistik2.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&statistik=aset">
			<img src="../assets/saiti/iconUi/aset.jpg" alt="">
			</a>
			<a href="n8_statistik2.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&statistik=aset" style="text-decoration: none;">
			<span >Statistik<br><b>Aset Desa</b> </span>
			</a>
		</div>
		<div class="menuHome w3-card-2 w3-small" style="text-align: center;">
			<a href="n8_statistik2.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&statistik=penduduk">
			<img src="../assets/saiti/iconUi/kependudukan.jpg" alt="">
			</a>
			<a href="n8_statistik2.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>&statistik=penduduk" style="text-decoration: none;">
			<span >Statistik<br><b>kependudukan</b></span>
			</a>
		</div>
	</div>
	<?php require '../view/bottom_body.php' ?>