<?php 
	$judulHalaman = "DATA LAYANAN";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$gambarJumbotron = "../assets/saiti/ilustrasi/layanan.jpg";
	$hrefBack = "n6_status_layanan.php?theme=$theme&iddesa=$iddesa";
	$edit = $_GET['edit'];
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
	require '../view/jumbotron.php';
	require '../core/init.php';
	$idd=$_GET['idd'];	//????????????????? terima dari get/post
	// $idf=$_GET['idf'];	//????????????????? terima dari get/post kayaknya g di gunakan ini
	$postku=$_POST;
// ------------------ cek login -------------------
if( !isset($_SESSION['user']) ){
	// die('anda belum login');
	header ( 'Location: ../functions/login.php' );
}
// ------------------------------------------------
if ($edit == 'true') {
	$display="block";
	$label ="Silahkan perbaiki data di bawah ini:";
}else{
	$display="none";
	$label ="Data anda yang pernah di terbitkan:";
}
// -------------------------------------------------
// ===================================================>
$datafield = query("SELECT * FROM suratkeluar WHERE id='$idd'");
echo "<br>";
// $formulir = query("SELECT quesioner FROM layanan WHERE id='$idf'");
// ===================================================>
// ---------------  urai string ---------------
	function uraiString($data){
		$urai1 = explode(",", $data);
		$arraydata =[];
			for ($i=0; $i < count($urai1); $i++) {
				$arraydata [] = explode("=>", $urai1[$i]);
			}
		$dataquesioner2 = [];
			for ($k=0; $k < count($urai1); $k++) { 
				$dataquesioner2[$arraydata[$k][0]] = $arraydata[$k][1];
			}	
		return ($dataquesioner2);
	}
	$arrayDataField = uraiString($datafield['data']);
/* --------------- bikin field --------------->
	bikin field quesioner dari array assoc di atas*/
	function fField($arrayDataField){
		foreach ($arrayDataField as $key => $value) { ?>
			<label class="huruf12" for="<?= $key ?>"style="text-transform: capitalize;"><?= $key; ?> :</label>
			<div class="jarak5"></div>
			<input type="text" class="w3-input w3-small w3-round capital" name=<?= $key;?> id=<?= $key; //dibelakang ini boleh tulis required?> value="<?php echo $value; ?>"> 
			<div class="jarak10" ></div>
	<?php }
	}
/* -------- tangkap data dan convert ke field ---------- */
function fdatakirim($arraypost){
	$key = array_keys($arraypost);
	$val = array_values($arraypost);
	$datakirim=[];
	for ($i=0; $i < count($arraypost); $i++) { 
		$datakirim[] = $key[$i] . "=>" . $val[$i] . ",";
	}
	$data = implode($datakirim);
	$data2 = substr($data, 0, -1);
	return $data2;
}
$dataku=fdatakirim($postku);
/* --------------- queri insert ----------------
edit data berikut ke db -> 
*/
function ubahdata($fielddb, $id, $datafield){
	global $conn;
	// $data1  = htmlspecialchars($fielddb["id"]);
	$data2  = htmlspecialchars($fielddb["idlayanan"]);
	$data3  = htmlspecialchars($fielddb["nomor"]);
	$data4  = htmlspecialchars($fielddb["urut"]);
	// $data5  = htmlspecialchars($fielddb["data"]);
	$data6  = htmlspecialchars($fielddb["pemohon"]);
	$data7  = htmlspecialchars($fielddb["nikpemohon"]);
	$data8  = htmlspecialchars($fielddb["penerbit"]);
	$data9  = htmlspecialchars($fielddb["sender"]);
	$data10 = htmlspecialchars($fielddb["perihal"]);
	$data11 = htmlspecialchars($fielddb["tglmasuk"]);
	$data12 = htmlspecialchars($fielddb["tglterbit"]);
	$data13 = htmlspecialchars($fielddb["verifikasi"]);
	$data14 = htmlspecialchars($fielddb["pesan"]);
	$data15 = htmlspecialchars($fielddb["desa"]);
		$query = "UPDATE suratkeluar SET 

				id 			= $id, 
				idlayanan 	= $data2,
				nomor 		='$data3',
				urut 			= $data4,	
				data 			='$datafield',
				pemohon 		='$data6',
				nikpemohon 	='$data7',
				penerbit 	='$data8',
				sender 		='$data9',
				perihal 		='$data10',
				tglmasuk 	= $data11,
				tglterbit 	= $data12,
				verifikasi 	='$data13',
				pesan 		='$data14',
				desa 			='$data15'

			  WHERE id = '$id' 
			  ";
	mysqli_query($conn, $query);
	return mysqli_affected_rows($conn);
}
function tekantbledit(){
	global $datafield, $idd, $dataku, $iddesa, $theme;
	if( isset($_POST['edit']) ){
	 	ubahdata($datafield, $idd, $dataku);
	 	?>
		<script>
			alert('data berhasil di ubah!');
			document.location.href = 'n6_status_layanan.php?iddesa=<?= $iddesa; ?>&theme=<?= $theme; ?>';
		</script>
	<?php } 
}
array_pop($arrayDataField); 
tekantbledit();
// var_dump($arrayDataField);
// ====================================================
/*
aturan  yang akan kita buat disini adalah:
= ambil baris data[id] dari yang akan di edit
= ambil field "kuesionernya"
= bikin form berisi data quesioner editable
= ubah oleh user
= kirim data ke post ("dataku")
= ubah data sesuai id
= gunakan data[id] dan dataku untuk edit
= berikan alert data berhasil di buat

- DI DBASE FIELD DATA ADA ARRAY KEY EDIT SILAHKAN HAPUS
*/
// ---------------- end ---------------------
?>
<style>
	.row{
		display: grid;
	}
	.jarak{
		margin-bottom:5px ;
	}
	.wadah{
		padding: 20px 0;
	}
	.tombol{
		display: <?= $display; ?>;
	}
	.capital{
		text-transform: capitalize;
	}
</style>
<div class="jarak20"></div>
<div class="containerBaca w3-theme-l3 wadah">
	<form action="" method="post" class="containerBaca">
		<div class="row">
			<label for=""><?= $label; ?></label>
			<div class="jarak5"></div>
			<?php fField($arrayDataField); ?>
		</div>
		<div class="jarak20"></div>
		<button type="submit" id="kirim" class="tombol w3-theme-d4 w3-btn w3-round" name="edit">Simpan perubahan</button>
	</form>
</div>
<?php /* --------------------------- selesai -> */  ?>