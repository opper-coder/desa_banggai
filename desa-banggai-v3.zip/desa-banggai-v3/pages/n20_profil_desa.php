<?php 	
	$judulHalaman = "KATEGORI PROFIL";
	$theme = $_GET['theme'];
	$iddesa = $_GET['iddesa'];
	$gambarJumbotron = "../assets/ilustrasi/team2.jpg";
	$hrefBack = "n7_statistik.php?theme=$theme&iddesa=$iddesa";
	require '../view/top_body.php';
	require $theme;
	require '../view/center_body.php';
	require '../view/navback.php';
	require '../view/jumbotron.php';
	require '../core/init.php';
?>
<?php // ============== halaman butuh login ===========
if( !isset($_SESSION['user']) ){
	// die('anda belum login');
	header ( 'Location: ../functions/login.php' );
}
// ============== /halaman butuh login ===========  ?>

<!-- <a href="../pages/baca_inspirasi.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>" >buka halaman dan kirim get</a> -->

<div class="jarak20"></div>
<div class="containerBaca kotakProfil">
	<a href="n21_profil_kelembagaan.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>">
		<div class="profil w3-theme-l3 w3-card">
			<img src="../assets/saiti/iconThumb/kertas.png" alt="" ><br>
			Kelembagaan
		</div>
	</a>
	<a href="n22_profil_program.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>">
		<div class="profil w3-theme-l3 w3-card">
			<img src="../assets/saiti/iconThumb/kertas.png" alt="" ><br>
			Program desa
		</div>
	</a>
	<a href="n23_profil_galeri.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>">
		<div class="profil w3-theme-l3 w3-card">
			<img src="../assets/saiti/iconThumb/kertas.png" alt="" ><br>
			Galeri
		</div>
	</a>
	<a href="n24_profil_hiburan.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>">
		<div class="profil w3-theme-l3 w3-card">
			<img src="../assets/saiti/iconThumb/kertas.png" alt="" ><br>
			Hiburan
		</div>
	</a>
	<a href="n25_profil_artikel.php?theme=<?= $theme; ?>&iddesa=<?= $iddesa; ?>">
		<div class="profil w3-theme-l3 w3-card">
			<img src="../assets/saiti/iconThumb/kertas.png" alt="" ><br>
			Arsip desa
		</div>
	</a>
</div>
<div class="jarak20">.</div>

	<?php require '../view/bottom_body.php' ?>