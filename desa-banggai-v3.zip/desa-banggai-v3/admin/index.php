<?php 	
	$iddesa = "saiti";
	require_once '../view/top_body.php';
	require_once '../view/center_body.php';
	require_once '../core/init.php';
// ============================= function ===============================
// --------------- session login --------------
// if( !isset($_SESSION['user']) ){
// 	// die('anda belum login');
// 	header ( 'Location: ../functions/login.php' );
// }
/* --------------- query ---------------------> */
// ----------------------------style
?>
<style>
	.containerlogin{
		width: 100%;
		height:100%;
		background-color: #585858;
		padding-top: 15%;
		text-align: center;
		position: absolute;
	}
	.kotaklogin{
		width: 60%;
		min-width: 200px;
		max-width: 500px;
		height: 300px;
		background-color:teal;
		margin:10px auto;
		border-radius: 4px;
	}
	.imglogin{
		width: 90px;
		margin: auto;
		display: inline-block;
	}
	.tb{
		background-color: tan;
		margin-top: 20px;
	}
	.wform{
		padding:40px 20px;
	}
	.formini{
		margin: 30px 0px 10px 0px;
	}
</style>
<div class="containerlogin">
	<img src="../assets/saiti/utils/logoSaiti.png" alt="logo saiti" class="imglogin">
	<p class="w3-text-white">Selamat Datang admin!</p>
	<div class="kotaklogin">
		<form action="../dashboard.php" method="POST" class="w3-form wform">
			<input type="text" name="name" class="w3-input w3-round formini" placeholder="Nama..">
			<input type="password" name="name" class="w3-input w3-round formini" placeholder="Password..">
			<button type="submit" name="submit" class="w3-btn w3-round w3-small tb"> Login! </button>
		</form>
	</div>


</div>

<?php require '../view/bottom_body.php' ?>