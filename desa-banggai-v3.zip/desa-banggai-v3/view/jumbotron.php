<div class="jarak40"></div>
<div class="jumbotron2">
	<img src="<?= $gambarJumbotron; ?>" alt="gambar ilustrasi">
</div> 