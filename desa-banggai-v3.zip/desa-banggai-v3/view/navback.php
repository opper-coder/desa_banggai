<div class="navback w3-theme-d2 w3-card w3-padding">
	<a href="<?= $hrefBack; ?>"><img src="../assets/panahKiriP.png" alt=""></a>
	<p><?= $judulHalaman; ?></p>
</div>