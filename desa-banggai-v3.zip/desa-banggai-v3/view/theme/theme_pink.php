	<link rel="stylesheet" type="text/css" media="screen" href="view/css/theme/w3_theme_pink.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="../view/css/theme/w3_theme_pink.css" />