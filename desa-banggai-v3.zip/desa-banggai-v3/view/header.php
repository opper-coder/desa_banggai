<?php 

require_once '../view/top_body.php';
require_once "../core/init.php";    

 ?>


<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="css/owl.carousel.min.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="css/owl.theme.default.min.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="assets/fontawesome-free-5.11.2-web/css/all.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="css/w3.css" />  

    <title>sistem login</title>
    <link rel="stylesheet" type="text/css" media="screen" href="css/index.css" />
    
</head>

<?php 
    $iddesa = $_SESSION["desa"];
 ?>

<body>
    <div class="containerBaca marginB16 w3-white w3-round w3-border w3-padding" >
        <header>
            <h4 class="w3-text-blue">Login dan Register</h4>
            <nav>
                <a href="../origin/<?= $iddesa; ?>.php?iddesa=<?= $iddesa; ?>&theme=<?= $theme; ?>" class="w3-btn w3-border w3-border-green">home</a>
                    <?php 
                    if( !isset($_SESSION['user']) ){ 
                    ?>
                <a href="login.php?iddesa=<?= $iddesa; ?>&theme=<?= $theme; ?>" class="w3-btn w3-border w3-border-green">login</a>
                <a href="../functions/register.php?iddesa=<?= $iddesa; ?>&theme=<?= $theme; ?>" class="w3-btn w3-border w3-border-green">register</a>
                
                    <?php }else{ ?>
                        <a href="logout.php?iddesa=<?= $iddesa ?>" class="w3-btn w3-border w3-border-green">logout</a>
                    <?php } ?>
            </nav>
        </header>
    </div>

<!-- <-7 hapus penutup body dan html dan cut ke footer.html-->
