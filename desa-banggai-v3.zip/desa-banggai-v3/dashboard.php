<?php 
	require_once 'view/top_body.php';
	require_once 'view/center_body.php';
	require_once 'functions/db.php';
	$iddesa = "saiti"; // nanti di ambilkan dari sistem login
	/* BOLEH HAPUS
	debug dulu masih belum di pakai
	$satu = $_GET['satu'];
	$dua = $_GET['dua'];
	$tiga = $_GET['tiga'];
	----

	----
	*/

	// ======= untuk bagian *********** ===========
	// query untuk daftar layanan di dashboard php
	$querylay = "SELECT * FROM layanan WHERE desa='$iddesa' OR desa='umum'"; 
	$resultlay = mysqli_query($conn, $querylay);
	// ============================================

	// ======= untuk bagian inbox layanan ===========
	// query untuk daftar pemohon layanan di dashboard php
	$querylayout = "SELECT * FROM suratkeluar WHERE desa='$iddesa' OR desa='umum' AND idlayanan=1 AND verifikasi <> '4'"; 
	$resultlayout = mysqli_query($conn, $querylayout);
	$datalayout = mysqli_fetch_assoc($resultlayout);
 	
 	$layanan=[];
 	$layananid=[];

	while ($datalay = mysqli_fetch_assoc($resultlay)) {
		$layanan[] = $datalay["nama"];
		$layananid[] = $datalay["id"];
		}

	$jumlayanan = count($layanan);
	// ============================================	



	// ======= untuk bagian arsip surat ===========
	$index5 = 1;
	$queryarsip = "SELECT * FROM suratkeluar WHERE desa='$iddesa' AND verifikasi='4'";
	$resultarsip= mysqli_query($conn, $queryarsip);
	$jumlarsip = (mysqli_num_rows($resultarsip));
	// ============================================



	// ======= untuk bagian *********** ===========
	$layout=[];
	while ($datalayout = mysqli_fetch_assoc($resultlayout)) {
		$layout[] = $datalayout["idlayanan"];
		}
	$jumlayout = count($layout);
	// ============================================

    // $layanan = ['London1','Paris1','Tokyo1'];
    // $jumlayanan = count($layanan);    // berisi jumlah array yang di ulangkan (count/length php)
    
    // ----
    $i = 1;
    $index = 0;    
    $index2 = 0;
    $index3 = 0;
	// ----

			// boleh hapus/////////
			// if( isset($_GET['simpanlatihan'])){
			// 	$query = "INSERT INTO latihan VALUES ('','$satu','$dua','$tiga')";
			// 	$result = mysqli_query($conn, $query);
			// }

				// if(isset($_GET["tbcari"])){
				// 	var_dump($_GET);
				// }
			 ?>

	<div class="contdash">
		<!-- barkanan -->
		<div class="barkanan w3-padding">
			<h2>Dashboard</h2>
			<br><br><br>

<?php 
	// ========= jumlah layanan di badge ==========

	$jumlahlayanan = query("SELECT count(id) as jumlah FROM suratkeluar WHERE desa='$iddesa' AND verifikasi <> '4' ");
	$jumlahlayanan['jumlah'];

				// $jumlahlayanan2 = query("SELECT count(idlayanan) as jumlah FROM suratkeluar WHERE desa='$iddesa' AND idlayanan=1");
				// $jumlahlayanan2['jumlah'];
	// ============================================
 ?>

		<div class="tab1">
			<button class="tablinks1" onclick="openCity1(event, 'kdesa')">Key Desa</button><br><br><br>
			<button class="tablinks1" onclick="openCity1(event, 'dpenduduk')">Data penduduk</button><br><br><br>
		  	<button class="tablinks1" onclick="openCity1(event, 'apbdesin')">Data APBDES masuk</button><br><br><br>
		 	<button class="tablinks1" onclick="openCity1(event, 'apbdesout')">Data APBDES keluar</button><br><br><br> 	
		  	<button class="tablinks1" onclick="openCity1(event, 'layanan')">Data layanan</button><br><br><br>
		  	<button class="tablinks1" onclick="openCity1(event, 'inbox')">Inbox layanan<span class="w3-badge w3-red w3-right"><?= $jumlahlayanan['jumlah']; ?></span></button><br><br><br>
		  	<button class="tablinks1" onclick="openCity1(event, 'arsip')">Arsip Surat<span class="w3-badge w3-blue w3-right"><?= $jumlarsip; ?></button><br><br><br>
		  	<button class="tablinks1" onclick="openCity1(event, 'artikel')">Artikel</button><br><br><br>
		  	<button class="tablinks1" onclick="openCity1(event, 'latihan')">Latihan</button><br><br><br>
		</div>

	</div>
	<!-- /barkanan -->
	<!-- barkiri -->
	<div class="barkiri w3-indigo w3-padding">
		<br><br><br><br>
		
		<div id="kdesa" class="tabcontent1">
		  <h3>Profil desa</h3>
		  <p>Memuat data kunci desa ini, cari, edit, tambahkan data yang baru, berdasaskan field di bawah ini:</p> <br>

			<form action="" method="get" >
				<input type="text" id="cari" name="cari" class="w3-input w3-round-xxlarge">
				<br>
				<button type="submit" class="w3-button w3-blue w3-round w3-card" name="tbcari" style="padding: 7px 50px;">  Cari  </button>
			</form>

		  <br><br><br>
					<form action="" method="get" class="containerformdash">
						<label for="id">id :</label>
						<input type="text" name="id" id="id" class="w3-input w3-small">
						<span></span>
						<label for="namadesa">Nama desa :</label>
						<input type="text" name="namadesa" id="namadesa" class="w3-input w3-small">
						<span></span>					
						<label for="kecamatan">Kecamatan :</label>
						<input type="text" name="kecamatan" id="kecamatan" class="w3-input w3-small">
						<span></span>					
						<label for="kabupaten">Kabupaten :</label>
						<input type="text" name="kabupaten" id="kabupaten" class="w3-input w3-small">
						<span></span>					
						<label for="sekretariat">Sekretariat :</label>
						<input type="text" name="sekretariat" id="sekretariat" class="w3-input w3-small">
						<span></span>					
						<label for="kades">Kades :</label>
						<input type="text" name="kades" id="kades" class="w3-input w3-small">
						<span></span>					
						<label for="sekdes">Sekdes :</label>
						<input type="text" name="sekdes" id="sekdes" class="w3-input w3-small">
						<span></span>					
						<label for="camat">Camat :</label>
						<input type="text" name="camat" id="camat" class="w3-input w3-small">
						<span></span>					
						<label for="bupati">Bupati :</label>
						<input type="text" name="bupati" id="bupati" class="w3-input w3-small">
						<span></span>					
						<label for="hp">Hp :</label>
						<input type="text" name="hp" id="hp" class="w3-input w3-small">
						<span></span>					
						<label for="kodepos">Kodepos :</label>
						<input type="text" name="kodepos" id="kodepos" class="w3-input w3-small">
						<span></span>					
						<label for="initsurat">Inisial surat :</label>
						<input type="text" name="initsurat" id="initsurat" class="w3-input w3-small">
						<span></span>					
						<label for="theme">Theme :</label>
						<input type="text" name="theme" id="theme" class="w3-input w3-small">
						<span></span>					
						<label for="logodesa">Logo desa :</label>
						<input type="text" name="logodesa" id="logodesa" class="w3-input w3-small">
						<span></span>					
						<label for="desa">Desa :</label>
						<input type="text" name="desa" id="desa" class="w3-input w3-small">

						<br><br><br>
						
						<span></span>
						<button type="submit" class="w3-button w3-blue  w3-round w3-card">edit!</button>
						<span></span><span></span>
						<button type="submit" class="w3-button w3-green  w3-round w3-card">Simpan!</button>
						<span></span><span></span>
						<button type="submit" class="w3-button w3-red  w3-round w3-card">Hapus!</button>

					</form>
		</div>

		<div id="dpenduduk" class="tabcontent1">
		  <h3>Data penduduk</h3>
		  <p>Memuat data penduduk desa ini, cari, edit, tambahkan data yang baru, berdasaskan field di bawah ini:</p> 

			<form action="" method="get" >
				<input type="text" id="cari" name="cari" class="w3-input w3-round-xxlarge">
				<br>
				<button type="submit" class="w3-button w3-blue">  Cari  </button>
			</form>

		  <br><br><br>
					<form action="" method="get" class="containerformdash">
						<label for="id">id :</label>
						<input type="text" name="id" id="id" class="w3-input w3-small">
						<span></span>
						<label for="nama">Nama lengkap :</label>
						<input type="text" name="nama" id="nama" class="w3-input w3-small">
						<span></span>					
						<label for="kelamin">kelamin :</label>
						<input type="text" name="kelamin" id="kelamin" class="w3-input w3-small">
						<span></span>					
						<label for="perkawinan">perkawinan :</label>
						<input type="text" name="perkawinan" id="perkawinan" class="w3-input w3-small">
						<span></span>					
						<label for="templahir">templahir :</label>
						<input type="text" name="templahir" id="templahir" class="w3-input w3-small">
						<span></span>					
						<label for="tgllahir">tgllahir :</label>
						<input type="text" name="tgllahir" id="tgllahir" class="w3-input w3-small">
						<span></span>					
						<label for="suku">suku :</label>
						<input type="text" name="suku" id="suku" class="w3-input w3-small">
						<span></span>					
						<label for="agama">agama :</label>
						<input type="text" name="agama" id="agama" class="w3-input w3-small">
						<span></span>					
						<label for="pendidikan">pendidikan :</label>
						<input type="text" name="pendidikan" id="pendidikan" class="w3-input w3-small">
						<span></span>					
						<label for="pekerjaan">pekerjaan :</label>
						<input type="text" name="pekerjaan" id="pekerjaan" class="w3-input w3-small">
						<span></span>					
						<label for="baca">baca :</label>
						<input type="text" name="baca" id="baca" class="w3-input w3-small">
						<span></span>					
						<label for="warga">warga :</label>
						<input type="text" name="warga" id="warga" class="w3-input w3-small">
						<span></span>					
						<label for="dusun">dusun :</label>
						<input type="text" name="dusun" id="dusun" class="w3-input w3-small">
						<span></span>					
						<label for="rt">rt :</label>
						<input type="text" name="rt" id="rt" class="w3-input w3-small">
						<span></span>					
						<label for="nik">nik :</label>
						<input type="text" name="nik" id="nik" class="w3-input w3-small">
						<span></span>					
						<label for="nokk">nokk :</label>
						<input type="text" name="nokk" id="nokk" class="w3-input w3-small">
						<span></span>					
						<label for="ket">ket :</label>
						<input type="text" name="ket" id="ket" class="w3-input w3-small">
						<span></span>					
						<label for="ayah">ayah :</label>
						<input type="text" name="ayah" id="ayah" class="w3-input w3-small">
						<span></span>					
						<label for="ibu">ibu :</label>
						<input type="text" name="ibu" id="ibu" class="w3-input w3-small">
						<span></span>					
						<label for="sttskeluarga">sttskeluarga :</label>
						<input type="text" name="sttskeluarga" id="sttskeluarga" class="w3-input w3-small">
						<span></span>					
						<label for="datamasuk">datamasuk :</label>
						<input type="text" name="datamasuk" id="datamasuk" class="w3-input w3-small">
						<span></span>					
						<label for="datakeluar">datakeluar :</label>
						<input type="text" name="datakeluar" id="datakeluar" class="w3-input w3-small">
						<span></span>					
						<label for="panggilan">panggilan :</label>
						<input type="text" name="panggilan" id="panggilan" class="w3-input w3-small">
						<span></span>					
						<label for="hp">hp :</label>
						<input type="text" name="hp" id="hp" class="w3-input w3-small">
						<span></span>					
						<label for="bumil">bumil :</label>
						<input type="text" name="bumil" id="bumil" class="w3-input w3-small">
						<span></span>					
						<label for="kb">kb :</label>
						<input type="text" name="kb" id="kb" class="w3-input w3-small">
						<span></span>					
						<label for="bayi">bayi :</label>
						<input type="text" name="bayi" id="bayi" class="w3-input w3-small">
						<span></span>					
						<label for="sd">sd :</label>
						<input type="text" name="sd" id="sd" class="w3-input w3-small">
						<span></span>					
						<label for="tk">tk :</label>
						<input type="text" name="tk" id="tk" class="w3-input w3-small">
						<span></span>					
						<label for="smp">smp :</label>
						<input type="text" name="smp" id="smp" class="w3-input w3-small">
						<span></span>					
						<label for="sma">sma :</label>
						<input type="text" name="sma" id="sma" class="w3-input w3-small">
						<span></span>					
						<label for="s1">s1 :</label>
						<input type="text" name="s1" id="s1" class="w3-input w3-small">
						<span></span>					
						<label for="s2">s2 :</label>
						<input type="text" name="s2" id="s2" class="w3-input w3-small">
						<span></span>					
						<label for="s3">s3 :</label>
						<input type="text" name="s3" id="s3" class="w3-input w3-small">
						<span></span>					
						<label for="difabel">difabel :</label>
						<input type="text" name="difabel" id="difabel" class="w3-input w3-small">
						<span></span>					
						<label for="pkh">pkh :</label>
						<input type="text" name="pkh" id="pkh" class="w3-input w3-small">
						<span></span>					
						<label for="rastra">rastra :</label>
						<input type="text" name="rastra" id="rastra" class="w3-input w3-small">
						<span></span>					
						<label for="desa">Desa :</label>
						<input type="text" name="desa" id="desa" class="w3-input w3-small">
						<br><br><br>
						
						<span></span>						
						<button type="submit" class="w3-button w3-blue">Simpan!</button>
					</form>

		</div>

		<div id="apbdesin" class="tabcontent1">
		  <h3>APBDES MASUK</h3>
		  <p>Tokyo is the capital of Japan.</p>

			<form action="" method="get" >
				<input type="text" id="cari" name="cari" class="w3-input w3-round-xxlarge">
				<br>
				<button type="submit" class="w3-button w3-blue">  Cari  </button>
			</form>

		  <br><br><br>
					<form action="" method="get" class="containerformdash">
						<label for="id">id :</label>
						<input type="text" name="id" id="id" class="w3-input w3-small">
						<span></span>
						<label for="nama">Nama desa :</label>
						<input type="text" name="namadesa" id="nama" class="w3-input w3-small">
						<span></span>					
						<label for="kecamatan">Kecamatan :</label>
						<input type="text" name="kec" id="kecamatan" class="w3-input w3-small">
						<span></span>					
						<label for="kabupaten">Kabupaten :</label>
						<input type="text" name="kab" id="kabupaten" class="w3-input w3-small">
						<span></span>					
						<label for="sekretariat">Sekretariat :</label>
						<input type="text" name="sekretariat" id="sekretariat" class="w3-input w3-small">
						<span></span>					
						<label for="kades">Kades :</label>
						<input type="text" name="kades" id="kades" class="w3-input w3-small">
						<span></span>					
						<label for="sekdes">Sekdes :</label>
						<input type="text" name="sekdes" id="sekdes" class="w3-input w3-small">
						<span></span>					
						<label for="camat">Camat :</label>
						<input type="text" name="camat" id="camat" class="w3-input w3-small">
						<span></span>					
						<label for="bupati">Bupati :</label>
						<input type="text" name="bupati" id="bupati" class="w3-input w3-small">
						<span></span>					
						<label for="hp">Hp :</label>
						<input type="text" name="hp" id="hp" class="w3-input w3-small">
						<span></span>					
						<label for="kodepos">Kodepos :</label>
						<input type="text" name="kodepos" id="kodepos" class="w3-input w3-small">
						<span></span>					
						<label for="initsurat">Inisial surat :</label>
						<input type="text" name="initsurat" id="initsurat" class="w3-input w3-small">
						<span></span>					
						<label for="theme">Theme :</label>
						<input type="text" name="theme" id="theme" class="w3-input w3-small">
						<span></span>					
						<label for="logodesa">Logo desa :</label>
						<input type="text" name="logodesa" id="logodesa" class="w3-input w3-small">
						<span></span>					
						<label for="desa">Desa :</label>
						<input type="text" name="desa" id="desa" class="w3-input w3-small">
						<br><br><br>
						
						<span></span>						
						<button type="submit" class="w3-button w3-blue">Simpan!</button>
					</form>

		</div>

		<div id="apbdesout" class="tabcontent1">
		  <h3>APBDES OUT</h3>
		  <p>London is the capital city of England.</p>

		  		<form action="" method="get" >
				<input type="text" id="cari" name="cari" class="w3-input w3-round-xxlarge">
				<br>
				<button type="submit" class="w3-button w3-blue">  Cari  </button>
			</form>

		  <br><br><br>
					<form action="" method="get" class="containerformdash">
						<label for="id">id :</label>
						<input type="text" name="id" id="id" class="w3-input w3-small">
						<span></span>
						<label for="nama">Nama :</label>
						<input type="text" name="nama" id="nama" class="w3-input w3-small">
						<span></span>					
						<label for="kelamin">Jenis kelamin :</label>
						<input type="text" name="kelamin" id="kelamin" class="w3-input w3-small">
						<span></span>					
						<label for="kabupaten">Kabupaten :</label>
						<input type="text" name="kabupaten" id="kabupaten" class="w3-input w3-small">
						<span></span>					
						<label for="sekretariat">Sekretariat :</label>
						<input type="text" name="sekretariat" id="sekretariat" class="w3-input w3-small">
						<span></span>					
						<label for="kades">Kades :</label>
						<input type="text" name="kades" id="kades" class="w3-input w3-small">
						<span></span>					
						<label for="sekdes">Sekdes :</label>
						<input type="text" name="sekdes" id="sekdes" class="w3-input w3-small">
						<span></span>					
						<label for="camat">Camat :</label>
						<input type="text" name="camat" id="camat" class="w3-input w3-small">
						<span></span>					
						<label for="bupati">Bupati :</label>
						<input type="text" name="bupati" id="bupati" class="w3-input w3-small">
						<span></span>					
						<label for="hp">Hp :</label>
						<input type="text" name="hp" id="hp" class="w3-input w3-small">
						<span></span>					
						<label for="kodepos">Kodepos :</label>
						<input type="text" name="kodepos" id="kodepos" class="w3-input w3-small">
						<span></span>					
						<label for="initsurat">Inisial surat :</label>
						<input type="text" name="initsurat" id="initsurat" class="w3-input w3-small">
						<span></span>					
						<label for="theme">Theme :</label>
						<input type="text" name="theme" id="theme" class="w3-input w3-small">
						<span></span>					
						<label for="logodesa">Logo desa :</label>
						<input type="text" name="logodesa" id="logodesa" class="w3-input w3-small">
						<span></span>					
						<label for="desa">Desa :</label>
						<input type="text" name="desa" id="desa" class="w3-input w3-small">
						<br><br><br>
						
						<span></span>						
						<button type="submit" class="w3-button w3-blue">Simpan!</button>
					</form>
		</div>


<!-- data layanan -->
		<div id="layanan" class="tabcontent1">
		  <h3>Data Layanan</h3>
		  <p>Paris is the capital of France.</p> 

		  		<form action="" method="get" >
				<input type="text" id="cari" name="cari" class="w3-input w3-round-xxlarge">
				<br>
				<button type="submit" class="w3-button w3-blue">  Cari  </button>
			</form>

		  <br><br><br>
					<form action="" method="get" class="containerformdash">
						<label for="id">id :</label>
						<input type="text" name="id" id="id" class="w3-input w3-small">
						<span></span>
						<label for="namadesa">Nama desa :</label>
						<input type="text" name="namadesa" id="namadesa" class="w3-input w3-small">
						<span></span>					
						<label for="kecamatan">Kecamatan :</label>
						<input type="text" name="kecamatan" id="kecamatan" class="w3-input w3-small">
						<span></span>					
						<label for="kabupaten">Kabupaten :</label>
						<input type="text" name="kabupaten" id="kabupaten" class="w3-input w3-small">
						<span></span>					
						<label for="sekretariat">Sekretariat :</label>
						<input type="text" name="sekretariat" id="sekretariat" class="w3-input w3-small">
						<span></span>					
						<label for="kades">Kades :</label>
						<input type="text" name="kades" id="kades" class="w3-input w3-small">
						<span></span>					
						<label for="sekdes">Sekdes :</label>
						<input type="text" name="sekdes" id="sekdes" class="w3-input w3-small">
						<span></span>					
						<label for="camat">Camat :</label>
						<input type="text" name="camat" id="camat" class="w3-input w3-small">
						<span></span>					
						<label for="bupati">Bupati :</label>
						<input type="text" name="bupati" id="bupati" class="w3-input w3-small">
						<span></span>					
						<label for="hp">Hp :</label>
						<input type="text" name="hp" id="hp" class="w3-input w3-small">
						<span></span>					
						<label for="kodepos">Kodepos :</label>
						<input type="text" name="kodepos" id="kodepos" class="w3-input w3-small">
						<span></span>					
						<label for="initsurat">Inisial surat :</label>
						<input type="text" name="initsurat" id="initsurat" class="w3-input w3-small">
						<span></span>					
						<label for="theme">Theme :</label>
						<input type="text" name="theme" id="theme" class="w3-input w3-small">
						<span></span>					
						<label for="logodesa">Logo desa :</label>
						<input type="text" name="logodesa" id="logodesa" class="w3-input w3-small">
						<span></span>					
						<label for="desa">Desa :</label>
						<input type="text" name="desa" id="desa" class="w3-input w3-small">
						<br><br><br>
						
						<span></span>						
						<button type="submit" class="w3-button w3-blue">Simpan!</button>
					</form>
		</div>
<!-- /data layanan -->



<!-- inbox layanan -->
		<!-- TAB -->
		<div id="inbox" class="tabcontent1">
				<!--  -->
				<h2>Daftar Inbox Layanan</h2>
				<p>Berisi request / permohonan layanan dari user. Tidak bisa di edit oleh admin hanya bisa di verifikasi atau permintaan ulang kepada user untuk melengkapi data dan membenarkan isi data melalui status layanan</p><br><br>
				<!--  -->
					<?php 
						function datapemohon($where){
							global $conn, $iddesa;
							$querylayout2 = "SELECT * FROM suratkeluar WHERE idlayanan='$where' AND desa='$iddesa' AND verifikasi <> '4'"; 
							$resultlayout2 = mysqli_query($conn, $querylayout2);
							while ( $datalayout2 = mysqli_fetch_assoc($resultlayout2)) {
								// echo $datalayout2["id"];
								$idp = $datalayout2["id"];
								echo "<br>"; ?>
									<div class="pemohon">
										<!-- jadi allternatif -->
										<form action="dashboard2.php?iddesa=<?= $iddesa; ?>&idlayout=<?= $idp; ?>" method="post">
											<!-- <button class="pemohonlinks" onclick="pemohon(event, <?= $idp ?>)"><?= $datalayout2['pemohon'] ?></button> -->
											<!-- <input type="hidden" name="idlayout" value="<?= $idp; ?>"> -->
											<button type="submit"><?= $datalayout2['pemohon'] ?> </button>
										</form>
									</div>
								<?php }} ?>
						
														
				<!--  -->
				<div class="containerinboxlay">
				    <div class="tab2">
				        <?php
				        	$index4 = 1; 
				            while ($index < $jumlayanan) { 

							$jumlahlayanan2 = query("SELECT count(idlayanan) as jumlah FROM suratkeluar WHERE desa='$iddesa' AND idlayanan=$index4 AND verifikasi <> '4'");
							$jumlahlayanan2['jumlah'];
							?>

				            <button class="tablinks2" onclick="openCity2(event, '<?= $layanan[$index] ?>')">
				            	<?= $layanan[$index]; ?> 
				            	<?php
									if($jumlahlayanan2['jumlah'] > 0){?>
										<span class ="w3-badge w3-red w3-right w3-small">
											<?= $jumlahlayanan2['jumlah']; ?>
										<?php } ?>
										</span>
							</button>
				                <?php $index++; $index4++; } ?>
				    </div>				


				    	<!--  -->
				        <?php 
				            while ($index2 < $jumlayanan) { ?>
				                <div id="<?= $layanan[$index2]; ?>" class="tabcontent2">
									<?php  
									$datapemohon = $layananid[$index2];?>
									<?= datapemohon($datapemohon); ?>
				                </div> 
				           <?php $index2++; } ?>
				    	<!--  -->
				    	
				   	<div>
				   		<!-- di bawah ini tidak harus ada saat di ganti dengan halaman mandiri -->
				   		<!-- <p>ini tempat verify</p> -->
	  					<!-- tinggal parameter ini diambil dari array id pemohon -->

						
				    	<!--  -->

							<!-- <div id=1 class="pemohoncontent">
							  <p>1 London is the capital city of England.</p>
							</div>

							<div id=2 class="pemohoncontent">
							  <p>2 Paris is the capital of France.</p> 
							</div>

							<div id=3 class="pemohoncontent">
							  <p>3 Tokyo is the capital of Japan.</p>
							</div>

							<div id=4 class="pemohoncontent">
							  <p>4 Tokyo is the capital of Japan.</p>
							</div> -->
				   	</div>
				</div>  	
				<!--  -->

		</div>
<!-- /inbox layanan -->	



<!-- =================== sedang ===================== -->
<!-- /arsip surat -->		

<div id="arsip" class="tabcontent1">
	<h3>Arsip Layanan</h3>
	<p>Tokyo is the capital of Japan.</p>

  	<form action="" method="get" >
		<input type="text" id="cari" name="cari" class="w3-input w3-round-xxlarge">
		<br>
		<button type="submit" class="w3-button w3-blue">  Cari  </button>
	</form>
	
  	<br><br><br>

	<table class="w3-table">
		<tr class="w3-blue">
			<th>No</th>
			<th>Kontrol</th>
			<th>Nama Pemohon</th>
			<th>Perihal</th>
			<th>No. Surat</th>
			<th>Tgl. Terbit</th>
		</tr>

<?php

// $index5 = 1;
// $queryarsip = "SELECT * FROM suratkeluar WHERE desa='$iddesa' AND verifikasi='0'";
// $resultarsip= mysqli_query($conn, $queryarsip);

while ($dataarsip = mysqli_fetch_assoc($resultarsip)) {?>
	<tr class="w3-white">
		<td><?= $index5; ?></td>
		<td>
			<form action="pages/cetak.php" method="post" target="blank">
				<input type="hidden" name="cetak" value="<?= $dataarsip['id'] ;?>">
				<button type="submit" name="submit">Preview</button>
			</form>
		</td>
		<td><?= $dataarsip['pemohon']; ?></td>
		<td><?= $dataarsip['perihal']; ?></td>
		<td><?= $dataarsip['nomor']; ?></td>
		<td><?= $dataarsip['tglterbit']; ?></td>
	</tr>
<?php $index5++; } ?>
 

		
	</table>



</div>
		
<!-- /arsip surat -->
<!-- =================== sedang ===================== -->



<!-- artikel -->
		<div id="artikel" class="tabcontent1">
		  <h3>Data Artikel</h3>
		  <p>Tokyo is the capital of Japan.</p>

		  		<form action="" method="get" >
				<input type="text" id="cari" name="cari" class="w3-input w3-round-xxlarge">
				<br>
				<button type="submit" class="w3-button w3-blue">  Cari  </button>
			</form>

		  <br><br><br>
					<form action="" method="get" class="containerformdash">
						<label for="id">id :</label>
						<input type="text" name="id" id="id" class="w3-input w3-small">
						<span></span>
						<label for="namadesa">Nama desa :</label>
						<input type="text" name="namadesa" id="namadesa" class="w3-input w3-small">
						<span></span>					
						<label for="kecamatan">Kecamatan :</label>
						<input type="text" name="kecamatan" id="kecamatan" class="w3-input w3-small">
						<span></span>					
						<label for="kabupaten">Kabupaten :</label>
						<input type="text" name="kabupaten" id="kabupaten" class="w3-input w3-small">
						<span></span>					
						<label for="sekretariat">Sekretariat :</label>
						<input type="text" name="sekretariat" id="sekretariat" class="w3-input w3-small">
						<span></span>					
						<label for="kades">Kades :</label>
						<input type="text" name="kades" id="kades" class="w3-input w3-small">
						<span></span>					
						<label for="sekdes">Sekdes :</label>
						<input type="text" name="sekdes" id="sekdes" class="w3-input w3-small">
						<span></span>					
						<label for="camat">Camat :</label>
						<input type="text" name="camat" id="camat" class="w3-input w3-small">
						<span></span>					
						<label for="bupati">Bupati :</label>
						<input type="text" name="bupati" id="bupati" class="w3-input w3-small">
						<span></span>					
						<label for="hp">Hp :</label>
						<input type="text" name="hp" id="hp" class="w3-input w3-small">
						<span></span>					
						<label for="kodepos">Kodepos :</label>
						<input type="text" name="kodepos" id="kodepos" class="w3-input w3-small">
						<span></span>					
						<label for="initsurat">Inisial surat :</label>
						<input type="text" name="initsurat" id="initsurat" class="w3-input w3-small">
						<span></span>					
						<label for="theme">Theme :</label>
						<input type="text" name="theme" id="theme" class="w3-input w3-small">
						<span></span>					
						<label for="logodesa">Logo desa :</label>
						<input type="text" name="logodesa" id="logodesa" class="w3-input w3-small">
						<span></span>					
						<label for="desa">Desa :</label>
						<input type="text" name="desa" id="desa" class="w3-input w3-small">
						<br><br><br>
						
						<span></span>
						 <button type="submit" class="w3-button w3-blue">Simpan!</button>
					</form>
		</div>
		
<!--  -->
		<div id="latihan" class="tabcontent1">
		  <h3>Data latihan</h3>
		  <p>ini cuman latihan aja....</p>

		  		<!-- <form action="" method="get" >
				<input type="text" id="cari" name="cari" class="w3-input w3-round-xxlarge">
				<br>
				<button type="submit" class="w3-button w3-blue" name="latihan1">  Cari  </button>
			</form>

		  <br><br><br>
					<form action="" method="get" class="containerformdash">
						<label for="id">id :</label>
						<input type="text" name="id" id="id" class="w3-input w3-small">
						<span></span>
						<label for="satu">satu :</label>
						<input type="text" name="satu" id="satu" class="w3-input w3-small">
						<span></span>					
						<label for="dua">dua :</label>
						<input type="text" name="dua" id="dua" class="w3-input w3-small">
						<span></span>					
						<label for="tiga">tiga :</label>
						<input type="text" name="tiga" id="tiga" class="w3-input w3-small">
						<span></span>					
						<label for="empat">empat :</label>
						<input type="text" name="empat" id="empat" class="w3-input w3-small">

						<br><br><br>
						
						<span></span>
						<button type="submit" class="w3-button w3-blue" name="simpanlatihan">Simpan!</button>
					</form> -->
		</div>
<!--  -->

	</div>
	

</div>

<!-- ===============script function================ -->


<!--  -->
<?php
for ($i=1; $i <= $jumlayanan; $i++) { 
    $nama = "openCity" . $i;
    $tabcontent = "tabcontent" . $i;
    $tablinks = "tablinks" . $i;
    ?>
<!-- ------------- style -------------- -->
    <style>
    .tab<?= $i ?> {
      overflow: hidden;
      /*border: 1px solid #ccc;*/
      background-color: #424242;;
    }

    /* Style the buttons inside the tab */
    .tab<?= $i ?> button {
      background-color: inherit;
      float: left;
      border: none;
      outline: none;
      cursor: pointer;
      padding: 14px 16px;
      transition: 0.3s;
      font-size: 17px;		  
      width: 100%; 
	  color: white;
    }

    /* Change background color of buttons on hover */
    .tab<?= $i ?> button:hover {
      background-color: green;
    }

    /* Create an active/current tablink class */
    .tab<?= $i ?> button.active {
      background-color: darkgreen;
    }

    /* Style the tab content */
    .tabcontent<?= $i ?> {
      display: none;
      padding: 6px 12px;
      /*border: 1px solid #ccc;*/
      border-top: none;
    }
    </style>
<!-- ------------- script -------------- -->
    <script>
    function <?= $nama; ?>(evt, cityName) {
    var i, <?= $tabcontent;?>, tablinks;
    <?= $tabcontent;?> = document.getElementsByClassName("<?= $tabcontent;?>");
    for (i = 0; i < <?= $tabcontent;?>.length; i++) {
      <?= $tabcontent;?>[i].style.display = "none";
    }
    <?= $tablinks ;?> = document.getElementsByClassName("<?= $tablinks ;?>");
    for (i = 0; i < <?= $tablinks ;?>.length; i++) {
      <?= $tablinks ;?>[i].className = <?= $tablinks ;?>[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
    }
    </script>
<?php } ?>

<script>
	function pemohon(evt, cityName) {
  var i, pemohoncontent, pemohonlinks;
  pemohoncontent = document.getElementsByClassName("pemohoncontent");
  for (i = 0; i < pemohoncontent.length; i++) {
    pemohoncontent[i].style.display = "none";
  }
  pemohonlinks = document.getElementsByClassName("pemohonlinks");
  for (i = 0; i < pemohonlinks.length; i++) {
    pemohonlinks[i].className = pemohonlinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
</script>