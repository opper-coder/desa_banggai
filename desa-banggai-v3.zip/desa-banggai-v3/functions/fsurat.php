<?php 
// ALGORITMA KODE

// 1. referensi variabel 
// 2. berisi utility surat
// 3. berisi function surat

// 4. bikin ukuran kertas
// 5. bikin jarak kertas dibawah nya

 ?>
 
 <?php 
// ??????????????? latihan ?????????????????????







// ???????????????????????????????????????????

  ?>
<?php 
// ________________ REFERENSI VAR _________________



// ________________________________________________
// ____________________ UTILITY ___________________

function nosuratsaiti($data, $tambah){
	// format 402/300/ST/2020 
	// unsur2 :
	// kode surat dari: layanan
	// nomor urut dari: layout
	// desa dari 

	$iddesa = $data['desa'];
	$idlayout = $data['id'];
	$idlayanan = $data['idlayanan'];

	$tahun = query("SELECT YEAR(tglterbit) FROM suratkeluar WHERE desa='$iddesa' AND id='$idlayout'");
	$sekarang = date('Y');
	// $sekarang = 2030;
	
		if( $tahun['YEAR(tglterbit)'] == $sekarang ){
			$nourut = $data['urut'] + $tambah;
		}else{$nourut = 0 + $tambah;}

	$kodesurat = query("SELECT kodesurat FROM layanan WHERE id='$idlayanan'");
	return $kodesurat['kodesurat'] . ' / ' . $nourut .' / '.'ST'.' / '. date('Y');
}

// ----- fungsi kop surat -----
function kopsurat($datadesa){
	global $pdf, $data;

	$pdf->SetFont('Helvetica','',14);
	$pdf->Cell(173,10,'PEMERINTAH DAERAH KABUPATEN BANGGAI',0,0,'C');
	$pdf->ln();

	$pdf->SetFont('Helvetica','B',12);
	$pdf->Cell(173,6,'DESA '. mb_strtoupper($datadesa["namadesa"]).' KEC. '. mb_strtoupper($datadesa["kec"]),0,0,'C');
	$pdf->ln();

	$pdf->SetFont('Helvetica','',12);
	$pdf->Cell(173,6,'Sekretariat : '. ucwords($datadesa["sekretariat"]),0,0,'C');
	$pdf->ln();

	$pdf->line(20,45,190,45);
	$pdf->line(20,45.7,190,45.7);

	$pdf->image('../assets/logo banggai.png', 20, 20 , 18 );
	$pdf->image('../assets/saiti/utils/'. $datadesa["logodesa"], 172, 19 , 16 );
}

// ----- fungsi perihal -----
function perihal($lampiran, $perihal){
	global $data; $tambah;

	return '
	<br>
	<div class="perihal">
		<table class="w3-text-black">
			<tr>
				<td>Nomor</td>
				<td style="padding-left: 10px;">:</td>
				<td>'. nosuratsaiti($data, $tambah) . '</td>
			</tr>
			<tr>
				<td>Lampiran</td>
				<td style="padding: 0 5px 0 10px;"> :</td>
				<td><b>'.$lampiran.'</b></td>
			</tr>
			<tr>
				<td>Perihal</td>
				<td style="padding-left: 10px;">:</td>
				<td><b>'.$perihal.'</b></td>
			</tr>
		</table>
	</div> 
'; } 


// ----- fungsi kepada -----
function kepada($kepada, $instansi, $di){
return '
	<div class="jarak20"></div>
	<div class="kepada">
		<span style="padding-left: 20px;"><b>Kepada Yth:</b></span><br>
		<span style="text-transform: capitalize;">'.$kepada.'</span><br>
		<span>'.$instansi.'</span><br>
		<span style="padding-left: 20px;">di-</span><br>
		<span style="padding-left: 50px; text-decoration: underline; ">'. $di .'</span>
	</div>
	';
 }

// ________________________________________________

// ________________ FUNCTION SURAT ________________
function sktm($data, $tambah){
	global $datadesa, $iddesa, $datawarga, $pdf;
	kopsurat($datadesa);
	
	$pdf->ln();
	$pdf->ln();
	$pdf->SetFont('Helvetica','U',11);
	$pdf->Cell(173,6,'SURAT KETERANGAN TIDAK MAMPU / SKTM',0,0,'C');
	
	$pdf->ln();
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(173,4,'Nomor : '.nosuratsaiti($data, $tambah),0,0,'C');

$pdf->ln();
	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Yang bertanda tangan di bawah ini, ');
	
	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Nama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Jabatan');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . 'Kepala Desa ' . ucwords($datadesa['desa']));

	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Menerangkan dengan sebenarnya bahwa : ');

$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Nama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['nama']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Jenis kelamin');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['kelamin']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Tempat/Tanggal lahir');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['templahir'] . ', ' . date('d F Y',strtotime($datawarga['tgllahir']))));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'NIK');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['nik']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Agama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['agama']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Pekerjaan');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['pekerjaan']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'alamat');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . 'Dusun '.ucwords($datawarga['dusun']).', RT '.$datawarga['rt'].', desa '.ucwords($datawarga['desa']));

$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Suami / Istri dari : '.ucwords($datawarga['pasangan']));

$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','BI',11);
	$pdf->MultiCell(172,7,'Bahwa yang bersangkutan benar benar warga desa '.ucwords($datadesa["namadesa"]).' kecamatan '.ucwords($datadesa["kec"]). ' kabupaten '.ucwords($datadesa["kab"]).' provinsi Sulawesi Tengah dan tergolong dalam keluarga berekonomi lemah (TIDAK MAMPU).');

	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->MultiCell(172,7,'Demikian surat keterangan ini kami buat dengan benar untuk dapat dipergunakan sebagai mengurus "PERSALINAN".');

					$pdf->ln();
					$pdf->ln();
					$pdf->Cell(175,7,ucwords($iddesa).', '.date('d F Y',strtotime($data['id'])),0,0,'C');

					$pdf->ln();
					$pdf->Cell(175,7,'Kepala Desa '. ucwords($iddesa),0,0,'C');

					// $pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->SetFont('Helvetica','U',11);
					$pdf->Cell(175,7,mb_strtoupper($datadesa["kades"]),0,0,'C');	


}
// -------------------------------------------------  n1  ----
// ----- fungsi surat -----
function n1($data, $tambah){

global $datadesa, $iddesa, $datawarga, $pdf;
	// kopsurat($datadesa);


$pdf->Rect(160,19,26,6,'D');

	// $pdf->SetX(110);
	
	$pdf->SetY(20);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(200,5,'                                                                                                                                                   Model N1');

	$pdf->SetX(20);
	$pdf->SetY(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,'KANTOR DESA');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["desa"]));

$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,'KECAMATAN');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kec"]));

$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,'KABUPATEN/KOTA');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kab"]));

// -----

	$pdf->ln();
	$pdf->ln();
	$pdf->SetFont('Helvetica','U',10);
	$pdf->Cell(173,5,'SURAT PENGANTAR PERKAWINAN',0,0,'C');
	
	$pdf->ln();
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(173,4,'Nomor : '.nosuratsaiti($data, $tambah),0,0,'C');

$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,'Yang bertanda tangan di bawah ini, menerangkan dengan sesungguhnya bahwa :');
	
	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,'1. '.' Nama lengkap');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,'2. '.' Jenis Kelamin');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,'3. '.' Tempat dan Tanggal lahir');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,'4. '.' Warga Negara');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,'5. '.' Agama');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,'6. '.' Pekerjaan');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,'7. '.' Tempat Tinggal');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,'8. '.' Bin');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,'9. '.' Status Perkawinan');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

		$pdf->ln();

		$pdf->SetX(35);
		$pdf->SetFont('Helvetica','',10);
		$pdf->MultiCell(40,5,'a. ');

			$pdf->SetX(40);
			$pdf->SetFont('Helvetica','',10);
			$pdf->MultiCell(40,4,'Jika pria terangkan jejaka Duda atau Beristri dan berapa istrinya');

			$pdf->SetX(40);
			$pdf->SetFont('Helvetica','',10);

		$pdf->SetX(35);
		$pdf->SetFont('Helvetica','',10);
		$pdf->MultiCell(40,4,'b. ');

			$pdf->SetX(40);
			$pdf->SetFont('Helvetica','',10);
			$pdf->MultiCell(40,4,'Jika Wanita terangkan Perawan atau Janda');

			$pdf->SetX(90);
			$pdf->SetFont('Helvetica','B',10);
		
		$pdf->Cell(100,4,': '.' ' . ucwords($datadesa["kades"]));

$pdf->ln();

	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,'10. '.' Nama Istri terdahulu');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

$pdf->ln();
$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(20,5,'Adalah benar anak dari perkawinan seorang pria :');


// -----
$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,' Nama lengkap dan Alias');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,' Nomor Induk Kependudukan (NIK)');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,' Tempat dan Tanggal lahir');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,' Kewarganegaraan');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,' Agama');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,' Pekerjaan');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,' Alamat');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

$pdf->ln();
$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(20,5,'Dengan seorang wanita :');

// -----
$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,' Nama lengkap dan Alias');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,' Nomor Induk Kependudukan (NIK)');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,' Tempat dan Tanggal lahir');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,' Kewarganegaraan');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,' Agama');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,' Pekerjaan');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,' Alamat');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(100,5,': '.' ' . ucwords($datadesa["kades"]));

$pdf->ln();
$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',10);
	$pdf->MultiCell(172,5,'Demikian surat pengantar ini dibuat dengan mengingat sumpah jabatan dan untuk dipergunakan sebagaimana mestinya.');

					$pdf->ln();
					$pdf->ln();
					$pdf->Cell(175,5,ucwords($iddesa).', '.date('d F Y',strtotime($data['id'])),0,0,'C');

					$pdf->ln();
					$pdf->Cell(175,5,'Kepala Desa '. ucwords($iddesa),0,0,'C');

					// $pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->SetFont('Helvetica','U',10);
					$pdf->Cell(175,5,mb_strtoupper($datadesa["kades"]),0,0,'C');	

}




























// ----- fungsi surat -----
function n2($data, $tambah){

global $datadesa, $iddesa, $datawarga, $pdf;
	// kopsurat($datadesa);


$pdf->Rect(160,19,26,6,'D');

	// $pdf->SetX(110);
	
	$pdf->SetY(20);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(200,5,'                                                                                                                                                   Model N2');

	$pdf->ln();
	$pdf->ln();
	$pdf->SetFont('Helvetica','U',11);
	$pdf->Cell(173,6,'SURAT KEHENDAK PERKAWINAN',0,0,'C');

	$pdf->ln();
	$pdf->ln();
$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,'Perihal                             :  Permohonan kehendak perkawinan                                  '.ucwords($datadesa['desa']).' '. date('d F Y',strtotime($data['tglterbit'])));
	
$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,'Kepada YTH');
	
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,'Kepala KUA kecamatan '. ucwords($datadesa['kec']));
	
	$pdf->ln();

	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,'di '. ucwords($datadesa['kec']));

$pdf->ln();
	$pdf->ln();

	$pdf->SetFont('Helvetica','',10);
	$pdf->MultiCell(173,5,'Dengan hormat kami mengajukan permohonan kehendak perkawinan untuk atas nama kami calon suami ... dengan calon istri ... pada hari ... 
tanggal ... jam... bertempat di rumah mempelai wanita di desa '.ucwords($datadesa['desa']).' kecamatan '.ucwords($datadesa['kec']).' kabupaten '.ucwords($datadesa['kab']));

	$pdf->ln();
	$pdf->SetFont('Helvetica','',10);
	$pdf->MultiCell(173,5,'Bersama ini kami sampaikan surat-surat yang diperlukan untuk diperiksa sebagai berikut :');

	$pdf->ln();
	$pdf->Cell(173,5,'1.  Surat pengantar perkawinan dari desa garis miring kelurahan (n1)');
	$pdf->Rect(160,102,6,4,'D');

	$pdf->ln();
	$pdf->Cell(173,5,'2.  Surat permohonan kehendak Nikah  (n2)');
	$pdf->Rect(160,107,6,4,'D');

	$pdf->ln();
	$pdf->Cell(173,5,'3.  Persetujuan calon mempelai  (n3)');
	$pdf->Rect(160,112,6,4,'D');

	$pdf->ln();
	$pdf->Cell(173,5,'4.  Surat izin orang tua');
	$pdf->Rect(160,117,6,4,'D');

	$pdf->ln();
	$pdf->Cell(173,5,'5.  Fotokopi KTP : Catin, Orang tua dan Saksi  (n2)');
	$pdf->Rect(160,122,6,4,'D');

	$pdf->ln();
	$pdf->Cell(173,5,'6.  Fotokopi Akte Kelahiran');
	$pdf->Rect(160,127,6,4,'D');

	$pdf->ln();
	$pdf->Cell(173,5,'7.  Fotokopi Kartu Keluarga');
	$pdf->Rect(160,132,6,4,'D');

	$pdf->ln();
	$pdf->Cell(173,5,'8.  Pas foto 2x3 = 3 lembar latar biru');
	$pdf->Rect(160,137,6,4,'D');

	$pdf->ln();
	$pdf->Cell(173,5,'9.  Pas foto 4x6 = 1 lembar latar biru');
	$pdf->Rect(160,142,6,4,'D');

	$pdf->ln();
	$pdf->Cell(173,5,'10.  Akta Cerai asli bagi janda/duda');
	$pdf->Rect(160,147,6,4,'D');

	$pdf->ln();
	$pdf->Cell(173,5,'11.  Rekomendasi Pindah Nikah');
	$pdf->Rect(160,152,6,4,'D');

	$pdf->ln();
	$pdf->Cell(173,5,'12.  Slip Setoran Bank');
	$pdf->Rect(160,157,6,4,'D');

	$pdf->ln();
	$pdf->Cell(173,5,'13.  KK asli (bagi yang mau pemisahan KK)');
	$pdf->Rect(160,162,6,4,'D');

$pdf->ln();
	$pdf->ln();
	$pdf->MultiCell(173,5,'Demikian permohonan ini kami sampaikan, kiranya dapat diperiksa, dihadiri dan dicatat sesuai dengan ketentuan peraturan perundang-undangan.');

				$pdf->ln();
				$pdf->Cell(173,5,'Wassalam,              ',0,0,'R');

				$pdf->ln();
				$pdf->Cell(173,5,'Diterima tanggal, ......................');

				$pdf->ln();
				$pdf->Cell(173,5,'Yang Menerima,');

				$pdf->ln();
				$pdf->Cell(173,5,'Kepala KUA/Penghulu                                                                                                           Pemohon');

				$pdf->ln();
				$pdf->ln();
				$pdf->ln();
				$pdf->ln();
				$pdf->SetFont('Helvetica','',10);
				$pdf->Cell(173,5,'__________________                                                                                                     ______________');

}

// ----- fungsi surat -----
function n3($data, $tambah){

global $datadesa, $iddesa, $datawarga, $pdf;
	// kopsurat($datadesa);


$pdf->Rect(160,19,26,6,'D');

	// $pdf->SetX(110);
	
	$pdf->SetY(20);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(200,5,'                                                                                                                                                   Model N3');

	$pdf->ln();
	$pdf->ln();
	$pdf->SetFont('Helvetica','U',10);
	$pdf->Cell(173,5,'SURAT PERSETUJUAN MEMPELAI',0,0,'C');

$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,'Yang bertanda tangan di bawah ini, ');
	
$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->Cell(20,5,'I.      Calon Suami :');
	$pdf->SetX(80);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'1. Nama lengkap dan alias');
	$pdf->SetX(80);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'2. Bin');
	$pdf->SetX(80);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'3. Tempat dan tanggal lahir');
	$pdf->SetX(80);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'4. Warga Negara');
	$pdf->SetX(80);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'5. Agama');
	$pdf->SetX(80);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'6. Pekerjaan');
	$pdf->SetX(80);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'7. Tempat tinggal');
	$pdf->SetX(80);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));


	
$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->Cell(20,5,'II.      Calon Istri :');
	$pdf->SetX(80);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'1. Nama lengkap dan alias');
	$pdf->SetX(80);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'2. Bin');
	$pdf->SetX(80);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'3. Tempat dan tanggal lahir');
	$pdf->SetX(80);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'4. Warga Negara');
	$pdf->SetX(80);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'5. Agama');
	$pdf->SetX(80);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'6. Pekerjaan');
	$pdf->SetX(80);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'7. Tempat tinggal');
	$pdf->SetX(80);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));



	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->MultiCell(173,5,'Menyatakan dengan sesungguhnya bahwa atas dasar sukarela, dengan kesadaran sendiri, tanpa paksaan dari siapapun juga, setuju untuk melangsungkan pernikahan.');

	$pdf->ln();
	$pdf->SetX(20);
	$pdf->MultiCell(173,5,'Demikian surat persetujuan ini dibuat untuk digunakan seperlunya.');

				$pdf->ln();
				$pdf->ln();
				$pdf->ln();
				$pdf->Cell(173,5,ucfirst($datadesa["desa"]) .', '. date('d F Y',strtotime($data['tglterbit'])),0,0,'C');

				$pdf->ln();
				$pdf->ln();
				$pdf->ln();
				$pdf->Cell(173,5,'I. Calon Suami,                                                                                                           II. Calon Istri');

				$pdf->ln();
				$pdf->ln();
				$pdf->ln();
				$pdf->ln();
				$pdf->SetFont('Helvetica','',10);
				$pdf->Cell(173,5,'_____QUERY_____________                                                                                              _____Query_________');

}







// ----- fungsi surat -----
function n4($data, $tambah){

	global $datadesa, $iddesa, $datawarga, $pdf;
	// kopsurat($datadesa);


$pdf->Rect(160,19,26,6,'D');

	// $pdf->SetX(110);
	
	$pdf->SetY(20);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(200,5,'                                                                                                                                                   Model N4');

	$pdf->ln();
	$pdf->ln();
	$pdf->SetFont('Helvetica','U',10);
	$pdf->Cell(173,5,'SURAT IZIN ORANG TUA',0,0,'C');

$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(20,5,'Yang bertanda tangan di bawah ini, menerangkan dengan sesungguhnya bahwa :');
	
$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->Cell(20,5,'I.       Calon Suami :');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'1. Nama lengkap dan alias');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'2. Bin');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'3. Nomor induk kependudukan(NIK)');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'4. Tempat dan tanggal lahir');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'5. Warga Negara');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'6. Agama');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'7. Pekerjaan');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'8. Tempat tinggal');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));


	
$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->Cell(20,5,'II.      Calon Istri :');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'1. Nama lengkap dan alias');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'2. Bin');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'3. Nomor induk kependudukan(NIK)');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'4. Tempat dan tanggal lahir');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'5. Warga Negara');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'6. Agama');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'7. Pekerjaan');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'8. Tempat tinggal');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));


	$pdf->ln();
	$pdf->ln();
	$pdf->SetFont('Helvetica','B',10);
	$pdf->SetX(20);
	$pdf->Cell(20,5,'Adalah benar ayah dan ibu kandung dari :');


$pdf->ln();
	$pdf->SetFont('Helvetica','',10);
	$pdf->SetX(30);
	$pdf->Cell(20,5,'1. Nama lengkap dan alias');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'2. Bin');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'3. Nomor induk kependudukan(NIK)');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'4. Tempat dan tanggal lahir');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'5. Warga Negara');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'6. Agama');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'7. Pekerjaan');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'8. Tempat tinggal');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->ln();
	$pdf->SetFont('Helvetica','B',10);
	$pdf->SetX(20);
	$pdf->Cell(20,5,'Memberikan izin kepada anak kami untuk melakukan perkawinan dengan :');

$pdf->ln();
	$pdf->SetFont('Helvetica','',10);
	$pdf->SetX(30);
	$pdf->Cell(20,5,'1. Nama lengkap dan alias');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'2. Bin');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'3. Nomor induk kependudukan(NIK)');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'4. Tempat dan tanggal lahir');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'5. Warga Negara');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'6. Agama');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'7. Pekerjaan');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->Cell(20,5,'8. Tempat tinggal');
	$pdf->SetX(90);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->MultiCell(173,5,'Demikian surat izin ini dibuat dengan kesadaran tanpa ada paksaan dari siapapun dan untuk digunakan seperlunya.');

				$pdf->ln();
				$pdf->Cell(173,5,ucfirst($datadesa["desa"]) .', '. date('d F Y',strtotime($data['tglterbit'])),0,0,'C');

				$pdf->ln();
				$pdf->ln();
				$pdf->Cell(173,5,'I. Calon Suami,                                                                                                           II. Calon Istri');

				$pdf->ln();
				$pdf->ln();
				$pdf->ln();
				$pdf->ln();
				$pdf->SetFont('Helvetica','',10);
				$pdf->Cell(173,5,'_____QUERY_____________                                                                                              _____Query_________');


}

// ----- fungsi surat -----
function n5($data, $tambah){

	global $datadesa, $iddesa, $datawarga, $pdf;
	// kopsurat($datadesa);


$pdf->Rect(160,19,26,6,'D');

	// $pdf->SetX(110);
	
	$pdf->SetY(20);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(200,5,'                                                                                                                                                   Model N5');

	$pdf->ln();
	$pdf->ln();
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(173,5,'KANTOR URUSAN AGAMA',0,0,'C');
	$pdf->ln();
	$pdf->Cell(173,5,'KECAMATAN'.mb_strtoupper($datadesa['kec']),0,0,'C');
	$pdf->ln();
	$pdf->SetFont('Helvetica','U',10);
	$pdf->Cell(173,5,'KABUPATEN'.mb_strtoupper($datadesa['kab']),0,0,'C');

$pdf->ln();
	$pdf->ln();
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(175,5,ucwords($datadesa['kec']).', '.date('d F Y',strtotime($data['id'])),0,0,'R');
	
	$pdf->ln();
	$pdf->ln();
	// $pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(173,5,'Nomor ');
	$pdf->SetX(50);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(173,5,'Lampiran');
	$pdf->SetX(50);
	$pdf->Cell(100,5,': '.' ' . mb_strtoupper($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(173,5,'Perihal                   :');
	$pdf->SetX(53);
	$pdf->MultiCell(62,5,'Pemberitahuan kekurangan syarat/ penolakan perkawinan/rujuk');

$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',10);
	$pdf->Cell(173,5,'Kepada Yth.');

	$pdf->ln();
	$pdf->Cell(173,5,'Calon Pengantin/Wali');

	$pdf->ln();
	$pdf->Cell(173,5,'QUERY');

	$pdf->ln();
	$pdf->Cell(173,5,'di');

	$pdf->ln();
	$pdf->Cell(173,5,'            '.'QUERY');

$pdf->ln();
	$pdf->ln();
	$pdf->MultiCell(173,5,'Dengan Hormat, setelah Dilakukan Pemeriksaan terhadap Persyaratan Pendaftaran Perkawinan yang diatur dalam peraturan Perundang-undangan, cara permohonan pendaftaran perkawinan atau Rujuk saudara'.$datadesa["bupati"].' Dengan '.$datadesa["bupati"].' diberitahukan sebagai berikut:');

		$pdf->ln();
		$pdf->SetX(30);
		$pdf->MultiCell(173,5,'1.  Perkawinan dapat dilakukan dengan melengkapi persyaratan ......QUERY');

		$pdf->ln();
		$pdf->SetX(30);
		$pdf->MultiCell(173,5,'2.  Tidak dapat dilaksanakan (ditalak), karena tidak melengkapi persyaratan berupa ........QUERY ');

$pdf->ln();	
	$pdf->SetX(20);
	$pdf->MultiCell(173,5,'Demikian agar menjadi dimaklumi.');


					$pdf->ln();


					$pdf->ln();
					$pdf->Cell(175,5,'Kepala KUA '. ucwords($datadesa['kec']),0,0,'C');

					// $pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->SetFont('Helvetica','U',10);
					$pdf->Cell(175,5,'QUERYY  '.mb_strtoupper($datadesa["kades"]),0,0,'C');	



}

// ----- fungsi surat -----
function n6($data, $tambah){


global $datadesa, $iddesa, $datawarga, $pdf;

$pdf->Rect(160,19,26,6,'D');

	// $pdf->SetX(110);
	
	$pdf->SetY(20);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(200,5,'                                                                                                                                                   Model N6');
	
	$pdf->ln();
	$pdf->ln();
	$pdf->SetFont('Helvetica','U',11);
	$pdf->Cell(173,6,'SURAT KETERANGAN KEMATIAN SUAMI/ISTERI',0,0,'C');
	
	$pdf->ln();
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(173,4,'Nomor : '.nosuratsaiti($data, $tambah),0,0,'C');

$pdf->ln();
	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Yang bertanda tangan di bawah ini menerangkan dengan sebenarnya bahwa :');
	
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'I.       1. Nama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'2. Bin/Binti');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['kelamin']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'3. Tempat/Tanggal lahir');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['templahir'] . ', ' . date('d F Y',strtotime($datawarga['tgllahir']))));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'4. Warga Negara');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['templahir'] . ', ' . date('d F Y',strtotime($datawarga['tgllahir']))));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'5. Agama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['templahir'] . ', ' . date('d F Y',strtotime($datawarga['tgllahir']))));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'6. Pekerjaan Terakhir');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['templahir'] . ', ' . date('d F Y',strtotime($datawarga['tgllahir']))));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'7. Tempat tinggal terakhir');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['templahir'] . ', ' . date('d F Y',strtotime($datawarga['tgllahir']))));

$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(20,7,'Telah meninggal dunia pada tanggal : ');

$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'II.      1. Nama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'2. Bin/Binti');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['kelamin']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'3. Tempat/Tanggal lahir');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['templahir'] . ', ' . date('d F Y',strtotime($datawarga['tgllahir']))));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'4. Warga Negara');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['templahir'] . ', ' . date('d F Y',strtotime($datawarga['tgllahir']))));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'5. Agama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['templahir'] . ', ' . date('d F Y',strtotime($datawarga['tgllahir']))));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'6. Pekerjaan Terakhir');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['templahir'] . ', ' . date('d F Y',strtotime($datawarga['tgllahir']))));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'7. Tempat tinggal terakhir');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['templahir'] . ', ' . date('d F Y',strtotime($datawarga['tgllahir']))));

	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->MultiCell(172,7,'Adalah suami/isteri orang yang telah meninggal tersebut diatas');

	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->MultiCell(172,7,'Demikian surat keterangan ini dibuat dengan mengingat sumpah jabatan dan untuk dipergunakan seperlunya.');

					$pdf->ln();
					$pdf->ln();
					$pdf->Cell(175,7,ucwords($iddesa).', '.date('d F Y',strtotime($data['id'])),0,0,'C');

					$pdf->ln();
					$pdf->Cell(175,7,'Kepala Desa '. ucwords($iddesa),0,0,'C');

					// $pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->SetFont('Helvetica','U',11);
					$pdf->Cell(175,7,mb_strtoupper($datadesa["kades"]),0,0,'C');

}

// ----- fungsi surat -----
function n7($data, $tambah){
echo "

";
}

// ----- fungsi surat -----
function n8($data, $tambah){


global $datadesa, $iddesa, $datawarga, $pdf;

$pdf->Rect(160,19,26,6,'D');

	// $pdf->SetX(110);
	
	$pdf->SetY(20);
	$pdf->SetFont('Helvetica','B',10);
	$pdf->Cell(200,5,'                                                                                                                                                   Model N8');
	
	$pdf->ln();
	$pdf->ln();
	$pdf->SetFont('Helvetica','U',11);
	$pdf->Cell(173,6,'BERITA ACARA PEMERIKASAAN PERKAWINAN',0,0,'C');
	
	$pdf->ln();
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(173,4,'Nomor : '.nosuratsaiti($data, $tambah),0,0,'C');

$pdf->ln();
	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->MultiCell(173,7,'Pada hari ini tanggal QUERY bulan QUERY tahun QUERY bertempat di KUA Kecamatan'.$datadesa['kec'].'kabupaten'.$datadesa['kec'].'provinsi Sulawesi tengah, telah dilakukan pemeriksaan perkawinan terhadap:');
	
	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(30,7,'1. Nama Calon Suami');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(30,7,'2. Nama Calon Isteri');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(30,7,'3. Nama Calon Wali');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(30,7,'4. Rencana Akad perkawinan');
	$pdf->SetX(90);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': ');

		$pdf->ln();
		$pdf->SetX(35);
		$pdf->SetFont('Helvetica','',11);
		$pdf->Cell(30,7,'a)   Hari/Tanggal');
		$pdf->SetX(90);
		$pdf->SetFont('Helvetica','B',11);
		$pdf->Cell(100,7,': '.' ' . ucwords($datadesa["kades"]));

		$pdf->ln();
		$pdf->SetX(35);
		$pdf->SetFont('Helvetica','',11);
		$pdf->Cell(30,7,'a)   Waktu');
		$pdf->SetX(90);
		$pdf->SetFont('Helvetica','B',11);
		$pdf->Cell(100,7,': '.' ' . ucwords($datadesa["kades"]));

		$pdf->ln();
		$pdf->SetX(20);
		$pdf->SetFont('Helvetica','',11);
		$pdf->Cell(30,7,'I.            Nama Petugas Pemeriksa');
		$pdf->SetX(90);
		$pdf->SetFont('Helvetica','B',11);
		$pdf->Cell(100,7,': '.' ' . ucwords($datadesa["kades"]));

		$pdf->ln();
		$pdf->SetX(35);
		$pdf->SetFont('Helvetica','',11);
		$pdf->Cell(30,7,'Jabatan');
		$pdf->SetX(90);
		$pdf->SetFont('Helvetica','B',11);
		$pdf->Cell(100,7,': '.' ' . ucwords($datadesa["kades"]));

		$pdf->ln();
		$pdf->ln();
		$pdf->ln();

        $pdf->SetFont('Helvetica','',11);                                                                                                                             
		$pdf->ln();
		$pdf->Cell(30,4,'       Calon Suami                 Calon Isteri                     Wali akad             Petugas Pemeriksa                ');

			$pdf->line(20,150,20,180);
			$pdf->line(60,150,60,180);
			$pdf->line(100,150,100,180);
			$pdf->line(140,150,140,180);
			$pdf->line(180,150,180,180);

			$pdf->line(20,150,180,150);
			$pdf->line(20,158,180,158);
			$pdf->line(20,180,180,180);








// echo "
// Berita acara pemeriksaan perkawinan
// Nomor

// Pada hari ini tanggal bulan tahun

// bertempat di KUA kecamatan nuhon kabupaten Banggai provinsi Sulawesi tengah, telah dilakukan pemeriksaan perkawinan terhadap:

// nama calon suami: nama calon istri: nama calon wali: rencana agar perkawinan: hari/tanggal. 2 masehi waktu. 2 Hijriyah

// Nama petugas pemeriksa: jabatan:

// Tabel


// ";
}

// ----- fungsi surat -----
function sktt($data, $tambah){
echo "

";
}

// ----- fungsi surat -----
function domisili($data, $tambah){
	global $datadesa, $iddesa, $datawarga, $pdf;
	kopsurat($datadesa);
// query belum ada disusun sesuai urutan lalu buatkan formnya

	
	$pdf->ln();
	$pdf->ln();
	$pdf->SetFont('Helvetica','U',11);
	$pdf->Cell(173,6,'SURAT KETERANGAN DOMISILI',0,0,'C');
	
	$pdf->ln();
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(173,4,'Nomor : '.nosuratsaiti($data, $tambah),0,0,'C');

$pdf->ln();
	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Yang bertanda tangan di bawah ini, ');
	
	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Nama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Jabatan');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . 'Kepala Desa ' . ucwords($datadesa['desa']));

	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Menerangkan dengan sebenarnya bahwa : ');

$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Nama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['nama']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Jenis kelamin');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['kelamin']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Tempat/Tanggal lahir');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['templahir'] . ', ' . date('d F Y',strtotime($datawarga['tgllahir']))));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'NIK');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['nik']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Agama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['agama']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Status perkawinan');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' .'Sudah '. ucwords($datawarga['perkawinan']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Pekerjaan');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['pekerjaan']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'alamat');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . 'Dusun '.ucwords($datawarga['dusun']).', RT '.$datawarga['rt'].', desa '.ucwords($datawarga['desa']));

	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->MultiCell(172,7,'adalah benar-benar yang bersangkutan sampai dengan dikeluarkan surat keterangan ini masih berdomisili di "desa '.ucwords($datadesa["desa"]).' kecamatan '.ucwords($datadesa["kec"]).' kabupaten '.ucwords($datadesa["kab"]).' provinsi Sulawesi Tengah".');

	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->MultiCell(172,7,'Demikian surat keterangan ini dibuat dan diberikan kepada yang bersangkutan untuk digunakan sebagaimana perlunya.');

					$pdf->ln();
					$pdf->ln();
					$pdf->Cell(175,7,ucwords($iddesa).', '.date('d F Y',strtotime($data['id'])),0,0,'C');

					$pdf->ln();
					$pdf->Cell(175,7,'Kepala Desa '. ucwords($iddesa),0,0,'C');

					// $pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->SetFont('Helvetica','U',11);
					$pdf->Cell(175,7,mb_strtoupper($datadesa["kades"]),0,0,'C');	

}

// ----- fungsi surat -----
function spermohonankreditusaha($data, $tambah){

}

// ----- fungsi surat -----
function skhasilortu($data, $tambah){
echo "

";
}





// ----- fungsi surat -----
function skusaha($data, $tambah){
global $datadesa, $iddesa, $datawarga, $pdf;
	kopsurat($datadesa);

	// query belum ada disusun sesuai urutan lalu buatkan formnya

	$pdf->ln();
	$pdf->ln();
	$pdf->SetFont('Helvetica','U',11);
	$pdf->Cell(173,6,'SURAT KETERANGAN USAHA',0,0,'C');
	
	$pdf->ln();
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(173,4,'Nomor : '.nosuratsaiti($data, $tambah),0,0,'C');

$pdf->ln();
	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Yang bertanda tangan di bawah ini, ');
	
	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Nama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Jabatan');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . 'Kepala Desa ' . ucwords($datadesa['desa']));

	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Menerangkan dengan sebenarnya bahwa : ');

$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Nama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['nama']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Tempat/Tanggal lahir');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['templahir'] . ', ' . date('d F Y',strtotime($datawarga['tgllahir']))));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Pekerjaan');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['pekerjaan']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'alamat');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . 'Dusun '.ucwords($datawarga['dusun']).', RT '.$datawarga['rt'].', desa '.ucwords($datawarga['desa']));

	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->MultiCell(172,7,'Adalah benar-benar memiliki usaha: "Pertanian PADI QUERY NYA BELUM SIAP" berdomisili di "desa '.ucwords($datadesa["desa"]).' kecamatan '.ucwords($datadesa["kec"]).' kabupaten '.ucwords($datadesa["kab"]).' provinsi sulawesi tengah".');
	$pdf->ln(); 
	$pdf->MultiCell(172,7,'Usaha tersebut Terletak di wilayah "desa '.ucwords($datadesa["desa"]).' kecamatan '.ucwords($datadesa["kec"]).' kabupaten '.ucwords($datadesa["kab"]).' provinsi sulawesi tengah".');

	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->MultiCell(172,7,'Demikian surat keterangan ini dibuat dan diberikan kepada yang bersangkutan untuk digunakan sebagaimana perlunya.');

					$pdf->ln();
					$pdf->ln();
					$pdf->Cell(175,7,ucwords($iddesa).', '.date('d F Y',strtotime($data['id'])),0,0,'C');

					$pdf->ln();
					$pdf->Cell(175,7,'Kepala Desa '. ucwords($iddesa),0,0,'C');

					// $pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->SetFont('Helvetica','U',11);
					$pdf->Cell(175,7,mb_strtoupper($datadesa["kades"]),0,0,'C');	
}




// ----- fungsi surat -----
function skkb($data, $tambah){
global $datadesa, $iddesa, $datawarga, $pdf;
	kopsurat($datadesa);
// query belum ada disusun sesuai urutan lalu buatkan formnya

	
	$pdf->ln();
	$pdf->ln();
	$pdf->SetFont('Helvetica','U',11);
	$pdf->Cell(173,6,'SURAT KETERANGAN BERKELAKUAN BAIK',0,0,'C');
	
	$pdf->ln();
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(173,4,'Nomor : '.nosuratsaiti($data, $tambah),0,0,'C');

$pdf->ln();
	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Yang bertanda tangan di bawah ini, ');
	
	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Nama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Jabatan');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . 'Kepala Desa ' . ucwords($datadesa['desa']));

	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Menerangkan dengan sebenarnya bahwa : ');

$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Nama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['nama']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Jenis kelamin');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['kelamin']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Tempat/Tanggal lahir');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['templahir'] . ', ' . date('d F Y',strtotime($datawarga['tgllahir']))));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Pekerjaan');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['pekerjaan']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Agama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['agama']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Suku dan kewarganegaraan');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' '. mb_strtoupper($datawarga['suku']) . '/' . mb_strtoupper($datawarga['warga']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'alamat');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . 'Dusun '.ucwords($datawarga['dusun']).', RT '.$datawarga['rt'].', desa '.ucwords($datawarga['desa']));

	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->MultiCell(172,7,'Yang namanya tersebut di atas menurut penelitian kami hingga saat dikeluarkan surat keterangan ini, oknum tersebut diatas "BERKELAKUAN BAIK" dan tidak pernah terlibat sesuatu perkara /organisasi yang mengganggu keamanan dan ketertiban.');

	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->MultiCell(172,7,'Demikian surat pengantar ini dibuat dengan benar dan diberikan kepada yang bersangkutan untuk dipergunakan membuat rekomendasi catatan kepolisian (RCK) di Polsek '.ucwords($datadesa['kec']));

					$pdf->ln();
					$pdf->ln();
					$pdf->Cell(175,7,ucwords($iddesa).', '.date('d F Y',strtotime($data['id'])),0,0,'C');

					$pdf->ln();
					$pdf->Cell(175,7,'Kepala Desa '. ucwords($iddesa),0,0,'C');

					// $pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->SetFont('Helvetica','U',11);
					$pdf->Cell(175,7,mb_strtoupper($datadesa["kades"]),0,0,'C');


}





// ----- fungsi surat -----
function skuasa($data, $tambah){
	global $datadesa, $iddesa, $datawarga, $pdf;
	// query belum ada disusun sesuai urutan lalu buatkan formnya

	$pdf->ln();
	$pdf->ln();
	$pdf->SetFont('Helvetica','BU',11);
	$pdf->Cell(173,6.2,'SURAT KUASA',0,0,'C');

	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,6.2,'Yang bertanda tangan di bawah ini, ');

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,6.2,'Nama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,6.2,': '.' ' . ucwords($datawarga['nama']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,6.2,'Tempat/Tanggal lahir');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,6.2,': '.' ' . ucwords($datawarga['templahir'] . ', ' . date('d F Y',strtotime($datawarga['tgllahir']))));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,6.2,'Pekerjaan');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,6.2,': '.' ' . ucwords($datawarga['pekerjaan']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,6.2,'alamat');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,6.2,': '.' ' . 'Dusun '.ucwords($datawarga['dusun']).', RT '.$datawarga['rt'].', desa '.ucwords($datawarga['desa']));

$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,6.2,'Sebagai ahliwaris Sertipikat tanah atas nama : QUERY');


$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,6.2,'Dengan ini memberi kuasa kepada: ');

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,6.2,'Nama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,6.2,': '.' Query' . ucwords($datawarga['nama']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,6.2,'Tempat/Tanggal lahir');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,6.2,': '.' Query' . ucwords($datawarga['templahir'] . ', ' . date('d F Y',strtotime($datawarga['tgllahir']))));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,6.2,'Pekerjaan');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,6.2,': '.' Query' . ucwords($datawarga['pekerjaan']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,6.2,'alamat');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,6.2,': '.' Query' . 'Dusun '.ucwords($datawarga['dusun']).', RT '.$datawarga['rt'].', desa '.ucwords($datawarga['desa']));

	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->MultiCell(172,6.2,'Untuk menggunakan hak milik kami sendiri yang berupa Sertifikat/Surat Penyerahan/AJB Akta Hibah no.... Tanggal,.... Dengan luas ... M2 atas nama yang terletak di desa '.ucwords($datadesa["desa"]).' kecamatan '.ucwords($datadesa["kec"]).' kabupaten '.ucwords($datadesa["kab"]).' provinsi Sulawesi tengah. Dengan batas-batas:');

		$pdf->ln();
		$pdf->SetX(30);
		$pdf->SetFont('Helvetica','',11);
		$pdf->Cell(20,6.2,'Utara');
		$pdf->SetX(80);
		$pdf->SetFont('Helvetica','B',11);
		$pdf->Cell(100,6.2,': '.' Query' . ucwords($datawarga['pekerjaan']));
		
		$pdf->ln();
		$pdf->SetX(30);
		$pdf->SetFont('Helvetica','',11);
		$pdf->Cell(20,6.2,'Timur');
		$pdf->SetX(80);
		$pdf->SetFont('Helvetica','B',11);
		$pdf->Cell(100,6.2,': '.' Query' . ucwords($datawarga['pekerjaan']));

		$pdf->ln();
		$pdf->SetX(30);
		$pdf->SetFont('Helvetica','',11);
		$pdf->Cell(20,6.2,'Selatan');
		$pdf->SetX(80);
		$pdf->SetFont('Helvetica','B',11);
		$pdf->Cell(100,6.2,': '.' Query' . ucwords($datawarga['pekerjaan']));

		$pdf->ln();
		$pdf->SetX(30);
		$pdf->SetFont('Helvetica','',11);
		$pdf->Cell(20,6.2,'Barat');
		$pdf->SetX(80);
		$pdf->SetFont('Helvetica','B',11);
		$pdf->Cell(100,6.2,': '.' Query' . ucwords($datawarga['pekerjaan']));

$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,6.2,'Sebagai jaminan kredit pada BANK RAKYAT INDONESIA persero(Tbk) Unit : QUERY');

$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->MultiCell(172,6.2,'Dengan demikian apabila dikemudian hari ternyata yang bersangkutan tersebut di atas tidak memenuhi kewajiban/bayar pinjaman baik pokok maupun bunga, maka kami tidak keberatan jika hak milik kami di atas disita oleh BANK RAKYAT INDONESIA unit "QUERI" yang diberi kuasa olehnya kemudahan dijual di bawah tangan atau dilelang di muka umum, dan hasilnya digunakan untuk melunasi kredit yang bersangkutan.');

	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->MultiCell(172,6.2,'Surat kuasa ini tidak akan batal walaupun pemberi kuasa meninggal dunia, namun demikian akan batal dengan sendirinya apabila terjadi setelah di lunasi. ');

	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->MultiCell(172,6.2,'Demikian surat pengantar ini kami buat, tanpa paksaan dari pihak manapun, untuk dapat dipergunakan sebagaimana perlunya ');

					$pdf->ln();
					$pdf->Cell(175,6.2,ucwords($iddesa).', '.date('d F Y',strtotime($data['id'])),0,0,'C');

					$pdf->ln();
					$pdf->Cell(175,6.2,'Yang diberi kuasa',0,0,'L');

					$pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->SetFont('Helvetica','U',11);
					$pdf->Cell(175,6.2,mb_strtoupper("QUERY"),0,0,'L');

					$pdf->SetY(253);
					$pdf->SetFont('Helvetica','',11);
					$pdf->Cell(175,6.2,'Yang memberi kuasa',0,0,'R');


			$pdf->ln();
			$pdf->rect(150,260,20,15,'D');

			$pdf->SetY(265);
			$pdf->SetX(151);
			$pdf->SetFont('Helvetica','',7);
			$pdf->Cell(175,6.2,'Materai 6000');

					$pdf->ln();
					$pdf->ln();
					$pdf->SetFont('Helvetica','U',11);
					$pdf->Cell(175,6.2,mb_strtoupper("QUERY"),0,0,'R');

					$pdf->ln();
					$pdf->SetFont('Helvetica','',11);
					$pdf->Cell(175,6.2,'Kepala Desa '. ucwords($iddesa),0,0,'C');

					// $pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->SetFont('Helvetica','U',11);
					$pdf->Cell(175,6.2,mb_strtoupper($datadesa["kades"]),0,0,'C');

}

// ----- fungsi surat -----
function sjb($data, $tambah){
echo "

";
}

// ----- fungsi surat -----
function spengantar($data, $tambah){
echo "

";
}

// ----- fungsi surat -----
function spernyataan($data, $tambah){
echo "
Saya yang bertanda tangan di bawah ini:

Nama: tempat/tanggal lahir:
alamat:

dengan ini menyatakan bahwa saya benar-benar mengajukan kredit untuk kepentingan pribadi dan bukan untuk dipergunakan oleh pihak lain dan saya bertanggung jawab penuh atas kredit yang saya ambil di BRI unit kontak sampai dengan lunas.

Demikian surat keterangan ini dibuat untuk digunakan seperlunya.

Tanda tangan



";
}

// ----- fungsi surat -----
function skpindah($data, $tambah){
echo "

";
}

// ----- fungsi surat -----
function skpengantar($data, $tambah){
echo "

";
}

// ----- fungsi surat -----
function sahliwaris($data, $tambah){
echo "
Kok surat

Set keterangan ahli waris

kami yang bertanda tangan di bawah ini adalah para ahli waris dari almarhum Maryoso menerangkan bahwa dengan sesungguhnya dan sanggup angkat sumpah bahwa almarhum martabak bertempat tinggal terakhir di desa site kecamatan mohon kabupaten banggai dan telah meninggal dunia pada hari jumat tanggal 8 bulan maret tahun duaributigabelas, dan dari perkawinan dengan istri Zaenab, dikaruniai 4 (empat) orang anak yakni sebagai berikut:

Satu dua tiga

Dengan demikian kami kelima orang ahli waris garis miring istri dan anak-anak adalah satu-satunya ali waris dari mendiang almarhum martabak

Siti tanggal

Kami para ahli waris:

Satu dua tiga empat

Tanda tangan

Sudah dua tiga empat

Saksi saksi:

Nama umur alamat pekerjaan tanda tangan

Nomor
Tanggal

Dikuatkan oleh kami camat nuhun

Disahkan oleh kami kepala desa said
";
}

// ----- fungsi surat -----
function sktmbpjs($data, $tambah){
echo "

";
}

// ----- fungsi surat -----
function sktmpend($data, $tambah){
echo "

";
}

// ----- fungsi surat -----
function skhubdarah($data, $tambah){

global $datadesa, $iddesa, $datawarga, $pdf;
	kopsurat($datadesa);
	
	$pdf->ln();
	$pdf->ln();
	$pdf->SetFont('Helvetica','U',11);
	$pdf->Cell(173,6,'SURAT KETERANGAN BELUM PERNAH MENIKAH',0,0,'C');
	
	$pdf->ln();
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(173,4,'Nomor : '.nosuratsaiti($data, $tambah),0,0,'C');

$pdf->ln();
	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Yang bertanda tangan di bawah ini, ');
	
	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Nama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Jabatan');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . 'Kepala Desa ' . ucwords($datadesa['desa']));

	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Menerangkan dengan sebenarnya bahwa : ');

$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'1.');

$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Nama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['nama']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Tempat/Tanggal lahir');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['templahir'] . ', ' . date('d F Y',strtotime($datawarga['tgllahir']))));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'NIK');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['nik']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Agama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['agama']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Pekerjaan');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['pekerjaan']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'alamat');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . 'Dusun '.ucwords($datawarga['dusun']).', RT '.$datawarga['rt'].', desa '.ucwords($datawarga['desa']));

$pdf->ln();
	$pdf->SetX(50);
	$pdf->SetFont('Helvetica','BU',11);
	$pdf->Cell(20,7,'Dan');

$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'2.');

$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Nama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['nama']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Tempat/Tanggal lahir');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['templahir'] . ', ' . date('d F Y',strtotime($datawarga['tgllahir']))));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'NIK');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['nik']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Agama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['agama']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Pekerjaan');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['pekerjaan']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'alamat');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . 'Dusun '.ucwords($datawarga['dusun']).', RT '.$datawarga['rt'].', desa '.ucwords($datawarga['desa']));
// -----
$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','BI',11);
	$pdf->MultiCell(172,7,'Bahwa yang bersangkutan benar benar TIDAK memiliki hubungan darah.');

	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->MultiCell(172,7,'Demikian surat keterangan ini kami buat dengan benar untuk dapat dipergunakan sebagaimana mestinya');

					$pdf->ln();
					$pdf->ln();
					$pdf->Cell(175,7,ucwords($iddesa).', '.date('d F Y',strtotime($data['id'])),0,0,'C');

					$pdf->ln();
					$pdf->Cell(175,7,'Kepala Desa '. ucwords($iddesa),0,0,'C');

					// $pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->SetFont('Helvetica','U',11);
					$pdf->Cell(175,7,mb_strtoupper($datadesa["kades"]),0,0,'C');

// echo "
// Surat keterangan tidak ada hubungan darah

// Yang bertanda tangan di bawah ini 

// nama: jabatan:

// Menerangkan dengan sebenarnya bahwa,

// Nama: tempat tanggal lahir: nik:
// Agama: pekerjaan : alamat:

// Dan 

// Sda

// Yang namanya tersebut diatas benar-benar tidak memiliki hubungan darah.

// Demikian surat keterangan ini dibuat untuk dipergunakan sebagai pengantar persyaratan menikah.

// Tanda tangan
// ";
}
// //////////////////////////////////////////////
// ----- fungsi surat -----
function skbelumnikah($data, $tambah){

	global $datadesa, $iddesa, $datawarga, $pdf;
	kopsurat($datadesa);
	
	$pdf->ln();
	$pdf->ln();
	$pdf->SetFont('Helvetica','U',11);
	$pdf->Cell(173,6,'SURAT KETERANGAN BELUM PERNAH MENIKAH',0,0,'C');
	
	$pdf->ln();
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(173,4,'Nomor : '.nosuratsaiti($data, $tambah),0,0,'C');

$pdf->ln();
	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Yang bertanda tangan di bawah ini, ');
	
	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Nama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datadesa["kades"]));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Jabatan');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . 'Kepala Desa ' . ucwords($datadesa['desa']));

	$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Menerangkan dengan sebenarnya bahwa : ');

$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'1.');

$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Nama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['nama']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Tempat/Tanggal lahir');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['templahir'] . ', ' . date('d F Y',strtotime($datawarga['tgllahir']))));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'NIK');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['nik']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Agama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['agama']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Pekerjaan');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['pekerjaan']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'alamat');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . 'Dusun '.ucwords($datawarga['dusun']).', RT '.$datawarga['rt'].', desa '.ucwords($datawarga['desa']));

$pdf->ln();
	$pdf->SetX(50);
	$pdf->SetFont('Helvetica','BU',11);
	$pdf->Cell(20,7,'Dan');

$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'2.');

$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Nama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['nama']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Tempat/Tanggal lahir');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['templahir'] . ', ' . date('d F Y',strtotime($datawarga['tgllahir']))));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'NIK');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['nik']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Agama');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['agama']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'Pekerjaan');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . ucwords($datawarga['pekerjaan']));

	$pdf->ln();
	$pdf->SetX(30);
	$pdf->SetFont('Helvetica','',11);
	$pdf->Cell(20,7,'alamat');
	$pdf->SetX(80);
	$pdf->SetFont('Helvetica','B',11);
	$pdf->Cell(100,7,': '.' ' . 'Dusun '.ucwords($datawarga['dusun']).', RT '.$datawarga['rt'].', desa '.ucwords($datawarga['desa']));
// -----
$pdf->ln();
	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','BI',11);
	$pdf->MultiCell(172,7,'Bahwa yang bersangkutan benar benar belum pernah menikah.');

	$pdf->ln();
	$pdf->SetX(20);
	$pdf->SetFont('Helvetica','',11);
	$pdf->MultiCell(172,7,'Demikian surat keterangan ini kami buat dengan benar untuk dapat dipergunakan sebagaimana mestinya');

					$pdf->ln();
					$pdf->ln();
					$pdf->Cell(175,7,ucwords($iddesa).', '.date('d F Y',strtotime($data['id'])),0,0,'C');

					$pdf->ln();
					$pdf->Cell(175,7,'Kepala Desa '. ucwords($iddesa),0,0,'C');

					// $pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->ln();
					$pdf->SetFont('Helvetica','U',11);
					$pdf->Cell(175,7,mb_strtoupper($datadesa["kades"]),0,0,'C');	

}

// ________________________________________________
 ?>

<!-- belum ada function -->

<!-- sk hubungan darah -->
<!-- sk belum nikah -->
<!-- surat pernyataan bank -->
<!-- surat pernyataan umum -->