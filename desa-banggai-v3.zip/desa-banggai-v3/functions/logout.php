<?php 
// session_start();
require_once "../core/init.php";

// redirect kalau user belum login
// session_destroy();
// session_unset($_SESSION['user']);
unset($_SESSION['user']);
if(isset($_SESSION['error'])){unset($_SESSION["error"]);}
header( 'Location: login.php' );
 ?>



 