<?php

// -----
function register_user( $nama, $pass, $desa ){
    global $conn;
    $nama = mysqli_real_escape_string($conn, $nama);
    $pass = mysqli_real_escape_string($conn, $pass);
    $pass = password_hash( $pass, PASSWORD_DEFAULT);
    $desa = mysqli_real_escape_string($conn, $desa);

    $queryinsert = "INSERT INTO users (username, password, desa) VALUES ('$nama', '$pass', '$desa')";
    // variabel = " QUERY database ( field1, field2 )" VALUES ( 'input1','input2' )";

    if( mysqli_query ($conn, $queryinsert) ){
        // echo 'berhasil';
        return true;
        }else{
        // echo 'gagal';
        return false;}
    }

// -----
function register_cek_nama($nama){
    global $conn;
    $nama = mysqli_real_escape_string($conn, $nama);

    $query = "SELECT * FROM users WHERE username = '$nama'";
    if( $result = mysqli_query( $conn, $query ) ){
        if(mysqli_num_rows($result) == 0) return true;
        else return false;
    }
}

function register_cek_nik($nik, $desa){
    global $conn;
    $nik = mysqli_real_escape_string($conn, $nik);

    $query = "SELECT * FROM penduduk WHERE nik = '$nik' AND desa = '$desa' ";
    if( $result = mysqli_query( $conn, $query ) ){
        if(mysqli_num_rows($result) == 0) return false;
        else return true;
    }
}






// -----
function cek_pass($nama, $pass){
    global $conn;
        $nama = mysqli_real_escape_string($conn, $nama);
        $pass = mysqli_real_escape_string($conn, $pass);
        
        $query = "SELECT password FROM users WHERE username = '$nama'";
        $result = mysqli_query($conn, $query);
        $hash = mysqli_fetch_assoc($result)['password'];

    if (password_verify($pass, $hash)) {
        // die('berhasil');
        return true;
    } else {
        // die('gagal');
        return false;
    }
}

// -----
function login_cek_nama($nama){
    global $conn;
    $nama = mysqli_real_escape_string($conn, $nama);

    $query = "SELECT * FROM users WHERE username = '$nama'";

    if( $result = mysqli_query( $conn, $query ) ){
        if(mysqli_num_rows($result) != 0) return true;
        else return false;
    }
}

// -----
function cek_status_user($nama){
    global $conn;
    $nama = mysqli_real_escape_string($conn, $nama);
    $querySelect = "SELECT role FROM users WHERE username = '$nama'";
    $result = mysqli_query($conn, $querySelect);
    $status = mysqli_fetch_assoc($result)['role'];
    
    return $status;
    }
?>