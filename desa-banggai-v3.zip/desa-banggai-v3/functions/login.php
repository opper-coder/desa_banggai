<?php

require_once '../view/top_body.php';
require_once "../core/init.php";    

$tema = $_SESSION["tema"];
$desa = $_SESSION["desa"];

// -----
$error = '';

// validasi login
if( isset($_POST["submitx"]) ){
    $nama = $_POST["usernamex"];
    $pass = $_POST["passwordx"];
    if (!empty( trim($nama)) && !empty( trim($pass)) ) {
        if(login_cek_nama($nama)){
            if(cek_pass($nama, $pass)){
                $_SESSION['user'] = $nama;

                header( 'Location: login.php?theme=../view/theme/theme_green.php&iddesa=saiti' );

                }else{ $error = 'data(password) ada yang salah'; }
            }else{ $error = 'namanya belum terdaftar di database';}
        }else{ $error = 'field tidak boleh kosong'; }   
    }

require_once "../view/header.php";
?> 


<br>
<?php 
    if(!isset($_SESSION['user'])){?>
        <div class="containerBaca marginB16 w3-white w3-round w3-border w3-padding" >
            <p>Jika anda sudah berhasil register, silahkan login dibawah ini:</p> 
            <br>
            <form action="login.php" method="post">
                <label for="username">Nama</label><br>
                <input type="text" name="usernamex" id="username"><br><br>
                <label for="password">Password</label><br>
                <input type="password" name="passwordx" id="password"><br><br>
                <button class="w3-btn w3-green w3-round w3-small" type="submit" name="submitx">Masuk !</button>
                <br>
                <br>
                
                <?php  if( $error != ''){ ?>  
                    <div id="error" class="w3-orange paddingKr10">
                        <?php echo $error; ?>
                    </div>
                <?php } ?>

                <?php if( isset($_SESSION['error'])) { ?>
                    <div  class="w3-orange paddingKr10">
                        <?php echo $_SESSION['error']; ?>
                    </div>
                <?php } ?>

            </form>
            <br>
        </div>
<?php  
    
    } else { ?>
<div class="containerBaca marginB16 w3-white w3-round w3-border w3-padding" >

    <div style="text-align: center">
        <img src="../img/saiti/aparat/periode7/husna.jpg" alt="tidak ada data foto" style="width: 80px; border-radius: 50%; margin: auto;">
        <h3>Selamat datang <?php echo ucfirst($_SESSION['user']); ?> </h3> 
        <p>Anda dapat menggunakan semua layanan yang di sediakan di aplikasi ini dengan ketentuan yang berlaku</p>
    </div>

<br><br>
    <ul style="list-style-type: none;">
        <li><a href="">Inbox pesan</a></li>
        <li><a href="../pages/n6_status_layanan.php?iddesa=<?= $desa; ?>&theme=<?= $tema; ?>&sender=<?= $_SESSION['user']; ?>">Status layanan</a></li>
        <li><a href="">Pengaturan</a></li>
    </ul>

</div>





<?php } ?>





<?php 
require_once "../view/footer.php"; 
?>