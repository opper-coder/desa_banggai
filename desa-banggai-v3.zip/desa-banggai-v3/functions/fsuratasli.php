<?php 
// ALGORITMA KODE

// 1. referensi variabel 
// 2. berisi utility surat
// 3. berisi function surat

// 4. bikin ukuran kertas
// 5. bikin jarak kertas dibawah nya

 ?>
 
 <?php 
// ??????????????? latihan ?????????????????????







// ???????????????????????????????????????????

  ?>
<?php 
// ________________ REFERENSI VAR _________________



// ________________________________________________
// ____________________ UTILITY ___________________

function nosuratsaiti($data, $tambah){

	// format 402/300/ST/2020 
	// unsur2 :
	// kode surat dari: layanan
	// nomor urut dari: layout
	// desa dari 

	$iddesa = $data['desa'];
	$idlayout = $data['id'];
	$idlayanan = $data['idlayanan'];

	$tahun = query("SELECT YEAR(tglterbit) FROM suratkeluar WHERE desa='$iddesa' AND id='$idlayout'");
	$sekarang = date('Y');
	// $sekarang = 2030;
	
		if( $tahun['YEAR(tglterbit)'] == $sekarang ){
			$nourut = $data['urut'] + $tambah;
		}else{$nourut = 0 + $tambah;}

	$kodesurat = query("SELECT kodesurat FROM layanan WHERE id='$idlayanan'");

	return "<b>" . $kodesurat['kodesurat'] . ' / ' . $nourut .' / '.'ST'.' / '. date('Y') . "</b>";
	
	}


// ----- fungsi kop surat -----
function kopsurat($datadesa){
	 return '
	<header class="kopSurat">
		<img src="../img/logo Banggai.png" alt="" >
		<h5 style="text-transform: uppercase;">
			<b>
				<span>PEMERINTAH DAERAH KABUPATEN BANGGAI</span>
			</b><br>
			<span style="font-size: 26px;">DESA '. $datadesa["namadesa"].' KEC. '. $datadesa["kec"].'</span><br>
			<span style="font-size: 16px; text-transform: capitalize;">Sekretariat : '. $datadesa["sekretariat"] .'</span>
		</h5>
		<img src="../img/'. $datadesa['logodesa'] . '" alt="">
	</header>
'; } 


// ----- fungsi perihal -----
function perihal($lampiran, $perihal){
	global $data; $tambah;

	return '
	<br>
	<div class="perihal">
		<table class="w3-text-black">
			<tr>
				<td>Nomor</td>
				<td style="padding-left: 10px;">:</td>
				<td>'. nosuratsaiti($data, $tambah) . '</td>
			</tr>
			<tr>
				<td>Lampiran</td>
				<td style="padding: 0 5px 0 10px;"> :</td>
				<td><b>'.$lampiran.'</b></td>
			</tr>
			<tr>
				<td>Perihal</td>
				<td style="padding-left: 10px;">:</td>
				<td><b>'.$perihal.'</b></td>
			</tr>
		</table>
	</div> 
'; } 


// ----- fungsi kepada -----
function kepada($kepada, $instansi, $di){

return '
	<div class="jarak20"></div>
	<div class="kepada">
		<p style="padding-left: 20px;"><b>Kepada Yth:</b></p>
		<p style="text-transform: capitalize;">'.$kepada.'</p>
		<p>'.$instansi.'</p>
		<p>di-</p>
		<b style="text-decoration: underline; padding-left: 40px;">'.$di.'</b>
	</div>
	';
 }

// ________________________________________________

// ________________ FUNCTION SURAT ________________
function sktm($data, $tambah){

}

// ----- fungsi surat -----
function n1($data, $tambah){
echo "
Kantor desa
Kecamatan
kabupaten garis miring kota
Surat pengantar perkawinan
Nomor
yang bertanda tangan di bawah ini koma menerangkan dengan sesungguhnya bahwa titik dua
Nama lengkap jenis kelamin tempat dan tanggal lahir warga negara agama pekerjaan tempat tinggal bin status perkawinan:
a. Jika pria koma terangkan sejagad udah atau beristri dan berapa istrinya
b. Jika wanita terangkan perawan atau janda
Adalah benar anak dari perkawinan seorang pria:
Nama lengkap dan alias nomor induk kependudukan (NIK) tempat dan tanggal lahir kewarganegaraan agama pekerjaan alamat
Dengan seorang wanita
Sda
demikian surat pengantar ini dibuat dengan mengingat sumpah jabatan dan untuk dipergunakan sebagaimana mestinya
Tanda tangan kepala desa
";
}

// ----- fungsi surat -----
function n2($data, $tambah){
echo "
Permohonan kehendak perkawinan

Perihal : permohonan kehendak perkawinan

Kepada yth
Kepala kua kecamatan hon
Di hhhhjj

Dengan hormat kami mengajukan permohonan kehendak perkawinan untuk atas nama kami calon suami ... Dengan calon istri ... Pada hari ... 
Tanggal ... jam bertempat di rumah mempelai wanita di desa saidi kecamatan open kabupaten banggai
bersama ini kami sampaikan surat-surat yang diperlukan untuk diperiksa sebagai berikut titik dua
Surat pengantar perkawinan dari desa garis miring kelurahan (n1)
Surat permohonan kehendak nikah (N2)
Persetujuan jalan mempelai (n3)
Surat izin orang tua
Fotokopi ktp : yakin koma orang tua dan saksi
Fotokopi akta kelahiran
Fotokopi kartu keluarga
Pas foto 2x3 = 3 lembar latar biru
Pas foto 4x6 = 1 lembar latar biru
Akta cerai asli bagi janda garis miring duda
Rekomendasi pindah nikah
Slip setoran bank
KK asli (bagi yang mau pemisahan KK)
Demikian permohonan ini kami sampaikan, kiranya dapat diperiksa, dihadiri dan dicatat sesuai dengan ketentuan peraturan perundang-undangan.
Wassalam,
Diterima tanggal
Yang menerima, garis baru kepala KUA/penghulu
Pemohon
";
}

// ----- fungsi surat -----
function n3($data, $tambah){
echo "
Surat persetujuan mempelai
1. calon suami:
Nama lengkap dan alias
Bin
Tempat dan tanggal lahir
 warga negara
Agama
Pekerjaan tempat tinggal

Calon istri
Sama dengan diatas

Menyatakan dengan sesungguhnya bahwa atas dasar sukarela, dengan kesadaran sendiri, tanpa paksaan dari siapapun juga, setuju untuk melangsungkan pernikahan.

Demikian surat persetujuan ini dibuat untuk digunakan seperlunya.

 tanggal

Calon suami
Calon istri



";
}

// ----- fungsi surat -----
function n4($data, $tambah){
echo "
Surat izin orang tua

Yang bertanda tangan di bawah ini, menerangkan dengan sesungguhnya bahwa:

Nama lengkap dan alias: bin:
Nomor induk kependudukan (Nik):
Tempat dan tanggal lahir: kewarganegaraan: agama: pekerjaan: alamat:

Sda

Adalah benar ayah dan ibu kandung dari

Sama dengan diatas

memberikan izin kepada anak kami untuk melakukan perkawinan dengan:

Sda

Demikian surat izin ini dibuat dengan kesadaran tanpa ada paksaan dari siapapun dan untuk digunakan seperlunya.

Tanggal

Tanda tangan ayah ibu

";
}

// ----- fungsi surat -----
function n5($data, $tambah){
echo "
Kantor urusan agama kecamatan nuhon  kabupaten Banggai

Tanggal

Nomor: lampiran: perihal:
Pemberitahuan kekurangan syarat/penolakan perkawinan/rujuk

Kepada

dengan hormat, setelah dilakukan pemeriksaan terhadap persyaratan pendaftaran perkawinan yang diatur dalam peraturan perundang-undangan, cara permohonan pendaftaran perkawinan atau rujuk saudara..... Dengan .... Diberitahukan sebagai berikut:

Perkawinan dapat dilakukan dengan melengkapi persyaratan...

Tidak dapat dilaksanakan (ditalak), karena tidak melengkapi persyaratan berupa....

Demikian agar menjadi dimaklumi.

Wa sallam kepala,


";
}

// ----- fungsi surat -----
function n6($data, $tambah){
echo "
Surat keterangan kematian suami/istri
Nomor

Yang bertanda tangan di bawah ini menerangkan dengan sesungguhnya bahwa:

Nama:bin/binti:
Tempat dan tanggal lahir: warga negara: agama: pekerjaan terakhir: tempat tinggal terakhir:

Telah meninggal dunia pada tanggal
:

Sama dengan diatas

Adalah suami/istri orang yang telah meninggal tersebut di atas.

Demikian surat keterangan ini dibuat dengan mengingat sumpah jabatan dan untuk dipergunakan seperlunya.

Tanggal garis baru tanda tangan
";
}

// ----- fungsi surat -----
function n7($data, $tambah){
echo "

";
}

// ----- fungsi surat -----
function n8($data, $tambah){
echo "
Berita acara pemeriksaan perkawinan
Nomor

Pada hari ini tanggal bulan tahun

bertempat di KUA kecamatan nuhon kabupaten Banggai provinsi Sulawesi tengah, telah dilakukan pemeriksaan perkawinan terhadap:

nama calon suami: nama calon istri: nama calon wali: rencana agar perkawinan: hari/tanggal. 2 masehi waktu. 2 Hijriyah

Nama petugas pemeriksa: jabatan:

Tabel


";
}

// ----- fungsi surat -----
function sktt($data, $tambah){
echo "

";
}

// ----- fungsi surat -----
function domisili($data, $tambah){
echo "
Top surat

Nomor surat

Yang bertanda tangan di bawah ini,

Nama 
jabatan

Menerangkan dengan sebenarnya bahwa:

Nama 
tempat tanggal lahir 
Nik
Jenis kelamin 
agama 
status kawin
 pekerjaan 
alamat

adalah benar-benar yang bersangkutan sampai dengan dikeluarkan surat keterangan ini masih berdomisili di desa saidi kecamatan nuhun kabupaten banggai provinsi sulawesi tengah

demikian surat keterangan ini dibuat dan diberikan kepada yang bersangkutan untuk digunakan sebagaimana perlunya

Tanda tangan
Kepala desa 12
";	echo "halo domisili";
}

// ----- fungsi surat -----
function spermohonankreditusaha($data, $tambah){

}

// ----- fungsi surat -----
function skhasilortu($data, $tambah){
echo "

";
}

// ----- fungsi surat -----
function skusaha($data, $tambah){
echo "

";	echo "halo surat keterangan usaha";
}

// ----- fungsi surat -----
function skkb($data, $tambah){
echo "
Yang bertanda tangan di bawah ini kepala desa siti kecamatan nuhon kabupaten banggai , menerangkan bahwa:

Nama 
jenis kelamin 
tempat tanggal lahir 
status perkawinan 
agama
Alamat

yang namanya tersebut di atas menurut penelitian kami hingga saat dikeluarkan surat keterangan ini, oknum tersebut diatas ber kelakuan baik dan tidak pernah terlibat sesuatu perkara /organisasi yang mengganggu keamanan dan ketertiban

demikian surat pengantar ini dibuat dengan benar dan diberikan kepada yang bersangkutan untuk dipergunakan membuat rekomendasi catatan kepolisian l(rck)di polsek nuhon

Tertanda kepala desa 
Tanda tangan


";
}

// ----- fungsi surat -----
function skuasa($data, $tambah){
echo "
Yang bertanda tangan di bawah ini 

nama umur pekerjaan alamat

Dengan ini memberi kuasa kepada:

Nama umur pekerjaan alamat

untuk menggunakan hak milik kami sendiri yang berupa sertifikat /surat penyerahan/ajb akta hibah no.... Tanggal,.... Dengan luas M2 atas nama yang terletak di desa sayati kecamatan hon kabupaten banggai provinsi sulawesi tengah. Dengan batas-batas:

Utara timur selatan barat

Sebagai jaminan kredit pada pt bank rakyat indonesia persero tbk unit bunta

Dengan demikian apabila dikemudian hari ternyata yang bersangkutan tersebut di atas tidak memenuhi kewajiban/bayar pinjaman baik perokok maupun bunga, maka kami tidak keberatan jika hak milik kami di atas disita oleh perang rakyat indonesia unit bunta yang diberi kuasa olehnya kemudahan dijual di bawah tangan atau dilelang di muka umum, dan hasilnya digunakan untuk melunasi kredit yang bersangkutan.

Surat kuasa ini tidak akan batal walaupun pemberi kuasa meninggal dunia, namun demikian akan batal dengan sendirinya apabila terjadi setelah di lunasi.

Demikian surat kuasa ini kami buat tanpa paksaan dari pihak manapun, ada dapat dipergunakan sebagaimana mestinya

Tanda tangan tiga orang
";
}

// ----- fungsi surat -----
function sjb($data, $tambah){
echo "

";
}

// ----- fungsi surat -----
function spengantar($data, $tambah){
echo "

";
}

// ----- fungsi surat -----
function spernyataan($data, $tambah){
echo "
Saya yang bertanda tangan di bawah ini:

Nama: tempat/tanggal lahir:
alamat:

dengan ini menyatakan bahwa saya benar-benar mengajukan kredit untuk kepentingan pribadi dan bukan untuk dipergunakan oleh pihak lain dan saya bertanggung jawab penuh atas kredit yang saya ambil di BRI unit kontak sampai dengan lunas.

Demikian surat keterangan ini dibuat untuk digunakan seperlunya.

Tanda tangan



";
}

// ----- fungsi surat -----
function skpindah($data, $tambah){
echo "

";
}

// ----- fungsi surat -----
function skpengantar($data, $tambah){
echo "

";
}

// ----- fungsi surat -----
function sahliwaris($data, $tambah){
echo "
Kok surat

Set keterangan ahli waris

kami yang bertanda tangan di bawah ini adalah para ahli waris dari almarhum Maryoso menerangkan bahwa dengan sesungguhnya dan sanggup angkat sumpah bahwa almarhum martabak bertempat tinggal terakhir di desa site kecamatan mohon kabupaten banggai dan telah meninggal dunia pada hari jumat tanggal 8 bulan maret tahun duaributigabelas, dan dari perkawinan dengan istri Zaenab, dikaruniai 4 (empat) orang anak yakni sebagai berikut:

Satu dua tiga

Dengan demikian kami kelima orang ahli waris garis miring istri dan anak-anak adalah satu-satunya ali waris dari mendiang almarhum martabak

Siti tanggal

Kami para ahli waris:

Satu dua tiga empat

Tanda tangan

Sudah dua tiga empat

Saksi saksi:

Nama umur alamat pekerjaan tanda tangan

Nomor
Tanggal

Dikuatkan oleh kami camat nuhun

Disahkan oleh kami kepala desa said
";
}

// ----- fungsi surat -----
function sktmbpjs($data, $tambah){
echo "

";
}

// ----- fungsi surat -----
function sktmpend($data, $tambah){
echo "

";
}

// ----- fungsi surat -----
function skhubdarah($data, $tambah){
echo "
Surat keterangan tidak ada hubungan darah

Yang bertanda tangan di bawah ini 

nama: jabatan:

Menerangkan dengan sebenarnya bahwa,

Nama: tempat tanggal lahir: nik:
Agama: pekerjaan : alamat:

Dan 

Sda

Yang namanya tersebut diatas benar-benar tidak memiliki hubungan darah.

Demikian surat keterangan ini dibuat untuk dipergunakan sebagai pengantar persyaratan menikah.

Tanda tangan
";
}

// ----- fungsi surat -----
function skbelumnikah($data, $tambah){
echo "
Surat keterangan belum pernah menikah

yang bertanda tangan di bawah ini kepala desa Sayati kecamatan nuhon kabupaten Banggai, menerangkan dengan sesungguhnya bahwa:

Nama: tempat tanggal lahir: nik: agama: pekerjaan: alamat: 

Yang namanya tersebut diatas benar-benar belum pernah menikah.

Demikian surat keterangan ini dibuat untuk dipergunakan sebagaimana mestinya.

Tanggal tanda tangan


";
}

// ________________________________________________
 ?>

<!-- belum ada function -->

<!-- sk hubungan darah -->
<!-- sk belum nikah -->
<!-- surat pernyataan bank -->
<!-- surat pernyataan umum -->