<?php 
// CARA PAKAI FUNCTION 
// sebelumnya panggil dulu div.kertasA4 ATAU .kertasLegal
// lalu panggil semua function di dalam div tersebut




 ?>
<?php // ================= generate no. surat =================

function nosurat($kode){
	// format    001/sktm/saiti/09/2020 

	// baca max id lalu ++
	// kode surat yang dibuat misalnya ../sktm/../
	// baca $iddesa 
	// baca bulan
	// baca tahun

	// CARA PAKAI 
		// kode isi dengan kode yang ada

	global 	$conn,
	 		$iddesa,
	 		$idkec,
	 		$initsurat,
	 		$kodesurat;

	// di query dibawah bisa ditambah AND tglterbit=2020 di ambil dari tgl sekarang
	$query = "SELECT max(id) as idterakhir FROM suratkeluar WHERE desa='$iddesa' ";
	$result = mysqli_query($conn, $query);
	$dataid = mysqli_fetch_assoc($result);
	
	echo "<b style='text-transform: uppercase;'>";
	echo $kodesurat . " / "; echo $dataid['idterakhir']+1 .' / '.$initsurat.' / '.date('Y');
	echo "</b>";
	}
?>

<?php // ================= kop surat =================

function kopsurat(){
	// CARA PAKAI 

	global 	$iddesa,
			$idkec,
			$sekret,
			$logodesa;
	 ?>
	<header class="kopSurat">
		<img src="../img/logo Banggai.png" alt="">
		<h5 style="text-transform: uppercase;">
			<b>
				<span>PEMERINTAH DAERAH KABUPATEN BANGGAI</span>
			</b><br>
			<span style="font-size: 26px;">DESA <?= $iddesa ?> KEC. <?= $idkec ?></span><br>
			<span style="font-size: 16px; text-transform: capitalize;">Sekretariat : <?= $sekret ?></span>
		</h5>
		<img src="../img/<?= $logodesa; ?>" alt="">
	</header>
<?php } ?>

<?php // ================= perihal surat =================

function perihal($lampiran, $perihal){?>
	<br>
	<div class="perihal">
		<table class="w3-text-black">
			<tr>
				<td>Nomor</td>
				<td style="padding-left: 10px;">:</td>
				<td><?php nosurat("sktm"); ?></td>
			</tr>
			<tr>
				<td>Lampiran</td>
				<td style="padding: 0 5px 0 10px;"> :</td>
				<td><b><?= $lampiran; ?></b></td>
			</tr>
			<tr>
				<td>Perihal</td>
				<td style="padding-left: 10px;">:</td>
				<td><b><?= $perihal; ?></b></td>
			</tr>
		</table>
	</div>
<?php } ?>

<?php // ================= kepada =================

function kepada($kepada){?>
	<!-- CARA PAKAI 
	* isi $kepada
	 -->
	<div class="jarak20"></div>
	<div class="kepada">
		<p style="padding-left: 20px;"><b>Kepada Yth:</b></p>
		<p style="text-transform: capitalize;"><?= $kepada; ?></p>
		<p>Kab. Banggai</p>
		<p>di-</p>
		<b style="text-decoration: underline; padding-left: 40px;">Banggai</b>
	</div>
<?php } ?>

<?php // ================= salam dan pembukaan =================

function salam(){?>
	<!-- CARA PAKAI
	* masih bisa berubah
	 -->

	<br><br>
	<p>Assalamu'alaikum Wr. Wb</p>
	<br>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid harum cupiditate mollitia placeat quam, repellendus expedita magni vitae, officiis eaque.</p>
<?php } ?>

<?php // ================= penutup dan penutupan =================
function penutup(){?>
	<!-- CARA PAKAI 
	* masih bisa berubah
	-->

	<br>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid harum cupiditate mollitia placeat quam, repellendus expedita magni vitae, officiis eaque.</p>
	<br>
	<p>Wassalamu'alaikum Wr. Wb</p>

<?php } ?>

<?php // ================= isi surat =================

function isisurat(){?>
	<!-- CARA PAKAI 
	* belum di selesai
	* mungkin tak dipakai
	-->
	<br>
	<p>isi nya tinggal ambil dari data base belum selesai ini ya !!!!!!!!!!</p>
<?php } ?>

<?php // ================= tanda tangan =================

function ttd(

	// ini kayaknya kode tidak di pakai

	$jabatan1,
	$jabatan2,
	$jabatan3,
	
	$pejabat1,
	$pejabat2,
	$pejabat3

			){?>

	<?php 
	global 	$iddesa, 
			$idkec; 

	if ($jabatan1 = 1) {
		echo "kosoooooong";
	}else{ echo "isiiiiii";}

	?>

	<div class="container">
		<div class="container">Saiti, 22 Desember 2019</div>
		<div class="jarak30"></div>
		<div class="kotakTtd">
			<div class="ttd1">
				<p>Mengetahui</p>
				<p style="text-transform: capitalize;"><?= $jabatan1 ." ". $iddesa; ?></p>
				<div class="jarak40"></div>
				<div class="jarak40"></div>
			</div>
			<div class="ttd2">
				<p>Mengetahui</p>
				<p style="text-transform: capitalize;"><?= $jabatan2; ?></p>
				<div class="jarak40"></div>
				<div class="jarak40"></div>
			</div>
			<div class="ttd3">
				<p>Mengetahui</p>
				<p style="text-transform: capitalize;"><?= $jabatan3; ?></p>
				<div class="jarak40"></div>
				<div class="jarak40"></div>
				
			</div>

			<b class="ttd1 nmttd"><?= $pejabat1; ?></b>
			<b class="ttd2 nmttd"><?= $pejabat2; ?></b>
			<b class="ttd3 nmttd"><?= $pejabat3; ?></b>
		</div>
	</div>
<?php } ?>


<?php // ================= templat contoh =================

function sktm($nik, $perihal){
	echo "haloo: ".$nik." ".$perihal;
	echo "<br>";
	nosurat('skk');
	}
?>


<?php // ================= isi surat =================?>


<!-- ************************************************************
*****************************************************************
*****************************************************************
*****************************************************************-->








<?php // ================= TEMPLAT SURAT =================
// =================== surat sktm persalinan ==================
function sktmpersalinan($nik){
		global 	$iddesa, 
				$idkec,
				$idkab,
				$kodesurat;

		kopsurat();?>
		<!-- CSS -->
		<style>
			.ttd1{
				visibility: hidden;
			}
			.ttd2{
				visibility: visible;
			}
			.ttd3{
				visibility: hidden;
			}
		</style>

		<!-- BODY SURAT -->
			<br>
			<h6 style="
			text-align: center; 
			text-decoration: underline;
			"><b>SURAT KETERANGAN TIDAK MAMPU / SKTM (kesehatan)</b></h6>
			<p style="text-align: center;">Nomor : <?php nosurat($kodesurat); ?></p>
			
			<br>
			<p>Yang bertanda tangan di bawah ini,</p>
				<div class="containerisian">
					<p>Nama</p><span>:</span><b class="hurufCaSe"><?php globaldesa("kades"); ?></b>
					<p>jabatan</p><span>:</span><b class="hurufCaSe">kepala desa <?= $iddesa; ?></b>
				</div>
			<p>menerangkan dengan sebenarnya bahwa:</p>
				<div class="containerisian">
					<p>Nama</p><span>:</span><b><?php querypenduduk("nama", $nik); ?></b>
					<p>Jenis kelamin</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("kelamin", $nik); ?></b>
					<p>Tempat/Tanggal lahir</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("templahir", $nik); echo ", "; querypenduduk("tgllahir", $nik); ?></b>
					<p>NIK</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("nik", $nik); ?></b>
					<p>Agama</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("agama", $nik); ?></b>
					<p>Pekerjaan</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("pekerjaan", $nik); ?></b>
					<p>Alamat</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("alamat", $nik); ?></b>
				</div>

				<b>Suami dari: </b>
			<br><br>

			<p>Bahwa yang bersangkutan benar benar warga desa <?= $iddesa; ?> Kecamatan <?= $idkec; ?> Kabupaten <?= $idkab; ?> Provinsi Sulawesi Tengah dan tergolong dalam keluarga berekonomi lemah (TIDAK MAMPU) </p>
			<br>
				<p>Demikian surat keterangan ini kami buat dengan benar untuk dapat dipergunakan sebagai mengurus <b>persalinan</b></p>

		<!-- tanda tangan -->
			<br>
			<div class="container">
				<div class="container"><?= $iddesa; ?>, <?= date('d M Y'); ?></div>
				<div class="jarak30"></div>
				<div class="kotakTtd">
					<div class="ttd1">
						<p>Mengetahui</p>
						<p>Kepala Desa Saiti kecamatan Nuhon</p>
						<div class="jarak40"></div>
						<div class="jarak40"></div>
					</div>
					<div class="ttd2">
						<p>Mengetahui</p>
						<p>Kepala Desa Saiti</p>
						<div class="jarak40"></div>
						<div class="jarak40"></div>
					</div>
					<div class="ttd3">
						<p>Mengetahui</p>
						<p>Kepala Desa Saiti</p>
						<div class="jarak40"></div>
						<div class="jarak40"></div>
						
					</div>

					<b class="ttd1 nmttd" >Lamudi</b>
					<b class="ttd2 nmttd" ><?php globaldesa("kades"); ?></b>
					<b class="ttd3 nmttd" >Lamudi</b>
				</div>
			</div>
<?php } ?>

 <!-- =================== surat sktm kis ================== -->










 <?php 
 // =================== surat sktm bpjs/kis ==================
function sktmkis($nik){
		global 	$conn,
				$iddesa, 
				$idkec,
				$idkab,
				$kodesurat;

		kopsurat();?>
		<!-- CSS -->
		<style>
			.ttd1{
				visibility: hidden;
			}
			.ttd2{
				visibility: visible;
			}
			.ttd3{
				visibility: hidden;
			}
		</style>

		<!-- BODY SURAT -->
		
			<h6 style="
			text-align: center; 
			text-decoration: underline;
			"><b>SURAT KETERANGAN TIDAK MAMPU / SKTM (BPJS/KIS)</b></h6>
			<p style="text-align: center;">Nomor : <?php nosurat($kodesurat); ?></p>
							
			<p>menerangkan dengan sebenarnya bahwa:</p>
				<div class="containerisian">
					<p>Nama</p><span>:</span><b><?php querypenduduk("nama", $nik); ?></b>
					<p>Tempat Tanggal lahir / umur</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("templahir", $nik); echo ", "; querypenduduk("tgllahir", $nik); ?></b>
					<p>NIK</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("nik", $nik); ?></b>
					<p>Nomor KK</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("nokk", $nik); ?></b>
					<p>Status Hubungan dalam keluarga</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("sttskeluarga", $nik); ?></b>
					<p>Alamat</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("alamat", $nik); ?></b>
				</div>

				<p>Benar yang bersangkutan adalah warga desa <?= $iddesa; ?> Kecamatan <?= $idkec; ?> Kabupaten <?= $idkab; ?>, Yang termasuk miskin / tidak mampu. dengan susunan keluarga sebagai berikut</p>	
			<br>
		
<?php 
	$nokk = querypenduduk("nokk", $nik);
	$querytable = "SELECT * FROM penduduk WHERE desa='$iddesa' AND nokk='$nokk' ORDER BY 'id'";
	$resulttable = mysqli_query($conn, $querytable);
 ?>
				<table class="w3-table w3-bordered w3-border w3-striped w3-small">
					<tr>
						<th>No.</th>
						<th>Nama lengkap</th>
						<th>NIK</th>
						<th>Jenis</th>
						<th>Tempat lahir</th>
						<th>Tanggal lahir</th>
						<th>Status hubungan</th>
					</tr>
					<?php $i = 1; 
					while ($datatable = mysqli_fetch_assoc($resulttable)) {?>
					<tr>
						<td><?= $i; ?></td>
						<td><?= $datatable['nama']; ?></td>
						<td><?= $datatable['nik']; ?></td>
						<td><?= $datatable['kelamin']; ?></td>
						<td><?= $datatable['templahir']; ?></td>
						<td><?= $datatable['tgllahir']; ?></td>
						<td><?= $datatable['sttskeluarga']; ?></td>
					</tr>
					<?php $i++; } ?>
				</table>
			<br>
				<p>Demikian surat keterangan ini kami buat dengan benar untuk dapat dipergunakan sebagai kelengkapan mengurus <b>KIS/BPJS</b> kesehatan</p>

		<!-- tanda tangan -->
			<br>
			<div class="container">
				<div class="container"><?= $iddesa; ?>, <?php echo date('d M Y'); ?></div>
				<div class="kotakTtd">
					<div class="ttd1">
						<p>Mengetahui</p>
						<p>Kepala Desa <?= $iddesa; ?> kecamatan <?= $idkec; ?></p>
						<div class="jarak30"></div>
						<div class="jarak30"></div>
					</div>
					<div class="ttd2">
						<p>Mengetahui</p>
						<p>Kepala Desa <?= $iddesa; ?></p>
						<div class="jarak30"></div>
						<div class="jarak30"></div>
					</div>
					<div class="ttd3">
						<p>Mengetahui</p>
						<p>Kepala Desa <?= $iddesa; ?></p>
						<div class="jarak30"></div>
						<div class="jarak30"></div>
						
					</div>

					<b class="ttd1 nmttd" ><?php globaldesa("kades"); ?></b>
					<b class="ttd2 nmttd" ><?php globaldesa("kades"); ?></b>
					<b class="ttd3 nmttd" ><?php globaldesa("kades"); ?></b>
				</div>
			</div>
<?php } ?>
 <!-- ================================================== -->









<?php 
// =================== surat sktm sekolah ==================
function sktmsekolah($nik){
		global 	$conn,
				$iddesa, 
				$idkec,
				$idkab,
				$kodesurat;

		kopsurat();?>
		<!-- CSS -->
		<style>
			.ttd1{
				visibility: hidden;
			}
			.ttd2{
				visibility: visible;
			}
			.ttd3{
				visibility: hidden;
			}
		</style>

		<!-- BODY SURAT -->
			<br>
			<h6 style="
			text-align: center;
			text-decoration: underline;
			"><b>SURAT KETERANGAN TIDAK MAMPU / SKTM (kesehatan)</b></h6>
			<p style="text-align: center;">Nomor : <?php nosurat($kodesurat); ?></p>
			
			<br>
			<p class="huruf14">Yang bertanda tangan di bawah ini,</p>
				<div class="containerisian huruf14">
					<p>Nama</p><span>:</span><b class="hurufCaSe"><?php globaldesa("kades"); ?></b>
					<p>jabatan</p><span>:</span><b class="hurufCaSe">kepala desa <?= $iddesa; ?></b>
				</div>
			<p class="huruf14">menerangkan dengan sebenarnya bahwa:</p>

<?php 
$nokk = querypenduduk("nokk", $nik);
$queryortu = "SELECT * FROM penduduk WHERE desa='$iddesa' AND nokk='$nokk' AND sttskeluarga = 'ayah' OR sttskeluarga = 'ibu'";
$resultortu = mysqli_query($conn, $queryortu);
$dataortu = mysqli_fetch_assoc($resultortu);
 ?>
				<div class="containerisian huruf14">
					<p>Nama</p><span>:</span><b><?= $dataortu["nama"]; ?></b>
					<p>Jenis kelamin</p><span>:</span><b class="hurufCaSe"><?= $dataortu["kelamin"]; ?></b>
					<p>Tempat/Tanggal lahir</p><span>:</span><b class="hurufCaSe"><?= $dataortu["templahir"]; echo $dataortu["tgllahir"]; ?></b>
					<p>NIK</p><span>:</span><b class="hurufCaSe"><?= $dataortu["nik"]; ?></b>
					<p>Agama</p><span>:</span><b class="hurufCaSe"><?= $dataortu["agama"]; ?></b>
					<p>Pekerjaan</p><span>:</span><b class="hurufCaSe"><?= $dataortu["pekerjaan"]; ?></b>
					<p>Alamat</p><span>:</span><b class="hurufCaSe"><?= $dataortu["alamat"]; ?></b>
				</div>

				<p class="huruf14">Adalah Orang tua kandung dari: </p>
				<div class="containerisian huruf14">
					<p>Nama</p><span>:</span><b><?php querypenduduk("nama", $nik); ?></b>
					<p>Jenis kelamin</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("kelamin", $nik); ?></b>
					<p>Tempat/Tanggal lahir</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("templahir", $nik); echo ", "; querypenduduk("tgllahir", $nik); ?></b>
					<p>NIK</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("nik", $nik); ?></b>
					<p>Agama</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("agama", $nik); ?></b>
					<p>Pekerjaan</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("pekerjaan", $nik); ?></b>
					<p>Alamat</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("alamat", $nik); ?></b>
				</div>
			<br>

			<p class="huruf14">Bahwa yang bersangkutan benar benar warga desa <?= $iddesa; ?> Kecamatan <?= $idkec; ?> Kabupaten <?= $idkab; ?> Provinsi Sulawesi Tengah dan tergolong dalam keluarga berekonomi lemah (TIDAK MAMPU) </p>
			<br>
				<p class="huruf14">Demikian surat keterangan ini kami buat dengan benar untuk dapat dipergunakan sebagai mengurus <b>bantuan sekolah</b></p>

		<!-- tanda tangan -->
			<br>
			<div class="container huruf14">
				<div class="container"><?= $iddesa; ?>, <?= date('d M Y'); ?></div>
				<div class="jarak10"></div>
				<div class="kotakTtd">
					<div class="ttd1">
						<p>Mengetahui</p>
						<p>Kepala Desa Saiti kecamatan Nuhon</p>
						<div class="jarak10"></div>
						<div class="jarak40"></div>
					</div>
					<div class="ttd2">
						<p>Mengetahui</p>
						<p>Kepala Desa Saiti</p>
						<div class="jarak10"></div>
						<div class="jarak40"></div>
					</div>
					<div class="ttd3">
						<p>Mengetahui</p>
						<p>Kepala Desa Saiti</p>
						<div class="jarak10"></div>
						<div class="jarak40"></div>
						
					</div>

					<b class="ttd1 nmttd" >Lamudi</b>
					<b class="ttd2 nmttd" ><?php globaldesa("kades"); ?></b>
					<b class="ttd3 nmttd" >Lamudi</b>
				</div>
			</div>
<?php } ?>

 <!-- =================== surat sktm kis ================== -->









 <?php 
// =================== surat keterangan domisili ==================
function skdomisili($nik){
		global 	$conn,
				$iddesa, 
				$idkec,
				$idkab,
				$kodesurat;

		kopsurat();?>
		<!-- CSS -->
		<style>
			.ttd1{
				visibility: hidden;
			}
			.ttd2{
				visibility: hidden;
			}
			.ttd3{
				visibility: visible;
			}
		</style>

		<!-- BODY SURAT -->
			<br>
			<h6 style="
			text-align: center; 
			text-decoration: underline;
			"><b>SURAT KETERANGAN DOMISILI</b></h6>
			<p style="text-align: center;">Nomor : <?php nosurat($kodesurat); ?></p>
			
			<br>
			<p class="huruf14">Yang bertanda tangan di bawah ini,</p>
				<div class="containerisian huruf14">
					<p>Nama</p><span>:</span><b class="hurufCaSe"><?php globaldesa("kades"); ?></b>
					<p>jabatan</p><span>:</span><b class="hurufCaSe">kepala desa <?= $iddesa; ?></b>
				</div>
			<p class="huruf14">menerangkan dengan sebenarnya bahwa:</p>

				<div class="containerisian huruf14">
					<p>Nama</p><span>:</span><b><?php querypenduduk("nama", $nik); ?></b>
					<p>Jenis kelamin</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("kelamin", $nik); ?></b>
					<p>Tempat/Tanggal lahir</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("templahir", $nik); echo ", "; querypenduduk("tgllahir", $nik); ?></b>
					<p>NIK</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("nik", $nik); ?></b>
					<p>Agama</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("agama", $nik); ?></b>
					<p>Pekerjaan</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("pekerjaan", $nik); ?></b>
					<p>Alamat</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("alamat", $nik); ?></b>
					<p>Status kawin</p><span>:</span><b class="hurufCaSe"><?php querypenduduk("perkawinan", $nik); ?></b>
				</div>
			<br>

			<p class="huruf14">Bahwa yang bersangkutan benar benar warga desa <?= $iddesa; ?> Kecamatan <?= $idkec; ?> Kabupaten <?= $idkab; ?> Provinsi Sulawesi Tengah dan tergolong dalam keluarga berekonomi lemah (TIDAK MAMPU) </p>
			<br>
				<p class="huruf14">Demikian surat keterangan ini kami buat dengan benar untuk dapat dipergunakan sebagai mengurus <b>bantuan sekolah</b></p>

		<!-- tanda tangan -->
			<br>
			<div class="container huruf14">
				<div class="container"><?= $iddesa; ?>, <?= date('d M Y'); ?></div>
				<div class="jarak10"></div>
				<div class="kotakTtd">
					<div class="ttd1">
						<p>Mengetahui</p>
						<p>Kepala Desa Saiti kecamatan Nuhon</p>
						<div class="jarak10"></div>
						<div class="jarak40"></div>
					</div>
					<div class="ttd2">
						<p>Mengetahui</p>
						<p>Kepala Desa Saiti</p>
						<div class="jarak10"></div>
						<div class="jarak40"></div>
					</div>
					<div class="ttd3">
						<p>Mengetahui</p>
						<p>Kepala Desa Saiti</p>
						<div class="jarak10"></div>
						<div class="jarak40"></div>
						
					</div>

					<b class="ttd1 nmttd" >Lamudi</b>
					<b class="ttd2 nmttd" ><?php globaldesa("kades"); ?></b>
					<b class="ttd3 nmttd" >Lamudi</b>
				</div>
			</div>
<?php } ?>

 <!-- ============================================================== -->
 