<?php 

$conn = mysqli_connect ("localhost", "root", "", "desa_banggai") or DIE ( mysqli_error() );
 
 //-----------------------
echo "<br>";

function querycell($querycell){
	global $conn;
	$result = mysqli_query($conn, $querycell);
	$row = mysqli_fetch_assoc($result);
	return $row;
}

$cellkelembagaan = querycell("SELECT * FROM kelembagaan");
echo $cellkelembagaan["alamat"];

//-----------------------
echo "<br>"; 

$periode = [[1,2,3],[4,5,6],[7,8,9,10]];

foreach ($periode as $per) {
	foreach ($per as $p) {
	echo $p;
		}
	}

//-----------------------
echo "<br>"; 

// while($row = mysqli_fetch_assoc($cellkelembagaan2) ){
//         echo $row["nama"] ."<br>"; 
//     }

//-----------------------
echo "<br>"; 

$data =mysqli_fetch_assoc($cellkelembagaan2);

foreach ($data as $kel) {
		echo "$kel ";
	}
 
 ?>
//-----------------------
<?php 

$linkTable = "n26_profil_lmbg_pemdes.php?theme=$theme&iddesa=$iddesa";
$field = ["No.","Perode","Ke","Tahun"];
$barisList =[["ada", "periode","coba"],["asa", "periode","coba2"],["ana", "periode", "coba3"],["ara", "periode","coba4"]];

?>

<?php 
function listLink($field, $barisList, $linkTable){ 
	global $theme;
	global $iddesa;
	$i=1;	
?>	
	<div class="containerBaca">
			<table class="w3-table w3-striped w3-bordered w3-border w3-hoverable ">
				<tr>
					<?php  
					foreach ($field as $f):?>
						<th class="w3-theme-l2"><?= $f ?></th>
					<?php endForeach ?>
				</tr>
					
				<?php 

				foreach ($barisList as $barl):?>
					<?php 
						$id='&id='.$barl[0]; 
						$hrefku=$linkTable.$id;
					?>
					<tr>
						<td><a href=<?= $hrefku ?>><?= $i;$i++ ?></a></td>
						<?php foreach($barl as $b):?>
						<td><a href=<?= $hrefku ?>><?= $b; ?></a></td>
						<?php endForeach ?>	
					</tr>
				<?php endForeach ?>
			</table>
		</div>
	
 	<?php } ?>



 ?>

<?php 
// -------------------------

while ( $data = mysqli_fetch_assoc($result4) ) {
	// var_dump($data["nama"]);
	echo "<br><br>";
	
	foreach ($data as $k => $v) {
		print_r($v);
		echo "<br>";
}


}

foreach ($tabelkelembagaan as $k => $v) {
		var_dump($v);
		echo "<br>";
} 

// -------------------------
?>