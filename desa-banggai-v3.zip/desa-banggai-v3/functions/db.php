<?php
$host       = "saitimobile.online";
$user       = "saitimob_dbsaiti";
$password   = "saitimobile";
$db         = "saitimob_desa_banggai";

$conn = mysqli_connect ($host, $user, $password, $db) or DIE ( mysqli_error("database belum konect") );
?>

<?php
// ----- metode pengambilan cell ------

// function querycell($querycell){
// 	global $conn;
// 	$result = mysqli_query($conn, $querycell);
// 	$row = mysqli_fetch_assoc($result);
// 	return $row;
// }

// $desa 				= $iddesa;
// $cellapbdesin 		= querycell("SELECT * FROM apbdesin WHERE desa='$desa'");
// $cellapbdesout 		= querycell("SELECT * FROM apbdesout WHERE desa='$desa'");
// $cellartikel 		= querycell("SELECT * FROM artikeltb WHERE desa='$desa'");
// $cellkelembagaan 	= querycell("SELECT * FROM kelembagaan WHERE desa='$desa'");
// $cellkelembagaanmasy = querycell("SELECT * FROM kelembagaanmasyarakat WHERE desa='$desa'");
// $cellkependudukan 	= querycell("SELECT * FROM kependudukan WHERE desa='$desa'");
// $cellpesan 			= querycell("SELECT * FROM pesan WHERE desa='$desa'");
// $cellprogramdesa 	= querycell("SELECT * FROM programdesa WHERE desa='$desa'");
// $cellsaranaumum 	= querycell("SELECT * FROM saranaumum WHERE desa='$desa'");
// // tabel ini belum di buat bereskan:	????????????
// $cellayanan;

// // METODE PEMANGGILAN
?>
<!-- ----- metode pembuatan list link -------->

<?php

// $query1	= "SELECT * FROM apbdesin WHERE desa='$desa'";
// $query2 = "SELECT * FROM apbdesout WHERE desa='$desa'";
// $query3	= "SELECT * FROM artikeltb WHERE desa='$desa'";
// $query4 = "SELECT * FROM kelembagaan WHERE desa='$desa'";
// $query5 = "SELECT * FROM kelembagaanmasyarakat WHERE desa='$desa'";
// $query6 = "SELECT * FROM kependudukan WHERE desa='$desa'";
// $query7 = "SELECT * FROM pesan WHERE desa='$desa'";
// $query8 = "SELECT * FROM programdesa WHERE desa='$desa'";
// $query9 = "SELECT * FROM saranaumum WHERE desa='$desa'";

// $data1 = mysqli_query($conn, $query1);
// $data2 = mysqli_query($conn, $query2);
// $data3 = mysqli_query($conn, $query3);
// $data4 = mysqli_query($conn, $query4);
// $data5 = mysqli_query($conn, $query5);
// $data6 = mysqli_query($conn, $query6);
// $data7 = mysqli_query($conn, $query7);
// $data8 = mysqli_query($conn, $query8);
// $data9 = mysqli_query($conn, $query9);

// $tabelapbdesin 			= mysqli_fetch_assoc($result1);
// $tabelapbdesout 			= mysqli_fetch_assoc($result2);
// $tabelartikel 			= mysqli_fetch_assoc($result3);
// $tabelkelembagaan 		= mysqli_fetch_assoc($result4);
// $tabelkelembagaanmasy 	= mysqli_fetch_assoc($result5);
// $tabelkependudukan 		= mysqli_fetch_assoc($result6);
// $tabelpesan 				= mysqli_fetch_assoc($result7);
// $tabelprogramdesa 		= mysqli_fetch_assoc($result8);
// $tabelsaranaumum 		= mysqli_fetch_assoc($result9);


// METODE PEMANGGILAN 

// listLink($field, $barisList, $linkTable);
// echo $cellkelembagaan['nama'];
// echo "<br>"; 
// echo $cellkelembagaan['jabatan'];
// listLink2($field, $data4, $linkTable);
// echo "<br>";
// echo $cellkelembagaan['alamat'];
// listLink3($field, $data4, $linkTable);
// echo "<br>";

// ============
?>


<?php 

// =============== hitung jumlah baris db =====




// =============== function query ===== 

function query($query){
	global $conn;
	$result = mysqli_query($conn, $query);
	$barisdata = [];
	
	while ($data = mysqli_fetch_assoc($result)) {
		$barisdata = $data;
	}
	
	return $barisdata;
}

// =============== function query ===== 
function queryulang($query){
	global $conn;
	$result = mysqli_query($conn, $query);
	return $result;
}
// =============== global desa =====

function globaldesa($field){
	global $conn, $iddesa;
	$querydesa = "SELECT * FROM globaldesa WHERE desa='$iddesa'";
	$resultdesa = mysqli_query($conn, $querydesa);
	$datadesa = mysqli_fetch_assoc($resultdesa);
	echo $datadesa[$field];
	}

// =============== query data desa =====
function querypenduduk($field, $nik){
	global $conn, $iddesa;

	$query = "SELECT * FROM penduduk WHERE desa='$iddesa' AND nik='$nik'";
	$result = mysqli_query($conn, $query);
	$data = mysqli_fetch_assoc($result);
	echo $data[$field];
	}

// =============== query umum TABLE dan FIELD database  =============

function queryTF($tabel, $field){
	global $conn, $iddesa;

	$query = "SELECT * FROM $tabel WHERE desa='$iddesa'";
	$result = mysqli_query($conn, $query);
	$data = mysqli_fetch_assoc($result);
	echo $data[$field];
	}

// =============== query umum TABLE, FIELD, ID layanan (dri n5) =============
function queryTFlayanan($tabel, $field){
	global $conn, $iddesa, $idlayanan;
	
	$query = "SELECT * FROM $tabel WHERE desa='$iddesa' OR desa='umum' AND id='$idlayanan' " ;
	$result = mysqli_query($conn, $query);
	$data = mysqli_fetch_assoc($result);
	echo $data[$field];
	}

function queryTFlayanan2($tabel, $field){
	global $conn, $iddesa, $idlayanan;
	
	$query = "SELECT * FROM $tabel WHERE desa='$iddesa' OR desa='umum' AND id='$idlayanan' " ;
	$result = mysqli_query($conn, $query);
	$data = mysqli_fetch_assoc($result);
	return $data[$field];
	}

// ================ bikin listlink tabel menggunakan array ======

// -field = array
// -barisList = array bersarang
// -linktable= link href halaman beserta method getnya jika diperlukan

function listLink($field, $barisList, $linkTable){ 
	global $theme;
	global $iddesa;
	$i=1;	
?>	
	<div class="containerBaca">
			<table class="w3-table w3-striped w3-bordered w3-border w3-hoverable ">
				<tr>
					<?php  
					foreach ($field as $f):?>
						<th class="w3-theme-l2"><?= $f ?></th>
					<?php endForeach ?>
				</tr>
					
				<?php 

				foreach ($barisList as $barl):?>
					<?php 
						$id='&id='.$barl[1]; 

						$hrefku=$linkTable.$id;
					?>
					<tr>
						<td><a href=<?= $hrefku ?>><?= $i;$i++ ?></a></td>
						<?php foreach($barl as $b):?>
						<td><a href=<?= $hrefku ?>><?= $b; ?></a></td>
						<?php endForeach ?>	
					</tr>
				<?php endForeach ?>
			</table>
		</div>
	
 	<?php } ?>

 	<?php 
// ============

// bikin listlink tabel menggunakan array dan data

// -field = array
// -baris = dari database sbg bahan isi tabel row dan di looping seluruhnya
// -linktable= link href halaman beserta method getnya jika diperlukan


function listLink2($field, $baris, $linkTable){ 
	global $theme;
	global $iddesa;
	$i=1;
	?>

	<div class="containerBaca">
			<table class="w3-table w3-striped w3-bordered w3-border w3-hoverable ">
				<tr>
					<?php  
					foreach ($field as $f):?>
						<th class="w3-theme-l2"><?= $f ?></th>
					<?php endForeach ?>
				</tr>
					
				<?php 

				while ( $data = mysqli_fetch_assoc($baris) ) { ?>

				<tr>
					<td><a href=<?= $linkTable ?>><?= $i;$i++ ?></a></td>
					<?php foreach($data as $d):?>
					<?php $id="&id=".$data["id"]; ?>
					<td><a href=<?= $linkTable.$id; ?>><?= $d; ?></a></td>
					<?php endForeach ?>	
				</tr>

				<?php } ?>

			</table>
		</div>
<?php } ?>

<?php 

// bikin listlink tabel menggunakan array dan data

// -field = array
// -baris = dari database sbg bahan isi tabel row dan di looping sebagian yang di perlukan secra manual
// -linktable= link href halaman beserta method getnya jika diperlukan

function listLink3($field, $baris, $linkTable){ 
	global $theme;
	global $iddesa;
	$i=1;
	?>
		
		<div class="containerBaca">
			<table class="w3-table w3-striped w3-bordered w3-border w3-hoverable ">
				<tr>
					<?php  
					foreach ($field as $f):?>
						<th class="w3-theme-l2"><?= $f ?></th>
					<?php endForeach ?>
				</tr>
				
				<?php 

				while ( $data = mysqli_fetch_assoc($baris) ) { ?>

				<tr>
					<td><a href=<?= $linkTable ?>><?= $i;$i++ ?></a></td>
					<?php $id="&id=".$data["id"]; ?>
					<td><a href=<?= $linkTable.$id; ?>><?= $data["nama"]; ?></a></td>
					<td><a href=<?= $linkTable.$id; ?>><?= $data["alamat"]; ?></a></td>
					<td><a href=<?= $linkTable.$id; ?>><?= $data["periode"]; ?></a></td>
				</tr>

				<?php } ?>

				
			</table>
		</div>

	<?php } ?>

<?php 
// persiapan parameter pemanggilan dilakukan di halaman masing2

// $linkTable = "n26_profil_lmbg_pemdes.php?theme=$theme&iddesa=$iddesa";
// $field = ["No.","Periode","Tahun","Sampai"];
// $barisList =[["ada", "periode","coba"],["asa", "periode","coba2"],["ana", "periode", "coba3"],["ara", "periode","coba4"]];

// metode pemanggilan

// listLink($field, $barisList, $linkTable);
// echo $cellkelembagaan['nama'];
// echo "<br>"; 
// echo $cellkelembagaan['jabatan'];
// listLink2($field, $data4, $linkTable);
// echo "<br>";
// echo $cellkelembagaan['alamat'];
// listLink3($field, $data4, $linkTable);
// echo "<br>";


// dari halaman n6 =====================

function status($value){
	$statusLayanan="";
	switch ($value) {
		case 1:
			$statusLayanan = "terkirim";
			break;
		case 2:
			$statusLayanan = "masih ada yang salah";
			break;
		case 3:
			$statusLayanan = "Lengkapi persyaratan";
			break;
		case 4:
			$statusLayanan = "selesai";
			break;
		default:
			$statusLayanan = "kirim ulang...";
			break;
	}
	return $statusLayanan;
} 

// dari halaman dasboard2 =====================
 
function status2($kode){
				switch ($kode) {
					case '1':
						echo "belum di periksa";
						break;

					case '2':
						echo "masih ada yg salah";
						break;

					case '3':
						echo "lengkapi !!!";
						break;

					case '4':
						echo "selesai";
						break;

					default:
						echo "belum di periksa";
						break;
				}
			}
?>


