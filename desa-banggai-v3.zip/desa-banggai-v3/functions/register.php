<?php 
require_once "../core/init.php";

$iddesa = $_SESSION["desa"];
$error = '';

if(isset($_SESSION['error'])){unset($_SESSION["error"]);}

// redirec kalau user sudah login
// if( isset($_SESSION['user']) ){
//     header ( 'Location: index.php' );
// }

// validasi register
// if( isset($_POST["submitx"]) ){ 
//     $nama = $_POST["usernamex"];
//     $pass = $_POST["passwordx"];
//     $desa = $iddesa;
//     $nik  = $_POST["nik"];
//     // die($nama.' '.$pass);

//     if ( !empty( trim($nama)) && !empty( trim($pass)) && !empty( trim($nik)) ) {
//         // echo 'terimakasih sudah di isi';
//         // register_user($nama, $pass);

//         if ( register_cek_nama($nama) ){
//                 if ( register_user($nama, $pass, $desa) ){
//                         $error = 'berhasil register';
//                         header( 'Location: login.php' );
//                         }else{$error = 'gagal register';}
//                 }else{ $error = 'nama sudah ada, silahkan masukan nama yang lain!'; }
//         }else{ $error = 'field tidak boleh kosong';}
// }
?>

<?php
if( isset($_POST["submitx"]) ){ 
    $nama = $_POST["usernamex"];
    $pass = $_POST["passwordx"];
    $desa = $iddesa;
    $nik  = $_POST["nik"];
    // die($nama.' '.$pass);

    if ( !empty( trim($nama)) && !empty( trim($pass)) && !empty( trim($nik)) ) {
        // echo 'terimakasih sudah di isi';
        // register_user($nama, $pass);

        if ( register_cek_nama($nama) ){
            if( register_cek_nik($nik, $desa) ){
                if ( register_user($nama, $pass, $desa) ){
                        $error = 'berhasil register';
                        $_SESSION['error'] = $error;
                        header( 'Location: login.php' );
                        }else{$error = 'gagal register';}
                    }else{ $error = 'NIK anda belum terdaftar! silahkan datang ke Kantor Desa '. ucfirst($iddesa)  .' untuk cek NIK'; }
                }else{ $error = 'nama sudah ada, silahkan masukan nama yang lain!'; }
        }else{ $error = 'field tidak boleh kosong';}
}

?>

<!--  -->

<?php
require_once "../view/header.php";
?>
<div class="containerBaca marginB16 w3-white w3-round w3-border w3-padding" >
   
    <p>Untuk register pastikan NIK anda sudah terdaftar di Kantor Desa <?= ucfirst($iddesa); ?></p>
    <br>
    <form action="register.php" method="post">
        <input type="hidden" name="desa" value="<?= $iddesa; ?>">
        <label for="username">Nama</label><br>
            <input type="text" name="usernamex" id="username"><br><br>
        <label for="nik">NIK</label><br>
            <input type="text" name="nik" id="nik"><br><br>
        <label for="password">Password</label><br>
            <input type="password" name="passwordx" id="password"><br><br>
            <button type="submit" name="submitx" class="w3-btn w3-green w3-round w3-small">Daftar !</button>

            <br>
            <br>
        
        <?php  if( $error != ''){ ?>  
            <div id="error" class="w3-orange paddingKr10">
                <?php echo $error; ?>
            </div>
        <?php } ?>
    </form>
</div>


<?php 
require_once "../view/footer.php";
?>