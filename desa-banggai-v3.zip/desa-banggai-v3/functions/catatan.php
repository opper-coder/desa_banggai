// pada setiap halaman akan mengirimkan get lewat <a href=""></a> -
// berupa $_GET[theme] dan $_GET[iddesa]
// tinggal setiap halaman loading include halaman theme
// dan bagi pengirim link harus mencantumkan Get nya contoh di saiti.php 
   baca inspirasi dan sementara

  <!--  -->
// assets: 
// icon: info, pesan, akun, layanan, logo, add, profil desa, layanan, lapor, logo pembangunan, layanan, pemberdayaan, usaha, tombol back
// gambar ilustrasi : home, card pengumuman , baca berita , jumbotron pembangunan , foto akun, avatar, struktur organisasi, artikel, woro woro , layanan
// gambar dokumentasi :
// font : font , css
// 