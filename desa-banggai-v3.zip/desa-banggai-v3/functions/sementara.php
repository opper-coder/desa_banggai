layanan yang belum masuk
-------------
1. surat keterangan kematian
2. 

fitur
---------------
kelembagaan :
1 pemerintahan : aparat, bpd, rt/rw, 
2 keagamaan : grub yasinan, hindu, kristen
3 kelembagaan masyarakat: tani, seni dan budaya, olahraga, karang taruna, PKK, kader posyandu, bumdes

program desa :
1. prioritas musrembang
2. 10 besar usulan

galeri:
1. event
2. dokumentasi desa
3. lain lain

potensial desa 

pendapatan asli desa
arsip

manfaat:
------------------
masyarakat:
1. mendekatkan masyarakat kepada aplikasi dimana era akan mengarah ke sana
2. memudahkan urusan bagi masyarakat terkait dengan pelayanan
3. memberikan jaringan bisnis bagi pengguna
4. masyarakat dapat memonitoring keuangan desa
5. masyarakat bisa berperan aktif dalam pembangunan desa melalui fitur pesan
6. masyarakat bisa mendapatkan info dan edukasi bisnis 
7. masyarakat akan lebih merasa ikut memiliki dan lebih mencintai desanya sendiri lebih dekat karena terlibat langsung
8. masyarakat dapat meng akses profil dan statistik desa lebih mudah di genggaman
9. masyarakat bisa sekedar hiburan untuk bisa melihat galery dan video tentang desa dan seni
11. jika ingin mendapatkan tanggapan silahkan gunakan fasilitas chat layanan dengan klik tombol pesan

pemdes:
1. mudah dalam melayani
2. administrasi lebih rapi
3. menjadi pemicu untuk kreatif (mau mengumpulkan data yang selama ini tak terurus, dan pemdes bisa lbh fokus ke pengembangan desa)
4. mudah dalam pengambilan keputusan karena memegang data aspirasi dan pemetaan kepentingan
5. punya landasan berfikir untuk pengembangan manfaat dalam aplikasi(nambah layanan)
6. mudah dalam pengumpulan data yang diperlukan, dari masyarakat melalui form (cooming soon/conditional)
7. mudahnya instruksi kepada aparat dan masyarakat
8. ada surat kaleng/anonim (tapi surat kaleng tidak berhak mendapat tanggapan dari pemdes) silahkan gunakan media 
dengan bijak / untuk mendengar kata masyarakat desa 
9. data bisa di gunakan oleh instansi lain tanpa harus repot buka dokumen

pemkab:
1. monitoring perkembangan dan progress pembangunan desa
2. instruksi kepada kepala2 desa
3. bisa melihat histori percakapan dan kecenderungan masyarakat desa bersangkutan terhadap tema yang di kembangkan 
	(cooming soon/conditional).

marketing
------------------
strategi
kalkulasi

-----------------
ISI PRESENTASI

foto
1. demo ojek ke gojek
2. lapak vs supermarket
3. supermarket vs toko online 
4. penjual kripik online dan penghasilanya
5. penjual masakan gurita 4 milyar
6. pertanian peternakan bisa di online
7. jangan hanya berfikir untuk kita saja tapi juga generasi kita yang masuk di era ini /smp/sma
8. kalau, tidak dominasi cina akan melindas kita

video
1. Jokowi Dilan
2. Nadiem tentang IT
