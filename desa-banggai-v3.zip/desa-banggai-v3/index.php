<?php require 'view/top_body.php'; ?>

<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: rgba(61, 140, 230, 1);
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 8px 14px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}

.jumbotron{
	background-color: rgba(69, 69, 69, 1);
	width: 100%;
	min-height:350%;
	display: flex;

}
.desc{
	font-size: 12px;
	color: rgba(204, 204, 204, 1);
	margin-top: 80px;
}
.desc p{
	margin-bottom: 3px;
}
.wtombol{
	padding-top: 60px;
	text-align: center;
}
.tombol{
	background-color: #4CAF50;
	color: white;
	border-radius: 4px;
	border:none;
	padding: 7px 30px;
	margin: 10px;
}
.tombol2{
	background-color: rgba(61, 140, 230, 1);
	color: white;
	border-radius: 4px;
	border:none;
	padding: 7px 30px;
	margin: 10px;
}
.gbr{
	width: 100px;
	height: 150px;
	margin-left: auto;
	margin-right: 30px; 
	margin-top: 30px;
}
</style>
</head>
<body>

<div class="topnav">
  <a class="active" href="#home">Home</a>
</div>

<div class="jumbotron">
	<div style="padding:20px 20px; color:white;">
  	<p style="font-size: 28px">Selamat datang</p>
  	<p>di Saiti mobile download</p>
  	<div class="desc">
	  	<p>Aplikasi Saiti Mobile dapat di download dan dinstall</p>
	  	<p>pada smartphone anda silahkan klik </p>
	  	<p>tombol download di bawah. Aplikasi ini dapat di gunakan</p>
	  	<p>untuk melihat dan berinteraksi dengan data dan sebagian layanan </p>
	  	<p>kantor desa saiti. Namun ada sebagian feature belum maksimal dapat di gunakan </p>
	  	<p>karena masih dalam tahap pengembanagan secara berkala</p>
	  	<p>Silahkan berikan masukan dan saran kepada kami untuk meneyempurnakan fungsi dan layanan</p>
	  	<p>pada aplikasi dan pemerintah melalui saluran kontak yang di sediakan</p>
  	</div>
	</div>
<img src="assets/saiti/utils/logoSaiti.png" class="gbr">
</div>
<div class="wtombol">
	<a class="tombol w3-btn" href="index.php?file=sekdes.jpg">Download!</a>
	<a class="tombol2 w3-btn" href="index.php?file=sekdes.jpg">Alternative!</a>
</div>
</body>
</html>

<?php 
if (!empty($_GET['file'])) {
	$filename = basename($_GET['file']);
 	$filepath = '../download/apk/' . $filename;

 	if (!empty($filename) && file_exists($filepath)) {
 		header("Cache-Control: public");
 		header("Content-Description: File Transfer");
 		header("Content-Disposition: attachment; filename=$filename");
 		header("Content-Type: application/zip");
 		header("Content-Transfer-Emcoding: binary");
 		
 		readfile($filepath);
 		exit;
	}else{
 		echo "file tidak ditemukan!";
 	}
}



 require 'view/bottom_body.php' ?>

