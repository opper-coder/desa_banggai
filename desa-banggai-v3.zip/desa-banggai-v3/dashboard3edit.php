<?php
	$theme = "view/theme/theme_blue.php";
	$judulHalaman = "EDIT DATA PERMOHONAN";
	$iddesa = $_GET['iddesa'];
	$idlayout = $_GET['idlayout'];
	require 'view/top_body.php';
	require $theme;
	require 'view/center_body.php';
	require 'functions/db.php';
	$databaris = query("SELECT * FROM suratkeluar WHERE id='$idlayout' AND desa='$iddesa'");
	$datalayanan = query("SELECT * FROM layanan WHERE id='$idlayout' AND desa='umum' OR desa='$iddesa' ")
?>
<div class="navback w3-theme-d2 w3-card w3-padding">
	<a href="dashboard2.php?iddesa=<?= $iddesa ?>&idlayout=<?= $idlayout; ?>"><img src="assets/panahKiriP.png" alt=""></a>
	<p><?= $judulHalaman; ?></p>
</div>
<br>
<br>
<br>
<?php
// ===== FUNGSI UBAH DATA
function ubahdata($post, $id){
	global $conn;

	// $data1 	= $_POST["id"];
	$data2 	= $post["idlayanan"];
	$data3 	= $post["nomor"];
	$data4 	= $post["data"];
	$data5 	= $post["pemohon"];
	$data6 	= $post["nikpemohon"];
	$data7 	= $post["penerbit"];
	$data8 	= $post["sender"];
	$data9 	= $post["perihal"];
	$data10 = $post["tglmasuk"];
	$data11 = $post["tglterbit"];
	$data12 = $post["verifikasi"];
	$data13 = $post["pesan"];
	$data14 = $post["desa"];

	$query = "UPDATE suratkeluar SET 
				idlayanan 	= '$data2',
				nomor 		= '$data3',
				data 		= '$data4',
				pemohon 	= '$data5',
				nikpemohon	= '$data6',
				penerbit 	= '$data7',							
				sender 		= '$data8',
				perihal 	= '$data9',
				tglmasuk 	= '$data10',
				tglterbit 	= '$data11',
				verifikasi 	= '$data12',
				pesan 		= '$data13',
				desa 		= '$data14'
  			  WHERE id=$id";

  	mysqli_query($conn, $query);
  	return mysqli_affected_rows($conn);
}
	// ====+ jalankan tombol
	if(isset($_POST["edit"])){
		$data = $_POST;
		$id = $idlayout;
		ubahdata($data, $id);
		echo "
		<script>
			alert('perubahan data berhasil di simpan! halaman akan di kembalikan ke dashboard');
			document.location.href = 'dashboard.php';
		</script>";
	}
?>
<div class="containerdashboard2 w3-padding">
	<div class="w3-padding w3-margin">	
		<b>Isikan data yang benar dan aktual untuk data permohonan yang bersangkutan </b>
		<br><br>
		<form action="" method="post">
			<input type="hidden" name="id" value="<?= $databaris['id']; ?>">
			<input type="hidden" name="idlayanan" value="<?= $databaris['idlayanan']; ?>">
			<input type="hidden" name="nomor" value="<?= $databaris['nomor']; ?>">
			<input type="hidden" name="penerbit" value="<?= $databaris['penerbit']; ?>">
			<input type="hidden" name="tglterbit" value="<?= $databaris['tglterbit']; ?>">
			<input type="hidden" name="desa" value="<?= $databaris['desa']; ?>">
			<table>
				<tr>
					<td><label for="layanan">Nama layanan</label></td><td style="padding: 0 20px 0 20px"> : </td>
					<td style="font-weight: bold;"><?= $datalayanan['nama']; ?></td>
				</tr>
				<tr>
					<td><label for="nik">Nik pemohon</label></td><td style="padding: 0 20px 0 20px"> : </td>
					<td><input type="text" name="nikpemohon" id="nik" value="<?= $databaris['nikpemohon'] ?>"></td>
				</tr>
				<tr>
					<td><label for="pemohon">Nama pemohon</label></td><td style="padding: 0 20px 0 20px"> : </td>
					<td><input type="text" name="pemohon" id="pemohon" value="<?= $databaris['pemohon'] ?>"></td>
				</tr>
				<tr>
					<td><label for="sender">Nama Pengirim</label></td><td style="padding: 0 20px 0 20px"> : </td>
					<td><input type="text" name="sender" id="sender" value="<?= $databaris['sender'] ?>"></td>
				</tr>
				<tr>
					<td><label for="perihal">Perihal</label></td><td style="padding: 0 20px 0 20px"> : </td>
					<td><input type="text" name="perihal" id="perihal" value="<?= $databaris['perihal'] ?>"></td>
				</tr>
				<tr>
					<td><label for="data">Data</label></td><td style="padding: 0 20px 0 20px"> : </td>
					<td><input type="text" name="data" id="data" value="<?= $databaris['data'] ?>"></td>
				</tr>
				<tr>
					<td><label for="tglmasuk">Tgl Masuk</label></td><td style="padding: 0 20px 0 20px"> : </td>
					<td><input type="text" name="tglmasuk" id="tglmasuk" value="<?= $databaris['tglmasuk'] ?>"></td>
				</tr>
				<!-- <tr>
					<td><label for="verifikasi">Status Layanan</label></td><td style="padding: 0 20px 0 20px"> : </td>
					<td><input type="text" name="verifikasi" id="verifikasi" value="<?= $databaris['verifikasi'] ?>"></td>
					<span>isi nilai 1 - 4 sesuai kode verifikasi atau jangan di ubah disini</span>
				</tr> -->
				<tr>
					<td><label for="pesan">Pesan</label></td><td style="padding: 0 20px 0 20px"> : </td>
					<td><input type="text" name="pesan" id="pesan" value="<?= $databaris['pesan'] ?>"></td>
				</tr>
			</table>
			<br><br>	
			<button type="submit" name="edit" class="w3-btn w3-blue">Simpan perubahan!</button>
			<br><br>
			<div class="w3-padding w3-pale-red ">		
			</div>
		</form>
	</div>
</div>

 <?php require 'view/bottom_body.php' ?>