<?php
	$theme = "view/theme/theme_blue.php";
	$judulHalaman = "DASBOARD VERIFIKASI INBOX LAYANAN";
	$iddesa = $_GET['iddesa'];
 	require 'view/top_body.php';
	require $theme;
	require 'view/center_body.php';
	require 'functions/db.php';
?>
<div class="navback w3-theme-d2 w3-card w3-padding">
	<a href="dashboard.php?iddesa=<?= $iddesa ?>"><img src="assets/panahKiriP.png" alt=""></a>
	<p><?= $judulHalaman; ?></p>
</div>
 <br><br><br>
<!-- INGAT QUERY LAYANAN BELUM SELESAI LO DI DASHBOARD YANG WHERE ID 1 itu-->
<?php 
	// $idpermohonan = $_POST['idlayout'];
	$idpermohonan = $_GET['idlayout'];
	$querypermohonan = "SELECT * FROM suratkeluar WHERE desa='$iddesa' AND id='$idpermohonan'"; 
	$resultpermohonan = mysqli_query($conn, $querypermohonan);
	$datapermohonan = mysqli_fetch_assoc($resultpermohonan);
	function querylay($idlayanan){
			global $iddesa, $conn;
			$querylayanan = "SELECT * FROM layanan WHERE desa='umum' AND id=$idlayanan OR desa='$iddesa'"; 
			$resultlayanan = mysqli_query($conn, $querylayanan);
			$datalayanan = mysqli_fetch_assoc($resultlayanan);
			echo $datalayanan['nama'];
	 	}
			$idlaya = $datapermohonan['idlayanan'];
 ?>	
<div class="containerdashboard2 w3-padding">
	<?php 
		// var_dump($datapermohonan);
	 ?>
	<h2 class="hurufCaSe">Data Permohonan <?= $datapermohonan["pemohon"] ?> </h2>
	<p>Apakah data sudah benar? Silahkan di cek untuk di verifikasi</p>
	<br>
	<div class="w3-tiny" >
		<ul style="list-style: none;">
			<b>kode verifikasi</b>
			<li>0 = belum di perikasa</li>
			<li>1 = sudah selesai diperiksa</li>
			<li>2 = masih ada yang salah</li>
			<li>3 = lengkapi semua persyaratan</li>
			<li>4 = selesai, silahkan ambil berkas</li>
			<li>5 = masih salah perbaiki dulu </li>
		</ul>
	</div>
	<br>
	<b>Layanan yang di ajukan:</b>
	<p style="color: red"><?php querylay($idlaya) ?></p>
	<table class="w3-table w3-border w3-striped">
		<tr >
			<th>No</th>	
			<!-- <th>Kontrol</th> -->
			<th>Nama Field</th><th></th>
			<th>Isi Data</th>
		</tr>
		<?php
			$i = 1; 
			$field = ["Nama Layanan","Nik Pemohon","Pemohon","Pengirim","Perihal","Data","tgl masuk","status layanan","pesan"];
			$jumlahfield = sizeof($field);
			$fieldsql = ["id","nikpemohon","pemohon","sender","perihal","data","tglmasuk","verifikasi","pesan"];
			?>
			<tr>
			<?php
			while ($i < $jumlahfield) {?>
					<td><?= $i; ?></td>
					<td><?= $field[$i]; ?></td>
					<td>:</td>
					<td style="color: red">
						<?php 
							if($i == 7){
								status2($datapermohonan[$fieldsql[$i]]);
								} else{ echo $datapermohonan[$fieldsql[$i]];}
						?>
					</td>
				</tr>
			<?php $i++; } ?>
	</table>
	<br>
	<!--  -->
	<form action="pages/cetak.php" method="post" target="blank">
		<input type="hidden" name="cetak" value="<?= $idpermohonan; ?>">
		<button class="w3-btn w3-blue marginB10 marginKr10" name="preview">Cetak</button>
	</form>
	<form action="dashboard3edit.php?iddesa=<?= $iddesa; ?>&idlayout=<?= $idpermohonan; ?>" method="post" style="display: inline-block">
		<button class="w3-btn w3-border marginB10 marginKr10 " name="data" value="">Perbaiki data</button>
	</form>
	<!--  -->
		<?php 	
			function notifkirim($kirim){
				if ($kirim > 0 ){?>
					<p class="w3-text-blue">data berhasil terkirim...!</p>	
			<?php } else{  ?>
					<p style="color: red">data gagal terkirim...! </p>
			<?php 	} 		
			} ?>
		<?php 
			$databaris = query("SELECT * FROM suratkeluar WHERE id='$idpermohonan' AND desa='$iddesa'");
		 ?>
	<!--  -->
	<form action="" method="post">
		<h4>Pilih status proses yang sedang berlangsung</h4>
		<input type="hidden" name="id" value="<?= $databaris['id']; ?>">
		<input type="hidden" name="idlayanan" value="<?= $databaris['idlayanan']; ?>">
		<input type="hidden" name="nomor" value="<?= $databaris['nomor']; ?>">
		<input type="hidden" name="data" value="<?= $databaris['data']; ?>">
		<input type="hidden" name="pemohon" value="<?= $databaris['pemohon']; ?>">
		<input type="hidden" name="nikpemohon" value="<?= $databaris['nikpemohon']; ?>">
		<input type="hidden" name="penerbit" value="<?= $databaris['penerbit']; ?>">
		<input type="hidden" name="sender" value="<?= $databaris['sender']; ?>">
		<input type="hidden" name="perihal" value="<?= $databaris['perihal']; ?>">
		<input type="hidden" name="tglmasuk" value="<?= $databaris['tglmasuk']; ?>">
		<input type="hidden" name="tglterbit" value="<?= $databaris['tglterbit']; ?>">
		<input type="hidden" name="desa" value="<?= $databaris['desa']; ?>">
		<label class="container">
		  <input type="radio" checked="checked" name="verifikasi" value="1"> Belum di periksa
		  <span class="checkmark"></span>
		</label>
		<br>
		<label class="container">
		  <input type="radio" name="verifikasi" value="2"> Masih ada yang salah
		  <span class="checkmark"></span>
		</label>
		<br>
		<label class="container">
		  <input type="radio" name="verifikasi" value="3"> Lengkapi semua persyaratan
		  <span class="checkmark"></span>
		</label>
		<br>
		<label class="container">
		  <input type="radio" name="verifikasi" value="4"> Selesai diperiksa
		  <span class="checkmark"></span>
		</label>
		<br><br>
		<p>tuliskan pesan kepada pemohon akan apa yang terjadi pada proses saat ini</p>
		<input type="textarea" name="pesan">
		<br>
		<br>
		<button class="w3-btn w3-blue marginB10 marginKr10" type="submit" name="verifi">kirim status layanan</button>
	</form>
	<div class="w3-padding w3-pale-red ">
		<?php 
		function ubahdata2($post, $id){
				global $conn;
				// $data1 	= $_POST["id"];
				$data2 	= $post["idlayanan"];
				$data3 	= $post["nomor"];
				$data4 	= $post["data"];
				$data5 	= $post["pemohon"];
				$data6 	= $post["nikpemohon"];
				$data7 	= $post["penerbit"];
				$data8 	= $post["sender"];
				$data9 	= $post["perihal"];
				$data10 = $post["tglmasuk"];
				$data11 = $post["tglterbit"];
				$data12 = $post["verifikasi"];
				$data13 = $post["pesan"];
				$data14 = $post["desa"];
				$query = "UPDATE suratkeluar SET 
							idlayanan 	= '$data2',
							nomor 		= '$data3',
							data 		= '$data4',
							pemohon 	= '$data5',
							nikpemohon	= '$data6',
							penerbit 	= '$data7',							
							sender 		= '$data8',
							perihal 	= '$data9',
							tglmasuk 	= '$data10',
							tglterbit 	= '$data11',
							verifikasi 	= '$data12',
							pesan 		= '$data13',
							desa 		= '$data14'
			  			  WHERE id=$id";
			  	mysqli_query($conn, $query);
			  	return mysqli_affected_rows($conn);
			}
		// ====+ jalankan tombol
			if(isset($_POST["verifi"])){
				$data1 = $_POST;
				$id = $idpermohonan;
				notifkirim(ubahdata2($data1, $id));
				echo "
				<script>
	 				alert('perubahan data berhasil di simpan! halaman akan di kembalikan ke dashboard');
	 				document.location.href = 'dashboard.php';
	 			</script> ";
			}
		?>
	</div>
</div>
 <?php require 'view/bottom_body.php' ?>